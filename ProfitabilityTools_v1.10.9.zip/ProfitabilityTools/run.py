"""Point d'entrée racine pour la construction de l'exécutable (PyInstaller).

Contrairement à `python -m app.main`, ce script peut être exécuté
directement (double-clic, ou passé tel quel à PyInstaller) car il se trouve
déjà à la racine du projet, là où le package `app` est visible.
"""
import sys

from app.main import main

if __name__ == "__main__":
    sys.exit(main())
