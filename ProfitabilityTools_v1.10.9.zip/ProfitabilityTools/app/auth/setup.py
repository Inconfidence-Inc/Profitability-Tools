"""Déclaration de ProfitabilityTools auprès du module `auth_partage`, et
repli local (SQLite) tant que la base centrale OUTILS n'est pas configurée
sur ce poste (v1.10.0).

Pourquoi un repli local plutôt qu'exiger OUTILS dès le premier lancement
--------------------------------------------------------------------------
`auth_partage` est explicite sur ce point (voir auth_partage/database.py) :
« si OUTILS est injoignable, personne ne peut se connecter — nulle part ».
C'est une dépendance critique assumée pour un parc déjà raccordé à OUTILS
(Orchestrator), mais ProfitabilityTools ne l'est pas encore sur ce poste —
imposer OUTILS dès l'installation bloquerait l'application tant qu'un
administrateur n'a pas renseigné cette connexion, pour une fonctionnalité
qui n'existait pas avant cette version. Le module prévoit justement cette
« bascule progressive » (`utiliser_session_locale`) ; faute d'ORM déjà en
place côté ProfitabilityTools (qui n'utilise que pyodbc brut pour ses
propres données métier, jamais SQLAlchemy), le repli choisi ici est un
fichier SQLite local dans le dossier de données de l'application — c'est
le même mécanisme qu'utiliserait `auth_partage.installer` pour un premier
essai, simplement amorcé automatiquement avec un compte administrateur par
défaut plutôt que de laisser l'application sans aucun compte utilisable.

Un administrateur peut ensuite basculer vers la base OUTILS centrale à
tout moment depuis l'écran de connexion (si aucune base n'est encore
configurée) ou depuis Settings, via ConnexionOutilsDialog — à ce moment-là,
PLUS AUCUN compte local SQLite n'est utilisé : auth_partage bascule
entièrement sur OUTILS (même mécanisme que pour Orchestrator), et les
comptes créés en local ne sont pas repris automatiquement (OUTILS est la
base partagée du parc — y écrire des comptes locaux sans discernement n'a
pas de sens)."""
from __future__ import annotations

import logging
import os

import auth_partage

logger = logging.getLogger("profitabilitytools.auth")

#: Code d'application déclaré dans la table partagée USERS_PYTHON
#: (préfixe PROFITABILITY_DB_ utilisé ailleurs dans le code pour la connexion
#: SQL Server métier ; celui-ci n'a AUCUN rapport — comptes applicatifs vs.
#: connexion à la base de données métier, intentionnellement séparés).
APPLICATION_CODE = "PROFITABILITYTOOLS"

#: Rôle habilité à créer/gérer les comptes de CETTE application (voir
#: app/ui/pages/users_page.py). Les autres écrans restent ouverts à tout
#: compte connecté, quel que soit son rôle — pas de restriction d'écran
#: par rôle pour cette version (décision explicite de l'utilisateur).
ROLE_ADMINISTRATEUR = "Administrateur"
#: « Lecteur » plutôt que « Utilisateur » : c'est le nom de rôle non-
#: privilégié déjà utilisé par convention dans le reste du parc (Orchestrator,
#: exemple_integration.py du module). auth_partage.ui.utilisateur.UtilisateurDialog
#: pré-sélectionne « Lecteur » par défaut à la création d'un compte (valeur
#: codée en dur dans le module partagé — non modifiée ici, voir
#: app/ui/pages/users_page.py pour le choix de ne pas toucher ce fichier) ;
#: reprendre ce nom évite que ce pré-remplissage échoue silencieusement et
#: retombe sur le premier rôle de la liste (ici, Administrateur — le rôle le
#: PLUS privilégié serait alors proposé par défaut à chaque création, ce qui
#: est exactement l'inverse de ce qu'on veut).
ROLE_UTILISATEUR = "Lecteur"

#: `permissions` appartient à l'application (voir auth_partage/config.py) :
#: le seul droit différencié ici est "utilisateurs", qui conditionne
#: l'accès à l'écran de gestion des comptes.
PERMISSIONS: dict[str, set[str]] = {
    ROLE_ADMINISTRATEUR: {"utilisateurs"},
    ROLE_UTILISATEUR: set(),
}

#: Identifiants du compte administrateur amorcé automatiquement la toute
#: première fois que l'application démarre sans aucune base d'authentification
#: configurée (ni OUTILS, ni repli local déjà créé par un lancement précédent).
#: Le changement de mot de passe est IMPOSÉ dès la première connexion
#: (doit_changer_mdp=True, forcé par auth_partage.AuthService.create_user
#: quel que soit l'appelant) — la fenêtre d'exposition de ce mot de passe
#: documenté est donc limitée à la toute première connexion.
BOOTSTRAP_LOGIN = "admin"
BOOTSTRAP_PASSWORD = "ProfitAdmin1"

NOM_FICHIER_BASE_LOCALE = "profitabilitytools_auth_local.db"


def configure_auth() -> None:
    """Déclare ProfitabilityTools auprès du module (idempotent — sans effet
    de bord si déjà appelé). DOIT être appelé avant tout autre usage de
    `auth_partage` (AuthService, LoginDialog, ...)."""
    auth_partage.configurer(
        application=APPLICATION_CODE,
        permissions=PERMISSIONS,
        role_administrateur=ROLE_ADMINISTRATEUR,
        nom_dossier_donnees="ProfitabilityTools",
        longueur_minimale_mot_de_passe=8,
    )


def local_database_path() -> str:
    """Chemin du fichier SQLite de repli, dans le même dossier de données
    que la clé de chiffrement et le profil de connexion (voir
    auth_partage.chemins.get_app_data_dir) — configure_auth() doit avoir
    été appelé avant (le dossier dépend du nom déclaré)."""
    from auth_partage.chemins import get_app_data_dir

    return os.path.join(get_app_data_dir(), NOM_FICHIER_BASE_LOCALE)


def ensure_auth_backend_ready() -> tuple[bool, str]:
    """S'assure qu'une base d'authentification (OUTILS ou repli local) est
    configurée et utilisable, et amorce un compte administrateur par défaut
    sur un repli local tout juste créé.

    Retourne (ok, message). `ok` est False uniquement si la création du
    repli local lui-même a échoué (disque plein, dossier non accessible,
    ...) — un profil OUTILS déjà enregistré mais injoignable au moment de
    l'appel n'est PAS un échec ici : c'est à l'écran de connexion de le
    signaler (message dédié, voir auth_partage.database.MESSAGE_INJOIGNABLE),
    pas à cette étape de démarrage qui ne doit pas bloquer l'application sur
    un simple aléa réseau/VPN."""
    configure_auth()

    if auth_partage.centralisee():
        # Un profil (OUTILS ou repli local déjà créé lors d'un lancement
        # précédent) est déjà enregistré sur ce poste — rien à amorcer.
        return True, "Profil d'authentification déjà configuré."

    url = f"sqlite:///{local_database_path()}"
    ok, message = auth_partage.creer_tables(url)
    if not ok:
        logger.error("Échec de création de la base d'authentification locale : %s", message)
        return False, message
    auth_partage.enregistrer_profil("Local (fichier, sans OUTILS)", "sqlite", url)

    service = auth_partage.AuthService()
    if not service.list_users(APPLICATION_CODE):
        created, create_message = service.create_user(
            BOOTSTRAP_LOGIN, "Administrateur", "", "",
            ROLE_ADMINISTRATEUR, BOOTSTRAP_PASSWORD,
            cree_par="amorçage automatique",
            commentaire="Compte créé automatiquement au premier lancement "
                        "sans base d'authentification configurée.",
        )
        if not created:
            logger.error("Échec de création du compte administrateur par défaut : %s", create_message)
            return False, create_message
        logger.info(
            "Base d'authentification locale amorcée avec le compte « %s » "
            "(mot de passe à changer à la première connexion).",
            BOOTSTRAP_LOGIN,
        )

    return True, (
        "Aucune base d'authentification centrale (OUTILS) n'était "
        "configurée sur ce poste : un repli local a été créé "
        f"({local_database_path()}), avec un compte administrateur par "
        "défaut. Un administrateur peut migrer vers la base OUTILS "
        "centrale à tout moment (écran Connexion OUTILS)."
    )
