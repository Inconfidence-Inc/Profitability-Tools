"""Authentification de ProfitabilityTools (v1.10.0).

Ce paquet est volontairement petit : toute la logique d'authentification
(comptes, mots de passe, historique, habilitations) vit dans le module
partagé `auth_partage` (repris tel quel d'Orchestrator — voir
`auth_partage/README.md`), commun à plusieurs applications du parc ICI
Assurance/Oney. Ce qui est propre à ProfitabilityTools se limite à :

- déclarer l'application auprès du module (`setup.configure_auth`) ;
- amorcer un repli local (base SQLite) tant que la base centrale OUTILS
  n'est pas configurée sur ce poste (`setup.ensure_auth_backend_ready`) ;
- l'écran de saisie de la connexion OUTILS, propre à ProfitabilityTools
  dans son habillage mais fonctionnellement identique à celui d'Orchestrator
  (`ui.ConnexionOutilsDialog`).

Décision explicite de l'utilisateur (v1.10.0) : ce compte applicatif est
INDÉPENDANT des profils de connexion SQL Server métier déjà gérés sur
l'écran Settings (Local/Recette/Production, ICI_BI/TECH_BI) — se connecter
à ProfitabilityTools ne nécessite ni ne fournit d'identifiants SQL Server
métier, et inversement. Pas de restriction d'écran par rôle pour cette
version : le rôle « Administrateur » donne uniquement le droit de créer/
gérer les comptes, tous les autres écrans restent ouverts à tout compte
connecté.
"""
