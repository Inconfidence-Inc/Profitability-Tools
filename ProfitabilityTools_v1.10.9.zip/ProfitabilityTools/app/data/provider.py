"""
Couche Data Provider (cahier des charges §20) : interface commune permettant
de basculer entre données DEMO et SQL Server sans changer la logique métier
ni l'UI. Les deux implémentations renvoient des lignes brutes avec EXACTEMENT
les mêmes noms de colonnes que les tables source SQL Server, et c'est
app.core.aggregation.build_profitability_dataset qui fait tout le travail
métier — jamais dupliqué dans les providers ni dans l'UI (cahier des charges
§19 : "La logique ProfitabilityTools ne doit pas être dispersée").
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from app.core.aggregation import build_profitability_dataset
from app.core.models import ProfitabilityRow


class DataProvider(ABC):
    """Interface commune DEMO / SQL Server."""

    #: identifiant court affiché dans l'UI (Settings, etc.)
    mode_name: str = "ABSTRACT"
    is_demo: bool = False
    #: environnement de connexion actif (RECETTE / PRODUCTION — v1.6.0),
    #: affiché dans le bandeau d'en-tête (voir app/ui/main_window.py) pour que
    #: l'utilisateur sache toujours à quelle base il est connecté.
    environment: str = ""

    @abstractmethod
    def fetch_part1_rows(self) -> list[dict[str, Any]]:
        """Lignes de [ICI_BI].[dbo].TDB_Part1."""

    @abstractmethod
    def fetch_referentiel_rows(self) -> list[dict[str, Any]]:
        """Lignes de [ICI_BI].[dbo].[FONC_Référentiel programmes]."""

    @abstractmethod
    def fetch_part2_rows(self) -> list[dict[str, Any]]:
        """Lignes de [ICI_BI].[dbo].TDB_Part2."""

    @abstractmethod
    def fetch_sinistres_rows(self) -> list[dict[str, Any]]:
        """Lignes brutes de [TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu]
        (un sinistre par ligne, v1.8.0) — le regroupement par contrat/période
        est fait par app.core.aggregation.build_profitability_dataset."""

    def load_profitability_dataset(self) -> list[ProfitabilityRow]:
        """Construit le dataset consolidé ProfitabilityTools (§1) à partir des 4 sources."""
        return build_profitability_dataset(
            self.fetch_part1_rows(),
            self.fetch_referentiel_rows(),
            self.fetch_part2_rows(),
            self.fetch_sinistres_rows(),
            is_demo_data=self.is_demo,
        )
