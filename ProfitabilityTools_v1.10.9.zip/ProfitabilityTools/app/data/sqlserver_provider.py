"""
Connecteur SQL Server (cahier des charges §19-21).

Depuis la v1.7.0 (sur demande explicite de l'utilisateur, après qu'une
tentative de connexion réelle en environnement Recette a révélé que les
tables supposées — [ICI_BI].[dbo].TDB_Part1/TDB_Part2 — n'existaient pas),
ce module lit les VRAIES tables sources, confirmées par l'utilisateur à
partir de la requête SQL de génération réellement utilisée côté base :

  - [TECH_BI].[dbo].[SRC_TDBPART1]  (primes, commissions, adhésions)
  - [TECH_BI].[dbo].[SRC_TDBPART2]  (tranches tarifaires, résiliations)
  - [ICI_BI].[dbo].[FONC_Référentiel programmes] (uniquement pour le
    contrôle Data Quality "contrat sans référentiel" — voir
    app/core/referentiel.py ; Pays/Produit/Régularisation sont désormais
    directement portés par SRC_TDBPART1, plus besoin de les y chercher)

Depuis la v1.8.0 (même scénario que Part1/Part2 : la table supposée
TDB_Sinistres_Agrégés n'existe pas réellement — Invalid object name lors
d'un test sur Recette), les sinistres sont lus depuis la VRAIE table,
confirmée par l'utilisateur :

  - [TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu] : une table au
    niveau du sinistre BRUT (un sinistre par ligne), et non plus
    pré-agrégée par contrat/période comme le supposait l'ancienne table
    TDB_Sinistres_Agrégés. Seules les colonnes nécessaires au regroupement
    métier sont rapatriées (jamais Nom_Client/Nom_Magasin, données
    personnelles non utilisées par l'application — choix volontaire de
    minimisation des données, non une omission) :
      - Numero_Police      : rattachement au contrat (= identifiant_contrat
        de SRC_TDBPART1, confirmé par l'utilisateur)
      - Date_Souscription_Adhesion : rattachement à la période ; comparée en
        année+mois à date_debut_periode_souscription de SRC_TDBPART1 (une
        égalité stricte de date ne matcherait presque jamais, cf.
        app/core/aggregation.py)
      - Statut_Technique_Sinistre  : mappé vers les 4 catégories
        (Accepté/Refusé/En cours/Inconnu) via app/config/status_mapping.py
      - Montant_Total_Reglement    : montant de règlement (Montant_Total_Reglement_FR
        existe aussi dans la table mais n'est PAS utilisé, sur confirmation
        explicite de l'utilisateur)
  Le regroupement par contrat+période (comptages/montants par statut) est
  entièrement fait côté Python dans app.core.aggregation, puisque cette
  table n'est plus pré-agrégée côté SQL.

Les noms de colonnes Python (clés des dict retournés) reproduisent
EXACTEMENT les noms de colonnes réels de SRC_TDBPART1/SRC_TDBPART2
(minuscules, snake_case) plutôt que de les traduire vers d'anciens noms
supposés — afin qu'une requête SQL ad hoc et le code Python se lisent de la
même façon, et que toute divergence future avec la vraie base saute aux
yeux immédiatement.

Contrairement au SQL de référence, ce provider ne recalcule RIEN côté
serveur : il rapatrie les colonnes sources brutes, et c'est
app.core.aggregation.build_profitability_dataset qui applique toutes les
règles métier. Cela garantit un seul et unique moteur de règles, testé une
seule fois (§19 : logique jamais dispersée).

SÉCURITÉ (§21) :
  - Aucun identifiant ni mot de passe codé en dur : tout vient de
    app.config.settings.SqlServerConfig (variables d'environnement / .env).
  - Toutes les requêtes sont paramétrées (placeholders "?" pyodbc) —
    aucune concaténation de chaîne avec une valeur utilisateur.
  - Les erreurs de connexion sont interceptées et journalisées sans jamais
    exposer les identifiants dans les messages remontés à l'UI.
"""
from __future__ import annotations

import logging
from typing import Any

from app.config.settings import SqlServerConfig
from app.data.provider import DataProvider

logger = logging.getLogger("profitabilitytools.sqlserver")

# Délai maximal (secondes) pour l'EXÉCUTION d'une requête de lecture — distinct
# de PROFITABILITY_DB_TIMEOUT (connexion initiale, voir app/config/settings.py).
# Volontairement généreux : une table comme SRC_Sinistre_Transformer_Contenu
# (~1,3M lignes) peut légitimement prendre plusieurs minutes selon le réseau et
# la charge du serveur ; ce délai sert uniquement de garde-fou contre un
# blocage réellement infini (verrou SQL Server, connexion coupée sans reset),
# pas à accélérer un chargement simplement lent (v1.8.2).
_QUERY_TIMEOUT_SECONDS = 300

# --- TECH_BI.dbo.SRC_TDBPART1 (confirmé par l'utilisateur, v1.7.0) ---------
_PART1_COLUMNS = [
    "identifiant_contrat", "date_debut_periode_souscription", "date_fin_periode_souscription",
    "regularisation", "pays", "libelle_distributeur", "statut", "libelle_produit",
    "gestionnaire_1", "gestionnaire_2", "courtier_1", "courtier_2", "compagnie",
    "flux_fi", "date_creation_quittance", "code_devise_quittance",
    "nombre_total_adhesions", "montant_total_ht", "montant_total_taxes",
    "montant_total_taxes_1", "montant_total_taxes_2", "montant_total_ttc",
    "remboursement_total_compagnie", "montant_total_commission_distributeur",
    "montant_total_frais_gestion", "montant_total_autres_commissions_1",
    "montant_total_autres_commissions_2", "montant_total_autres_commissions_3",
    "montant_total_net_compagnie", "montant_total_commission_ici",
    "montant_total_prime_assureur", "montant_total_bordereau",
]

# --- TECH_BI.dbo.SRC_TDBPART2 (confirmé par l'utilisateur, v1.7.0) ---------
_PART2_COLUMNS = [
    "identifiant_contrat", "date_debut_periode_souscription", "reference",
    "code_critere_tarifaire_1", "nombre_resiliations",
]

# --- ICI_BI.dbo.[FONC_Référentiel programmes] ------------------------------
# Uniquement pour le contrôle Data Quality "contrat sans référentiel" (le
# reste des attributs référentiels — Pays, Produit, Régularisation — vient
# désormais directement de SRC_TDBPART1). On alias les colonnes réelles
# (dont "N° CONTRAT " contient volontairement un espace final en base) vers
# des noms Python simples.
_REFERENTIEL_SELECT = (
    '[N° CONTRAT ] AS contrat, [DATE_DEBUT] AS date_debut, [DATE_FIN] AS date_fin'
)
_REFERENTIEL_COLUMNS = ["contrat", "date_debut", "date_fin"]

# --- TECH_BI.dbo.SRC_Sinistre_Transformer_Contenu (confirmé par l'utilisateur, v1.8.0) ---
# Table au niveau du sinistre brut — seules les colonnes nécessaires au
# regroupement métier sont rapatriées (voir docstring de module).
_SINISTRES_COLUMNS = [
    "Numero_Police", "Date_Souscription_Adhesion", "Statut_Technique_Sinistre",
    "Montant_Total_Reglement",
]


def _bracket_cols(columns: list[str]) -> str:
    return ", ".join(f"[{c}]" for c in columns)


class SqlServerConnectionError(RuntimeError):
    """Erreur de connexion/exécution SQL Server, sans détail sensible exposé à l'UI."""


class SqlServerDataProvider(DataProvider):
    mode_name = "SQL_SERVER"
    is_demo = False

    def __init__(self, config: SqlServerConfig):
        self._config = config
        self._conn = None
        #: environnement de connexion (RECETTE/PRODUCTION, v1.6.0) —
        #: affiché dans le bandeau d'en-tête (app/ui/main_window.py).
        self.environment = config.environment

    def _connect(self):
        if not self._config.is_configured():
            raise SqlServerConnectionError(
                "Connexion SQL Server non configurée. Renseignez PROFITABILITY_DB_SERVER, "
                "PROFITABILITY_DB_USER et PROFITABILITY_DB_PASSWORD dans .env."
            )
        if self._conn is not None:
            return self._conn
        try:
            import pyodbc  # import local : dépendance optionnelle hors mode DEMO
        except ImportError as exc:  # pragma: no cover
            raise SqlServerConnectionError(
                "Le module pyodbc n'est pas installé (pip install pyodbc)."
            ) from exc

        try:
            self._conn = pyodbc.connect(
                self._config.odbc_connection_string(),
                timeout=self._config.timeout_seconds,
            )
            # v1.8.2 : délai distinct, plus généreux, pour l'EXÉCUTION des
            # requêtes (voir _fetch_all ci-dessous pour le contexte complet).
            # Correctif v1.10.3 : ce délai doit être affecté à la CONNEXION
            # (pyodbc.Connection.timeout, l'API réellement exposée par
            # pyodbc pour ceci), jamais au curseur — `cursor.timeout = ...`
            # levait "'pyodbc.Cursor' object has no attribute 'timeout' and
            # no __dict__ for setting new attributes" dès la première
            # requête réelle sur SQL Server, car pyodbc.Cursor est un type
            # C qui n'autorise aucun attribut arbitraire. Resté invisible
            # jusqu'ici faute de connexion SQL Server réelle disponible
            # pour tester ce chemin (le faux pyodbc utilisé par les tests
            # de l'écran Settings n'exerce que la connexion, pas l'exécution
            # d'une requête — voir tests/test_sqlserver_provider.py, qui
            # comble cette lacune avec un faux curseur qui refuse, lui
            # aussi, tout attribut non prévu).
            self._conn.timeout = _QUERY_TIMEOUT_SECONDS
        except Exception as exc:  # pyodbc.Error non importé pour rester optionnel
            logger.error(
                "Échec de connexion SQL Server (serveur=%s, base=%s) : %s",
                self._config.server, self._config.database_ici_bi, exc,
                exc_info=True,
            )
            raise SqlServerConnectionError(
                "Impossible de se connecter à SQL Server "
                f"({self._config.server} / {self._config.database_ici_bi}). "
                f"Détail technique : {exc}\n\n"
                "Vérifiez l'adresse du serveur, le pilote ODBC, les paramètres réseau/pare-feu "
                "et les droits d'accès (le détail complet est aussi journalisé dans "
                "profitabilitytools_error.log)."
            ) from exc
        return self._conn

    def _fetch_all(self, query: str, columns: list[str], params: tuple = ()) -> list[dict[str, Any]]:
        """Exécute la requête et renvoie toutes les lignes sous forme de
        dicts.

        v1.8.0 : lit par lots (`cursor.fetchmany()`) et construit les dicts
        au fur et à mesure, plutôt que `cursor.fetchall()` suivi d'une
        compréhension de liste séparée — cette dernière approche garde
        temporairement DEUX copies complètes du résultat en mémoire en même
        temps (la liste brute de lignes pyodbc, puis la liste de dicts
        construite par-dessus), ce qui double inutilement le pic mémoire.
        Sur une table volumineuse comme `SRC_Sinistre_Transformer_Contenu`
        (~1,3M lignes), ce doublement du pic contribuait à un risque de
        plantage silencieux (manque de mémoire, sans exception Python
        interceptable — voir app/ui/state.py::AppState.reload())."""
        conn = self._connect()
        # v1.8.2 : jusqu'ici, PROFITABILITY_DB_TIMEOUT ne bornait que la
        # connexion initiale (pyodbc.connect(timeout=...)) — l'EXÉCUTION
        # d'une requête, elle, pouvait rester bloquée indéfiniment (réseau
        # lent, verrou SQL Server, table sous charge), ce qui se manifeste
        # comme une application figée sans aucun message. On borne aussi
        # l'exécution, mais avec un délai bien plus généreux que le timeout
        # de connexion (_QUERY_TIMEOUT_SECONDS, pas self._config.timeout_seconds,
        # pensé pour un simple handshake) : une table de plus d'un million de
        # lignes comme SRC_Sinistre_Transformer_Contenu peut légitimement
        # prendre plus de 30s à rapatrier, et il ne faut pas transformer un
        # chargement lent mais qui aurait réussi en échec artificiel. Affecté
        # à la connexion dans _connect() (voir le correctif v1.10.3 détaillé
        # là-bas) — PAS au curseur, qui ne supporte pas cet attribut.
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)  # requête paramétrée — jamais de concaténation
            col_names = [d[0] for d in cursor.description]
            result: list[dict[str, Any]] = []
            while True:
                batch = cursor.fetchmany(5000)
                if not batch:
                    break
                result.extend(dict(zip(col_names, row)) for row in batch)
            return result
        except Exception as exc:
            logger.error(
                "Erreur d'exécution de requête SQL Server sur les colonnes %s : %s",
                columns, exc, exc_info=True,
            )
            raise SqlServerConnectionError(
                f"Erreur lors de l'interrogation de SQL Server. Détail technique : {exc}\n\n"
                "(le détail complet est aussi journalisé dans profitabilitytools_error.log)."
            ) from exc
        finally:
            cursor.close()

    def fetch_part1_rows(self) -> list[dict[str, Any]]:
        query = f"SELECT {_bracket_cols(_PART1_COLUMNS)} FROM [{self._config.database_tech_bi}].[dbo].[SRC_TDBPART1]"
        return self._fetch_all(query, _PART1_COLUMNS)

    def fetch_referentiel_rows(self) -> list[dict[str, Any]]:
        query = (
            f"SELECT {_REFERENTIEL_SELECT} "
            f"FROM [{self._config.database_ici_bi}].[dbo].[FONC_Référentiel programmes]"
        )
        return self._fetch_all(query, _REFERENTIEL_COLUMNS)

    def fetch_part2_rows(self) -> list[dict[str, Any]]:
        query = f"SELECT {_bracket_cols(_PART2_COLUMNS)} FROM [{self._config.database_tech_bi}].[dbo].[SRC_TDBPART2]"
        return self._fetch_all(query, _PART2_COLUMNS)

    def fetch_sinistres_rows(self) -> list[dict[str, Any]]:
        query = (
            f"SELECT {_bracket_cols(_SINISTRES_COLUMNS)} "
            f"FROM [{self._config.database_tech_bi}].[dbo].[SRC_Sinistre_Transformer_Contenu]"
        )
        return self._fetch_all(query, _SINISTRES_COLUMNS)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None


def build_provider_from_env() -> DataProvider:
    """Fabrique le provider SQL Server pour l'environnement actif
    (PROFITABILITY_ACTIVE_ENV — Recette/Production, .env, §20 ; profil
    "Local" retiré en v1.10.4 à la demande explicite de l'utilisateur).

    Depuis la v1.6.0, sur demande explicite de l'utilisateur, le mode DEMO
    a été retiré de l'application : celle-ci fonctionne désormais
    exclusivement avec une connexion SQL Server réelle. Si aucun des deux
    environnements n'est encore configuré, le provider est tout de même
    construit (is_configured() sera False) — AppState.reload() intercepte
    proprement l'échec de connexion qui en résulte et l'affiche à l'écran
    plutôt que de faire planter l'application (voir app/ui/state.py)."""
    from app.config.settings import get_sql_config

    return SqlServerDataProvider(get_sql_config())
