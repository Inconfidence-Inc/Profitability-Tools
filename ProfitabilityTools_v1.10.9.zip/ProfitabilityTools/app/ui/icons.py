"""Icône / logo de l'application (demande utilisateur : « un petit logo »).

Le chemin des ressources est résolu pour fonctionner aussi bien en
exécution depuis les sources (`python -m app.main`) que depuis
l'exécutable autonome construit par PyInstaller (`build_exe.bat`, qui
embarque `app/assets/` via `--add-data` et extrait tout sous
`sys._MEIPASS` à l'exécution) — jamais de chemin en dur vers le poste de
développement.
"""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QPixmap

_ASSETS_DIRNAME = "assets"


def _assets_dir() -> Path:
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        return Path(meipass) / "app" / _ASSETS_DIRNAME
    return Path(__file__).resolve().parent.parent / _ASSETS_DIRNAME


def app_icon() -> QIcon:
    """Icône complète de l'application (fenêtre, barre des tâches,
    Alt+Tab) — toutes les résolutions utiles sont embarquées dans
    app/assets/logo.ico. Repli sur le PNG, puis sur une icône vide
    (jamais d'exception : l'absence de logo ne doit jamais empêcher
    l'application de démarrer)."""
    assets = _assets_dir()
    ico_path = assets / "logo.ico"
    if ico_path.exists():
        return QIcon(str(ico_path))
    png_path = assets / "logo.png"
    if png_path.exists():
        return QIcon(str(png_path))
    return QIcon()


def logo_pixmap(size: int = 28) -> QPixmap:
    """Petit logo pour l'en-tête de l'application, mis à l'échelle
    proprement (lissage activé) à la taille demandée. Retourne un
    QPixmap nul (silencieusement) si le fichier est introuvable."""
    png_path = _assets_dir() / "logo.png"
    if not png_path.exists():
        return QPixmap()
    pixmap = QPixmap(str(png_path))
    if pixmap.isNull():
        return pixmap
    return pixmap.scaled(
        size,
        size,
        Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )
