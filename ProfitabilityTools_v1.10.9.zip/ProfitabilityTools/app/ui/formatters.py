"""Formatage d'affichage (montants, dates) — jamais utilisé pour les calculs,
uniquement pour le rendu (cahier des charges §15 : "formatage monétaire",
"formatage des dates")."""
from __future__ import annotations

from decimal import Decimal


def format_money(value: Decimal | None, devise: str = "") -> str:
    if value is None:
        return "—"
    try:
        sign = "-" if value < 0 else ""
        value = abs(value)
        integral = int(value)
        cents = int((value - integral) * 100)
        integral_str = f"{integral:,}".replace(",", " ")
        suffix = f" {devise}" if devise else ""
        return f"{sign}{integral_str},{cents:02d}{suffix}"
    except (ValueError, TypeError, ArithmeticError):
        # Défense en profondeur (v1.8.2) : une valeur numérique malformée
        # (ex. Decimal("NaN")/Infinity renvoyée par une source inattendue)
        # ne doit jamais faire planter le rendu d'un tableau entier — en
        # amont, app/core/money.py garantit déjà un Decimal propre ou None
        # dans le flux normal, ceci n'est qu'un filet supplémentaire.
        return str(value)


def format_int(value) -> str:
    if value is None:
        return "—"
    try:
        return f"{int(value):,}".replace(",", " ")
    except (ValueError, TypeError):
        return str(value)


def format_percent(value: Decimal | None, decimals: int = 1) -> str:
    if value is None:
        return "—"
    try:
        pct = value * 100
        return f"{pct:.{decimals}f}%"
    except (ValueError, TypeError, ArithmeticError):
        return str(value)  # v1.8.2 : même filet défensif que format_money


def format_date_fr(raw: str | None) -> str:
    """La date source est déjà au format métier dd/MM/yyyy — affichage tel quel."""
    return raw or "—"
