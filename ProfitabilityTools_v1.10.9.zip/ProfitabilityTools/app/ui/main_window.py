"""Fenêtre principale ProfitabilityTools (cahier des charges §18) : sidebar
de navigation, header, bandeau DEMO, barre de filtres globale, pages.

v1.10.0 : reçoit désormais le compte connecté (`current_user`, voir
app/auth/) pour afficher qui est connecté dans le header, proposer le
changement de mot de passe et la déconnexion, et n'ajouter l'écran
« Utilisateurs » à la navigation que pour le rôle Administrateur — seule
restriction d'écran par rôle de cette version (décision explicite de
l'utilisateur : aucune autre page n'est restreinte par rôle)."""
from __future__ import annotations

from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QFrame, QGraphicsDropShadowEffect, QHBoxLayout, QLabel,
    QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPushButton,
    QStackedWidget, QVBoxLayout, QWidget,
)

from app.data.provider import DataProvider
from app.ui.pages.claims_page import ClaimsPage
from app.ui.pages.contracts_page import ContractsPage
from app.ui.pages.dashboard_page import DashboardPage
from app.ui.pages.data_quality_page import DataQualityPage
from app.ui.pages.explorer_page import ExplorerPage
from app.ui.pages.settings_page import SettingsPage
from app.ui.pages.users_page import UsersPage
from app.ui.icons import app_icon, logo_pixmap
from app.ui.state import AppState
from app.ui.theme import build_stylesheet, palette_for
from app.ui.widgets.filter_bar import FilterBar

_NAV_ITEMS_BASE = ["Dashboard", "Profitability Explorer", "Contracts", "Claims", "Data Quality", "Settings"]
_NAV_UTILISATEURS = "Utilisateurs"


class MainWindow(QMainWindow):
    def __init__(
        self,
        provider: DataProvider,
        theme: str = "light",
        current_user=None,
        on_logout: Callable[[], None] | None = None,
    ):
        super().__init__()
        self.setWindowTitle("ProfitabilityTools — ICI Assurance")
        self.setWindowIcon(app_icon())
        self.resize(1440, 900)

        # Compte applicatif connecté (auth_partage.service.CurrentUser) —
        # voir app/auth/. Peut être None uniquement dans les tests qui
        # construisent MainWindow sans passer par le flux de connexion de
        # app/main.py ; le header s'adapte silencieusement dans ce cas
        # (pas de régression pour les tests existants écrits avant v1.10.0).
        self.current_user = current_user
        self._on_logout = on_logout

        from auth_partage.service import AuthService

        self._auth = AuthService()
        self._is_admin = bool(
            current_user is not None
            and self._auth.can(current_user.role, "utilisateurs")
        )
        self._nav_items = list(_NAV_ITEMS_BASE)
        if self._is_admin:
            self._nav_items.append(_NAV_UTILISATEURS)

        self._state = AppState(provider, theme=theme)
        self._state.loadError.connect(self._on_load_error)
        self._state.dataModeChanged.connect(lambda _m: self._update_env_badge())
        self._state.themeChanged.connect(self._apply_theme)

        central = QWidget(self)
        self.setCentralWidget(central)
        root_layout = QHBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # --- Sidebar ---------------------------------------------------
        self._sidebar = QListWidget(self)
        self._sidebar.setObjectName("Sidebar")
        self._sidebar.setFixedWidth(220)
        for name in self._nav_items:
            QListWidgetItem(name, self._sidebar)
        self._sidebar.currentRowChanged.connect(self._on_nav_changed)
        root_layout.addWidget(self._sidebar)

        # --- Right side (header + filters + pages) ----------------------
        right = QWidget(self)
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        root_layout.addWidget(right, stretch=1)

        right_layout.addWidget(self._build_header())

        self._filter_bar = FilterBar(self._state, self)
        right_layout.addWidget(self._filter_bar)

        self._stack = QStackedWidget(self)
        right_layout.addWidget(self._stack, stretch=1)

        self._explorer_page = ExplorerPage(self._state, on_open_contract=self._open_contract)
        self._contracts_page = ContractsPage(self._state)
        self._pages = {
            "Dashboard": DashboardPage(self._state),
            "Profitability Explorer": self._explorer_page,
            "Contracts": self._contracts_page,
            "Claims": ClaimsPage(self._state),
            "Data Quality": DataQualityPage(self._state),
            "Settings": SettingsPage(self._state, current_user=self.current_user),
        }
        if self._is_admin:
            self._pages[_NAV_UTILISATEURS] = UsersPage(self.current_user)
        for name in self._nav_items:
            self._stack.addWidget(self._pages[name])

        self._sidebar.setCurrentRow(0)
        self._apply_theme(theme)
        self._update_env_badge()
        self._state.reload()

    def _build_header(self) -> QWidget:
        header = QFrame(self)
        header.setObjectName("Header")
        header.setFixedHeight(56)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(20, 0, 20, 0)

        logo = QLabel(header)
        logo.setObjectName("HeaderLogo")
        logo_pix = logo_pixmap(28)
        if not logo_pix.isNull():
            logo.setPixmap(logo_pix)
            layout.addWidget(logo)

        title = QLabel("ProfitabilityTools", header)
        title.setObjectName("HeaderTitle")
        layout.addWidget(title)

        # Bandeau d'environnement (v1.6.0) : indique toujours à quelle base
        # SQL Server on est connecté (Recette / Production) —
        # remplace l'ancien bandeau "MODE DÉMONSTRATION" (mode DEMO retiré de
        # l'application sur demande explicite de l'utilisateur). Colorié en
        # rouge d'alerte pour Production afin de limiter le risque de
        # modifier/valider quelque chose en pensant être sur Recette.
        self._env_badge = QLabel("", header)
        self._env_badge.setObjectName("EnvBadge")
        layout.addWidget(self._env_badge)

        layout.addStretch(1)

        # Compte connecté + actions (v1.10.0) — indépendant du badge
        # d'environnement ci-dessus : l'un concerne la base métier
        # (ICI_BI/TECH_BI), l'autre le compte applicatif ProfitabilityTools
        # (voir app/auth/). Masqué si MainWindow est construite sans compte
        # (tests existants antérieurs à v1.10.0).
        if self.current_user is not None:
            user_label = QLabel(
                f"{self.current_user.nom_complet or self.current_user.login} "
                f"({self.current_user.role})",
                header,
            )
            user_label.setProperty("class", "Muted")
            layout.addWidget(user_label)

            btn_mdp = QPushButton("Changer mon mot de passe", header)
            btn_mdp.clicked.connect(self._on_change_password)
            layout.addWidget(btn_mdp)

            btn_logout = QPushButton("Déconnexion", header)
            btn_logout.clicked.connect(self._on_logout_clicked)
            layout.addWidget(btn_logout)

        return header

    def _on_change_password(self) -> None:
        from auth_partage.ui.mot_de_passe import ChangementMotDePasseDialog

        boite = ChangementMotDePasseDialog(self.current_user, impose=False, parent=self)
        boite.exec()

    def _on_logout_clicked(self) -> None:
        reponse = QMessageBox.question(
            self, "Déconnexion",
            "Se déconnecter de ProfitabilityTools ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reponse != QMessageBox.StandardButton.Yes:
            return
        if self.current_user is not None:
            try:
                self._auth.tracer_deconnexion(self.current_user.login, "déconnexion manuelle")
            except Exception:  # noqa: BLE001 - la trace ne doit jamais bloquer la déconnexion
                pass
        if self._on_logout is not None:
            self._on_logout()
        self.close()

    def _update_env_badge(self) -> None:
        from app.config.settings import ENVIRONMENT_LABELS

        env = getattr(self._state.provider, "environment", "") or ""
        label = ENVIRONMENT_LABELS.get(env, env)
        self._env_badge.setText(f"ENVIRONNEMENT : {label.upper()}" if label else "")
        self._env_badge.setVisible(bool(label))
        self._env_badge.setObjectName("EnvBadgeProd" if env == "PRODUCTION" else "EnvBadge")
        self._env_badge.style().unpolish(self._env_badge)
        self._env_badge.style().polish(self._env_badge)

    def _apply_theme(self, mode: str) -> None:
        palette = palette_for(mode)
        self.setStyleSheet(build_stylesheet(palette))
        self._apply_elevation(palette)

    def _apply_elevation(self, palette: dict) -> None:
        """Élévation Material Design réelle (ombre portée) sur les cartes et
        le bandeau supérieur — le QSS seul ne permet pas de box-shadow, donc
        on applique un QGraphicsDropShadowEffect par widget concerné.
        Centralisé ici (plutôt que dans chaque page) : toutes les pages sont
        déjà construites à ce stade (voir __init__), qu'elles soient
        actuellement visibles ou non dans le QStackedWidget."""
        shadow_rgba = palette.get("shadow_color", (0, 0, 0, 60))
        shadow_color = QColor(*shadow_rgba)

        def _shadow(blur: int, y_offset: int) -> QGraphicsDropShadowEffect:
            effect = QGraphicsDropShadowEffect()
            effect.setBlurRadius(blur)
            effect.setXOffset(0)
            effect.setYOffset(y_offset)
            effect.setColor(shadow_color)
            return effect

        for frame in self.findChildren(QFrame):
            if frame.property("class") == "Card":
                frame.setGraphicsEffect(_shadow(blur=18, y_offset=2))

        header = self.findChild(QFrame, "Header")
        if header is not None:
            header.setGraphicsEffect(_shadow(blur=12, y_offset=1))

    def _on_nav_changed(self, row: int) -> None:
        self._stack.setCurrentIndex(row)

    def _open_contract(self, contract_id: str) -> None:
        self._sidebar.setCurrentRow(self._nav_items.index("Contracts"))
        self._contracts_page._search.setText(contract_id)

    def _on_load_error(self, message: str) -> None:
        QMessageBox.warning(
            self,
            "Chargement des données",
            f"Une erreur est survenue lors du chargement des données :\n\n{message}",
        )
