"""Filet de sécurité local pour les rafraîchissements de page (v1.8.2).

Contexte (voir aussi app/main.py::_install_global_excepthook et
app/ui/state.py::AppState.reload()) : le filet GLOBAL empêche déjà toute
exception Python non interceptée de fermer brutalement l'application —
mais il le fait en affichant une boîte de dialogue MODALE et BLOQUANTE.
Si le même problème se reproduit à chaque signal (changement de filtre,
rechargement), par exemple parce qu'une donnée réelle inhabituelle fait
planter le rendu d'un écran de façon déterministe, l'utilisateur se
retrouve avec une dialogue à répéter à chaque interaction — l'application
ne "s'arrête" pas, mais devient inutilisable.

``guarded_refresh`` protège l'exécution du rafraîchissement d'UNE page :
en cas d'exception, elle est journalisée (profitabilitytools_error.log,
comme le reste de l'application) et un message discret, NON BLOQUANT,
remplace le contenu de cette page — les autres écrans et le reste de
l'application continuent de fonctionner normalement."""
from __future__ import annotations

import logging
from typing import Callable

from PySide6.QtWidgets import QLabel, QLayout, QWidget

logger = logging.getLogger("profitabilitytools.ui")


def guarded_call(
    body: Callable[[], None],
    page_name: str,
    on_error: Callable[[Exception], None] | None = None,
) -> None:
    """Variante de ``guarded_refresh`` pour une page qui n'utilise pas le
    schéma générique ``layout``/``clear()`` (widgets fixes construits une
    fois dans ``__init__``, mis à jour en place — ex. Profitability
    Explorer). ``on_error`` reçoit l'exception pour, par exemple, afficher
    un message dans un label déjà existant plutôt que de reconstruire la
    page ; son absence équivaut à journaliser seulement."""
    try:
        body()
    except Exception as exc:  # noqa: BLE001 - jamais remonter plus haut depuis ici
        logger.exception("Échec du rafraîchissement de l'écran %s", page_name)
        if on_error is not None:
            try:
                on_error(exc)
            except Exception:  # noqa: BLE001 - le filet lui-même ne doit jamais lever
                pass


def guarded_refresh(
    layout: QLayout,
    clear: Callable[[], None],
    body: Callable[[], None],
    page_name: str,
) -> None:
    """Exécute ``body()`` (le rafraîchissement réel d'une page). En cas
    d'exception : journalise, vide ``layout`` via ``clear()``, puis y
    affiche un message d'erreur discret au lieu de laisser l'exception
    remonter jusqu'au filet de sécurité global (boîte de dialogue
    bloquante, répétée à chaque signal si le problème est déterministe)."""
    try:
        body()
    except Exception as exc:  # noqa: BLE001 - jamais remonter plus haut depuis ici
        logger.exception("Échec du rafraîchissement de l'écran %s", page_name)
        try:
            clear()
            msg = QLabel(
                f"Une erreur est survenue lors de l'affichage de l'écran « {page_name} ».\n"
                "L'application reste utilisable — essayez de changer les filtres ou de "
                "recharger les données. Détail journalisé dans profitabilitytools_error.log.\n\n"
                f"{type(exc).__name__}: {exc}"
            )
            msg.setWordWrap(True)
            msg.setProperty("class", "Muted")
            layout.addWidget(msg)
        except Exception:  # noqa: BLE001 - le filet lui-même ne doit jamais lever
            pass
