"""Augmente l'écran de connexion fourni par auth_partage (LoginDialog) d'un
accès à la configuration du serveur OUTILS (v1.10.2).

Pourquoi ici plutôt que dans auth_partage/ui/connexion.py
-----------------------------------------------------------
`auth_partage.ui.connexion.LoginDialog` reste volontairement une copie
fidèle du module partagé (à l'exception du correctif de bug du v1.10.0,
voir son propre commentaire) : il ne connaît rien de ConnexionOutilsDialog,
qui est propre à ProfitabilityTools, et ça doit rester ainsi pour que le
module reste réutilisable tel quel par les autres applications du parc. Ce
fichier-ci ajoute donc le bouton par COMPOSITION (on complète la mise en
page déjà construite par LoginDialog depuis l'extérieur), pas en modifiant
le module partagé.

Pourquoi ce bouton est nécessaire (v1.10.2)
---------------------------------------------
Signalé par l'utilisateur : tant qu'OUTILS n'est pas configuré sur le
poste, un compte qui n'existe QUE dans OUTILS (créé par un administrateur
directement en base, ou habilité sur une autre application du parc) ne
peut tout simplement pas s'authentifier — l'application ne consulte encore
que son repli local SQLite. Jusqu'ici, configurer OUTILS exigeait de se
connecter d'abord (avec le compte administrateur amorcé localement,
voir app/auth/setup.py::BOOTSTRAP_LOGIN) puis d'aller sur Settings — un
détour peu évident, qui suppose de connaître ce compte de secours. Ce
bouton permet de configurer OUTILS directement depuis l'écran de
connexion, AVANT de s'authentifier — symétrique de l'accès déjà ajouté sur
Settings (v1.10.1), qui reste la voie normale une fois connecté."""
from __future__ import annotations

from PySide6.QtWidgets import QFrame, QLabel, QPushButton, QVBoxLayout


def build_login_dialog(sous_titre: str = ""):
    """Construit le LoginDialog d'auth_partage, complété du bouton de
    connexion au serveur OUTILS. Retourne l'instance, prête pour exec()."""
    from auth_partage.ui.connexion import LoginDialog

    boite = LoginDialog(sous_titre=sous_titre)
    _habiller(boite)
    return boite


def _habiller(boite) -> None:
    from app.config.settings import get_app_settings
    from app.ui.theme import build_stylesheet, palette_for

    # L'application n'a encore appliqué aucune feuille de style à ce stade
    # (MainWindow, qui s'en charge normalement, n'existe pas encore tant
    # qu'on n'est pas connecté) — sans ceci, ce dialogue ET la boîte
    # « Connexion OUTILS » qu'il ouvre s'afficheraient avec le rendu Qt
    # natif non thémé, en rupture avec le reste de l'application.
    try:
        theme = get_app_settings().theme
    except Exception:  # noqa: BLE001
        theme = "light"
    boite.setStyleSheet(build_stylesheet(palette_for(theme)))

    layout = boite.layout()
    if layout is None:
        return

    separateur = QFrame()
    separateur.setFrameShape(QFrame.Shape.HLine)
    layout.addWidget(separateur)

    statut = QLabel("")
    statut.setWordWrap(True)
    statut.setProperty("class", "Muted")
    layout.addWidget(statut)

    def _rafraichir_statut() -> None:
        from app.auth.setup import configure_auth

        try:
            configure_auth()  # idempotent — requis avant auth_partage.description()
            from auth_partage import description as auth_description

            statut.setText(auth_description())
        except Exception as exc:  # noqa: BLE001 - ne doit jamais bloquer l'écran
            statut.setText(f"État de la connexion indisponible : {exc}")

    _rafraichir_statut()

    bouton = QPushButton("Connexion au serveur (OUTILS)…")
    bouton.setToolTip(
        "Configurer le serveur SQL Server qui porte les comptes "
        "ProfitabilityTools (base OUTILS, partagée avec les autres "
        "applications du parc) — nécessaire si votre compte n'existe que "
        "sur ce serveur et pas encore dans le repli local de ce poste."
    )
    bouton.clicked.connect(lambda: _ouvrir_connexion_outils(boite, _rafraichir_statut))
    layout.addWidget(bouton)


def _ouvrir_connexion_outils(parent, on_closed) -> None:
    from app.config.settings import get_app_settings
    from app.ui.dialogs.connexion_outils_dialog import ConnexionOutilsDialog

    try:
        theme = get_app_settings().theme
    except Exception:  # noqa: BLE001
        theme = "light"
    boite = ConnexionOutilsDialog(theme=theme, parent=parent)
    boite.exec()
    # Enregistrée ou non (Annuler, ou « Tester » sans enregistrer), l'état
    # affiché doit toujours refléter la réalité du profil sur ce poste.
    on_closed()
