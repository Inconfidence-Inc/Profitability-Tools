"""Écran « Connexion OUTILS » (v1.10.0) — configuration de la base centrale
d'authentification (comptes ProfitabilityTools, partagés avec le reste du
parc via auth_partage).

Adapté de l'écran équivalent d'Orchestrator
(bordereaux/views/dialogue_serveur_auth.py) : même logique, mêmes appels au
module partagé (`construire_url_mssql`, `tester`, `enregistrer_profil`) —
seul l'habillage change, pour reprendre le thème Material de
ProfitabilityTools plutôt que celui d'Orchestrator.

IMPORTANT — sans rapport avec les profils SQL Server métier (Settings) :
cet écran configure UNIQUEMENT la connexion à la base OUTILS qui porte les
comptes applicatifs (USERS_PYTHON / USERS_PYTHON_HISTO). La connexion aux
données métier (ICI_BI / TECH_BI, profils Local/Recette/Production) reste
gérée séparément sur l'écran Settings existant, inchangé par cette version
(décision explicite de l'utilisateur : systèmes totalement indépendants)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QSpinBox, QVBoxLayout, QApplication,
)

import auth_partage
from app.auth.setup import configure_auth
from app.ui.theme import palette_for


class ConnexionOutilsDialog(QDialog):
    """Saisie et enregistrement du profil de connexion à OUTILS.

    `theme` : "light" ou "dark" (palette Material de ProfitabilityTools,
    voir app/ui/theme.py) — purement cosmétique, sans incidence sur la
    logique de connexion elle-même."""

    def __init__(self, theme: str = "light", parent=None):
        super().__init__(parent)
        self._palette = palette_for(theme)
        self.setWindowTitle("Connexion OUTILS — ProfitabilityTools")
        self.setMinimumWidth(640)
        self._construire()

    # ------------------------------------------------------------------ #
    def _construire(self) -> None:
        p = self._palette
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(12)

        intro = QLabel(
            "Base centrale qui porte les comptes ProfitabilityTools "
            "(USERS_PYTHON et USERS_PYTHON_HISTO), partagée avec les "
            "autres applications du parc. Ce n'est PAS la base métier "
            "(ICI_BI / TECH_BI) configurée sur l'écran Settings."
        )
        intro.setWordWrap(True)
        intro.setProperty("class", "Muted")
        lay.addWidget(intro)

        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)
        grid.setColumnStretch(1, 1)
        row = 0

        def champ(libelle: str, widget) -> object:
            nonlocal row
            label = QLabel(libelle)
            label.setProperty("class", "Muted")
            grid.addWidget(label, row, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            grid.addWidget(widget, row, 1)
            row += 1
            return widget

        self._f_serveur = champ("Serveur", QLineEdit())
        self._f_serveur.setPlaceholderText("ex : 4.233.146.115")

        self._f_port = QSpinBox()
        self._f_port.setRange(1, 65535)
        self._f_port.setValue(1433)
        self._f_port.setMaximumWidth(120)
        champ("Port", self._f_port)

        self._f_base = champ("Base", QLineEdit("OUTILS"))

        self._f_auth = QComboBox()
        from auth_partage.connexion_mssql import MODES_AUTH
        for cle in sorted(MODES_AUTH):
            self._f_auth.addItem(MODES_AUTH[cle], cle)
        champ("Authentification", self._f_auth)

        self._f_user = champ("Utilisateur", QLineEdit())
        self._f_pwd = QLineEdit()
        self._f_pwd.setEchoMode(QLineEdit.EchoMode.Password)
        champ("Mot de passe", self._f_pwd)

        self._f_driver = champ("Pilote ODBC", QLineEdit())
        from auth_partage.connexion_mssql import DRIVER_ODBC_PAR_DEFAUT
        self._f_driver.setPlaceholderText(f"vide = {DRIVER_ODBC_PAR_DEFAUT}")

        chiffrement = QHBoxLayout()
        self._f_chiffrer = QCheckBox("Encrypt (chiffrer la connexion)")
        self._f_chiffrer.setChecked(True)
        self._f_cert = QCheckBox("TrustServerCertificate")
        self._f_cert.setChecked(True)
        self._f_cert.setToolTip(
            "Nécessaire dès que le serveur présente un certificat que ce "
            "poste ne reconnaît pas — cas courant en interne.\n"
            "La connexion reste chiffrée : seule la vérification de "
            "l'autorité émettrice est levée.\n"
            "Sans cette option, le pilote 18 refuse la connexion (08001)."
        )
        chiffrement.addWidget(self._f_chiffrer)
        chiffrement.addWidget(self._f_cert)
        chiffrement.addStretch()
        grid.addWidget(QLabel(""), row, 0)
        grid.addLayout(chiffrement, row, 1)
        row += 1
        lay.addLayout(grid)

        self._lbl_etat = QLabel("")
        self._lbl_etat.setWordWrap(True)
        self._lbl_etat.setProperty("class", "Muted")
        lay.addWidget(self._lbl_etat)

        boutons = QHBoxLayout()
        self._btn_test = QPushButton("Tester")
        self._btn_ok = QPushButton("Enregistrer et activer")
        self._btn_ok.setObjectName("PrimaryButton")
        btn_annuler = QPushButton("Annuler")
        boutons.addWidget(self._btn_test)
        boutons.addStretch()
        boutons.addWidget(btn_annuler)
        boutons.addWidget(self._btn_ok)
        lay.addLayout(boutons)

        self._btn_test.clicked.connect(lambda: self._valider(enregistrer=False))
        self._btn_ok.clicked.connect(lambda: self._valider(enregistrer=True))
        btn_annuler.clicked.connect(self.reject)
        self._f_auth.currentIndexChanged.connect(self._maj_identifiants)
        self._maj_identifiants()

    def _maj_identifiants(self) -> None:
        mode = self._f_auth.currentData()
        actif = mode in ("sql", "azure_ad_password")
        self._f_user.setEnabled(actif)
        self._f_pwd.setEnabled(actif)

    # ------------------------------------------------------------------ #
    def _etat(self, texte: str, classe: str) -> None:
        self._lbl_etat.setText(texte)
        self._lbl_etat.setProperty("class", classe)
        self._lbl_etat.style().unpolish(self._lbl_etat)
        self._lbl_etat.style().polish(self._lbl_etat)

    def _valider(self, enregistrer: bool) -> None:
        serveur = self._f_serveur.text().strip()
        if not serveur:
            self._etat("Le serveur est obligatoire.", "ErrorText")
            return
        mode = self._f_auth.currentData()
        if mode in ("sql", "azure_ad_password") and not self._f_user.text().strip():
            self._etat(
                "Un utilisateur est requis pour ce mode d'authentification.",
                "ErrorText",
            )
            return

        # auth_partage refuse de travailler sans configurer() au préalable
        # (sans quoi il chercherait sa clé de chiffrement dans un dossier
        # par défaut et rendrait indéchiffrable un profil déjà enregistré) —
        # idempotent, sans effet de bord si déjà appelé.
        configure_auth()

        try:
            from auth_partage.connexion_mssql import construire_url_mssql

            url = construire_url_mssql(
                serveur=serveur, port=str(self._f_port.value()),
                base=self._f_base.text().strip() or "OUTILS",
                mode=mode,
                utilisateur=self._f_user.text().strip(),
                mot_de_passe=self._f_pwd.text(),
                driver=self._f_driver.text().strip(),
                chiffrer=self._f_chiffrer.isChecked(),
                accepter_certificat=self._f_cert.isChecked(),
            )
        except Exception as exc:  # noqa: BLE001
            self._etat(f"Paramètres invalides : {exc}", "ErrorText")
            return

        self._etat("Connexion en cours…", "Muted")
        self._btn_test.setEnabled(False)
        self._btn_ok.setEnabled(False)
        try:
            QApplication.processEvents()
            ok, message = auth_partage.tester(url)
        except Exception as exc:  # noqa: BLE001
            ok, message = False, f"{type(exc).__name__} : {exc}"
        finally:
            self._btn_test.setEnabled(True)
            self._btn_ok.setEnabled(True)

        if not ok:
            # auth_partage.tester() inclut déjà une piste de résolution
            # déduite du message (certificat, identifiants, base absente,
            # délai...) — voir auth_partage/database.py::_message_avec_piste.
            self._etat(f"Échec : {message}", "ErrorText")
            return

        if not enregistrer:
            self._etat(f"✓ {message} — rien n'a été enregistré.", "SuccessText")
            return

        try:
            base = self._f_base.text().strip() or "OUTILS"
            auth_partage.enregistrer_profil(f"{base} sur {serveur}", "mssql", url)
        except Exception as exc:  # noqa: BLE001
            self._etat(
                f"Connexion réussie mais enregistrement impossible : {exc}",
                "ErrorText",
            )
            return

        self.accept()
