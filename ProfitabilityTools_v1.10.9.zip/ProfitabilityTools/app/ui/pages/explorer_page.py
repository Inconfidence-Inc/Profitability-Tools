"""
Profitability Explorer (cahier des charges §15) : tri, recherche, pagination,
choix des colonnes visibles, regroupement, export CSV/Excel, formatage,
lignes de total, ouverture du détail d'un contrat.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMenu, QMessageBox, QPushButton, QTableView,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QWidgetAction,
)

from app.core.exporters import export_to_csv, export_to_excel
from app.core.kpi import group_sum
from app.core.models import COLUMN_LABELS, MONEY_FIELDS
from app.ui.formatters import format_money
from app.ui.safety import guarded_call
from app.ui.state import AppState
from app.ui.widgets.table_flex import (
    FrozenColumnTableView, enable_flexible_header, sortable_item,
)
from app.ui.widgets.table_model import DEFAULT_VISIBLE_COLUMNS, ProfitabilityTableModel

# Colonne utilisée comme repère figé (v1.9.0, voir FrozenColumnTableView) :
# toujours mise en première position parmi les colonnes choisies par
# l'utilisateur, quel que soit l'ordre dans lequel il les a cochées, pour
# qu'on sache toujours de quel contrat il s'agit en faisant défiler le
# tableau vers la droite.
_ANCHOR_COLUMN = "identifiant_contrat_tdb"


def _anchor_first(columns: list[str]) -> list[str]:
    if _ANCHOR_COLUMN in columns and columns[0] != _ANCHOR_COLUMN:
        return [_ANCHOR_COLUMN] + [c for c in columns if c != _ANCHOR_COLUMN]
    return columns

_PAGE_SIZES = [50, 100, 250, 500, 1000]
_SEARCH_FIELDS = ["identifiant_contrat_tdb", "reference", "compagny", "distributor", "tpa", "eligible_product"]
_GROUP_FIELDS = {
    "Aucun regroupement": None,
    "Compagnie": "compagny",
    "Distributeur": "distributor",
    "TPA": "tpa",
    "Produit": "eligible_product",
    "Contrat": "identifiant_contrat_tdb",
}


class ColumnPickerButton(QPushButton):
    def __init__(self, on_change: Callable[[list[str]], None], parent=None):
        super().__init__("Colonnes", parent)
        self._on_change = on_change
        self._checkboxes: dict[str, QListWidgetItem] = {}
        self._menu = QMenu(self)
        self._list = QListWidget(self._menu)
        self._list.setMinimumWidth(240)
        self._list.setMinimumHeight(320)
        for field, label in COLUMN_LABELS.items():
            item = QListWidgetItem(label, self._list)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                Qt.CheckState.Checked if field in DEFAULT_VISIBLE_COLUMNS else Qt.CheckState.Unchecked
            )
            item.setData(Qt.ItemDataRole.UserRole, field)
            self._checkboxes[field] = item
        self._list.itemChanged.connect(self._emit_change)
        action = QWidgetAction(self._menu)
        action.setDefaultWidget(self._list)
        self._menu.addAction(action)
        self.setMenu(self._menu)

    def _emit_change(self, _item) -> None:
        selected = [
            self._list.item(i).data(Qt.ItemDataRole.UserRole)
            for i in range(self._list.count())
            if self._list.item(i).checkState() == Qt.CheckState.Checked
        ]
        self._on_change(selected)


class ExplorerPage(QWidget):
    def __init__(self, state: AppState, on_open_contract: Callable[[str], None] | None = None, parent=None):
        super().__init__(parent)
        self._state = state
        self._on_open_contract = on_open_contract
        self._page = 0
        self._page_size = 100
        self._columns = _anchor_first(list(DEFAULT_VISIBLE_COLUMNS))
        self._group_field: str | None = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 20)
        outer.addWidget(self._build_toolbar())

        self._model = ProfitabilityTableModel(columns=self._columns)
        self._table = FrozenColumnTableView(self)
        self._table.setModel(self._model)
        self._table.setSortingEnabled(True)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        self._table.doubleClicked.connect(self._on_row_double_clicked)
        enable_flexible_header(self._table)
        outer.addWidget(self._table, stretch=1)

        self._grouped_table = QTableWidget(self)
        self._grouped_table.setVisible(False)
        self._grouped_table.setSortingEnabled(True)
        enable_flexible_header(self._grouped_table)
        outer.addWidget(self._grouped_table, stretch=1)

        self._totals_label = QLabel("")
        self._totals_label.setProperty("class", "Muted")
        outer.addWidget(self._totals_label)

        outer.addWidget(self._build_pagination_bar())

        state.datasetChanged.connect(self._refresh)
        state.filtersChanged.connect(self._refresh)
        self._refresh()

    # ------------------------------------------------------------------ #
    def _build_toolbar(self) -> QWidget:
        bar = QWidget()
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(0, 0, 0, 0)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Recherche (contrat, référence, compagnie, distributeur, TPA, produit)...")
        self._search.textChanged.connect(self._on_search_changed)
        layout.addWidget(self._search, stretch=1)

        self._group_combo = QComboBox()
        self._group_combo.addItems(list(_GROUP_FIELDS.keys()))
        self._group_combo.currentTextChanged.connect(self._on_group_changed)
        layout.addWidget(self._group_combo)

        layout.addWidget(ColumnPickerButton(self._on_columns_changed))

        export_csv_btn = QPushButton("Export CSV")
        export_csv_btn.clicked.connect(self._export_csv)
        layout.addWidget(export_csv_btn)

        export_xlsx_btn = QPushButton("Export Excel")
        export_xlsx_btn.clicked.connect(self._export_excel)
        layout.addWidget(export_xlsx_btn)

        return bar

    def _build_pagination_bar(self) -> QWidget:
        bar = QWidget()
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(0, 0, 0, 0)

        self._page_label = QLabel("")
        layout.addWidget(self._page_label)
        layout.addStretch(1)

        layout.addWidget(QLabel("Lignes par page :"))
        self._page_size_combo = QComboBox()
        self._page_size_combo.addItems([str(n) for n in _PAGE_SIZES])
        self._page_size_combo.setCurrentText(str(self._page_size))
        self._page_size_combo.currentTextChanged.connect(self._on_page_size_changed)
        layout.addWidget(self._page_size_combo)

        prev_btn = QPushButton("◀ Précédent")
        prev_btn.clicked.connect(self._prev_page)
        layout.addWidget(prev_btn)

        next_btn = QPushButton("Suivant ▶")
        next_btn.clicked.connect(self._next_page)
        layout.addWidget(next_btn)

        return bar

    # ------------------------------------------------------------------ #
    def _search_filtered_rows(self) -> list:
        rows = self._state.filtered_rows
        text = self._search.text().strip().lower()
        if not text:
            return rows
        out = []
        for r in rows:
            haystack = " ".join(str(getattr(r, f, "") or "") for f in _SEARCH_FIELDS).lower()
            if text in haystack:
                out.append(r)
        return out

    def _refresh(self) -> None:
        self._page = 0
        self._render()

    def _render(self) -> None:
        # v1.8.2 : cette page a des widgets fixes (pas de layout générique à
        # vider/reconstruire comme les autres écrans) — on protège donc le
        # rendu avec guarded_call plutôt que guarded_refresh (voir
        # app/ui/safety.py), en affichant l'erreur dans le label de
        # pagination déjà existant plutôt que de reconstruire la page.
        guarded_call(self._render_body, "Profitability Explorer", self._show_render_error)

    def _show_render_error(self, exc: Exception) -> None:
        self._page_label.setText(
            f"Erreur d'affichage — voir profitabilitytools_error.log ({type(exc).__name__}: {exc})"
        )

    def _render_body(self) -> None:
        rows = self._search_filtered_rows()

        if self._group_field:
            self._table.setVisible(False)
            self._grouped_table.setVisible(True)
            self._render_grouped(rows)
            self._page_label.setText(f"{len(rows)} ligne(s) avant regroupement")
            self._totals_label.setText("")
            return

        self._table.setVisible(True)
        self._grouped_table.setVisible(False)

        total = len(rows)
        start = self._page * self._page_size
        end = min(start + self._page_size, total)
        page_rows = rows[start:end]

        self._model.set_rows(page_rows)
        self._page_label.setText(
            f"{start + 1 if total else 0}-{end} sur {total} ligne(s)"
        )
        self._update_totals(rows)

    def _update_totals(self, rows) -> None:
        # Totaux calculés sur l'ensemble des lignes filtrées (pas uniquement la page affichée).
        money_cols = [c for c in self._columns if c in MONEY_FIELDS]
        if not money_cols:
            self._totals_label.setText("")
            return
        from decimal import Decimal
        parts = []
        for col in money_cols:
            total = sum((getattr(r, col) or Decimal("0") for r in rows), Decimal("0"))
            parts.append(f"{COLUMN_LABELS.get(col, col)} : {format_money(total)}")
        self._totals_label.setText("Totaux (toutes pages) — " + "  |  ".join(parts))

    def _render_grouped(self, rows) -> None:
        field = _GROUP_FIELDS[self._group_field] if self._group_field in _GROUP_FIELDS else None
        value_fields = ["volumes_primes_ttc", "volumes_primes_ht", "total_com", "montant_total_reglement", "number_of_subscription"]
        grouped = group_sum(rows, field, value_fields)

        headers = [COLUMN_LABELS.get(field, field)] + [COLUMN_LABELS.get(f, f) for f in value_fields]
        self._grouped_table.setSortingEnabled(False)  # désactivé pendant le remplissage (voir Qt docs)
        self._grouped_table.setColumnCount(len(headers))
        self._grouped_table.setRowCount(len(grouped))
        self._grouped_table.setHorizontalHeaderLabels(headers)
        self._grouped_table.verticalHeader().setVisible(False)
        self._grouped_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        for r, (key, sums) in enumerate(grouped):
            self._grouped_table.setItem(r, 0, QTableWidgetItem(key))
            for c, f in enumerate(value_fields, start=1):
                self._grouped_table.setItem(r, c, sortable_item(format_money(sums[f]), sums[f]))
        self._grouped_table.resizeColumnsToContents()
        self._grouped_table.setSortingEnabled(True)

    # --- callbacks --------------------------------------------------------
    def _on_search_changed(self, _text: str) -> None:
        self._page = 0
        self._render()

    def _on_group_changed(self, text: str) -> None:
        self._group_field = text if _GROUP_FIELDS.get(text) else None
        self._render()

    def _on_columns_changed(self, columns: list[str]) -> None:
        self._columns = _anchor_first(columns or list(DEFAULT_VISIBLE_COLUMNS))
        self._model.set_columns(self._columns)
        self._render()

    def _on_page_size_changed(self, text: str) -> None:
        try:
            self._page_size = int(text)
        except ValueError:
            self._page_size = 100
        self._page = 0
        self._render()

    def _prev_page(self) -> None:
        if self._page > 0:
            self._page -= 1
            self._render()

    def _next_page(self) -> None:
        total = len(self._search_filtered_rows())
        if (self._page + 1) * self._page_size < total:
            self._page += 1
            self._render()

    def _on_row_double_clicked(self, index) -> None:
        row = self._model.row_at(index.row())
        if row and self._on_open_contract:
            self._on_open_contract(row.identifiant_contrat_tdb)

    def _export_csv(self) -> None:
        rows = self._search_filtered_rows()
        path, _ = QFileDialog.getSaveFileName(self, "Exporter en CSV", "profitability_explorer.csv", "CSV (*.csv)")
        if not path:
            return
        try:
            export_to_csv(rows, self._columns, path)
            QMessageBox.information(self, "Export CSV", f"{len(rows)} ligne(s) exportée(s) vers :\n{path}")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Export CSV", f"Échec de l'export : {exc}")

    def _export_excel(self) -> None:
        rows = self._search_filtered_rows()
        path, _ = QFileDialog.getSaveFileName(self, "Exporter en Excel", "profitability_explorer.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        try:
            export_to_excel(rows, self._columns, path)
            QMessageBox.information(self, "Export Excel", f"{len(rows)} ligne(s) exportée(s) vers :\n{path}")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Export Excel", f"Échec de l'export : {exc}")
