"""Page Settings (cahier des charges §18, §20-21) : connexion SQL Server par
environnement (Recette / Production, v1.6.0 ; profil "Local" retiré en
v1.10.4), thème clair/sombre.

RÈGLE DE SÉCURITÉ inchangée : aucun identifiant n'est jamais codé en dur.
Les champs ci-dessous éditent le fichier .env local (non versionné) — c'est
strictement équivalent à l'éditer à la main depuis un éditeur de texte, en
plus pratique. Le mot de passe n'est jamais journalisé ni affiché en clair
par défaut.

MULTI-ENVIRONNEMENT (v1.6.0, demande explicite de l'utilisateur ; réduit à
deux profils en v1.10.4, toujours à la demande explicite de l'utilisateur,
qui souhaite que toute connexion passe directement par le serveur) : le
sélecteur "Environnement actif" fait basculer entre deux profils de
connexion complètement indépendants (Recette, Production), chacun
mémorisé sous ses propres clés .env (voir SqlServerConfig.env_keys()).
Changer la sélection recharge dans le formulaire les valeurs déjà
enregistrées pour ce profil — sans jamais écraser l'autre — afin que
les réglages de chaque environnement restent stockés tels quels jusqu'à leur
prochaine modification explicite. Le mode DEMO a été retiré : l'application
fonctionne désormais uniquement avec une connexion SQL Server réelle.
"""
from __future__ import annotations

from PySide6 import __version__ as pyside_version
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFormLayout, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPushButton, QSpinBox, QVBoxLayout, QWidget,
)

from app import __version__ as app_version
from app.config.env_writer import apply_env_updates
from app.config.settings import (
    ENVIRONMENT_LABELS, ENVIRONMENTS, SqlServerConfig, get_app_settings, get_sql_config,
)
from app.data.sqlserver_provider import SqlServerConnectionError, SqlServerDataProvider
from app.ui.state import AppState


def _section(title: str) -> QLabel:
    lbl = QLabel(title)
    lbl.setProperty("class", "SectionTitle")
    return lbl


class SettingsPage(QWidget):
    """`current_user` (v1.10.0) : compte applicatif connecté
    (auth_partage.service.CurrentUser) — nécessaire pour n'afficher la
    section « Authentification » (connexion à la base centrale OUTILS,
    voir app/ui/dialogs/connexion_outils_dialog.py) qu'au rôle
    Administrateur. Correctif v1.10.1 : cette section était absente de la
    livraison v1.10.0, qui construisait ConnexionOutilsDialog mais ne
    l'ouvrait jamais nulle part — un administrateur n'avait donc aucun
    moyen, depuis l'application, de configurer la connexion à OUTILS."""

    def __init__(self, state: AppState, current_user=None, parent=None):
        super().__init__(parent)
        self._state = state
        self._current_user = current_user

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 20)
        outer.setSpacing(18)

        # --- Source de données --------------------------------------------
        outer.addWidget(_section("Source de données"))
        data_card = QFrame()
        data_card.setProperty("class", "Card")
        data_form = QFormLayout(data_card)

        current_env = get_app_settings().active_environment

        self._env_combo = QComboBox()
        for env in ENVIRONMENTS:
            self._env_combo.addItem(ENVIRONMENT_LABELS[env], userData=env)
        self._env_combo.setCurrentIndex(max(0, self._env_combo.findData(current_env)))
        data_form.addRow("Environnement actif :", self._env_combo)

        apply_btn = QPushButton("Appliquer et recharger les données")
        apply_btn.setObjectName("PrimaryButton")
        apply_btn.clicked.connect(self._apply_environment)
        data_form.addRow(apply_btn)

        env_note = QLabel(
            "Chaque environnement (Recette, Production) a sa propre configuration, "
            "enregistrée séparément : basculer d'un environnement à l'autre ne modifie jamais "
            "les réglages de l'autre."
        )
        env_note.setWordWrap(True)
        env_note.setProperty("class", "Muted")
        data_form.addRow(env_note)

        outer.addWidget(data_card)

        # --- Configuration base de données (éditable, persistée dans .env) -
        outer.addWidget(_section("Configuration de la base de données (SQL Server)"))
        db_card = QFrame()
        db_card.setProperty("class", "Card")
        db_form = QFormLayout(db_card)

        cfg = get_sql_config(current_env)

        db_security_note = QLabel(
            "Ces paramètres sont enregistrés uniquement dans le fichier .env local "
            "(non versionné) — jamais codés en dur dans le code source."
        )
        db_security_note.setWordWrap(True)
        db_security_note.setProperty("class", "Muted")
        db_form.addRow(db_security_note)

        self._db_server = QLineEdit(cfg.server)
        self._db_server.setPlaceholderText("mon-serveur-sql.ici-assurance.local")
        db_form.addRow("Serveur :", self._db_server)

        self._db_ici_bi = QLineEdit(cfg.database_ici_bi)
        db_form.addRow("Base ICI_BI :", self._db_ici_bi)

        self._db_tech_bi = QLineEdit(cfg.database_tech_bi)
        db_form.addRow("Base TECH_BI :", self._db_tech_bi)

        self._db_trusted = QCheckBox("Authentification Windows (connexion locale — session actuelle)")
        self._db_trusted.setChecked(cfg.trusted_connection)
        self._db_trusted.setToolTip(
            "Se connecte avec la session Windows courante au lieu d'un identifiant/mot de "
            "passe SQL Server — équivalent de « Windows Authentication » dans SQL Server "
            "Management Studio. Ne fonctionne que si ce compte Windows a des droits sur le "
            "serveur SQL visé."
        )
        self._db_trusted.toggled.connect(self._on_trusted_toggled)
        db_form.addRow(self._db_trusted)

        self._db_user = QLineEdit(cfg.username)
        db_form.addRow("Utilisateur :", self._db_user)

        pwd_row = QHBoxLayout()
        self._db_password = QLineEdit(cfg.password)
        self._db_password.setEchoMode(QLineEdit.EchoMode.Password)
        pwd_row.addWidget(self._db_password)
        show_pwd = QCheckBox("Afficher")
        show_pwd.toggled.connect(
            lambda checked: self._db_password.setEchoMode(
                QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password
            )
        )
        pwd_row.addWidget(show_pwd)
        pwd_container = QWidget()
        pwd_container.setLayout(pwd_row)
        db_form.addRow("Mot de passe :", pwd_container)
        self._on_trusted_toggled(self._db_trusted.isChecked())

        self._db_driver = QLineEdit(cfg.driver)
        db_form.addRow("Pilote ODBC :", self._db_driver)

        adv_row = QHBoxLayout()
        self._db_encrypt = QCheckBox("Chiffrer la connexion (Encrypt)")
        self._db_encrypt.setChecked(cfg.encrypt)
        adv_row.addWidget(self._db_encrypt)
        self._db_trust_cert = QCheckBox("Faire confiance au certificat serveur")
        self._db_trust_cert.setChecked(cfg.trust_server_certificate)
        adv_row.addWidget(self._db_trust_cert)
        adv_container = QWidget()
        adv_container.setLayout(adv_row)
        db_form.addRow(adv_container)

        self._db_timeout = QSpinBox()
        self._db_timeout.setRange(1, 300)
        self._db_timeout.setSuffix(" s")
        self._db_timeout.setValue(cfg.timeout_seconds)
        db_form.addRow("Délai de connexion :", self._db_timeout)

        btn_row = QHBoxLayout()
        test_btn = QPushButton("Tester la connexion")
        test_btn.clicked.connect(self._test_connection)
        btn_row.addWidget(test_btn)
        save_btn = QPushButton("Enregistrer la configuration")
        save_btn.setObjectName("PrimaryButton")
        save_btn.clicked.connect(self._save_db_config)
        btn_row.addWidget(save_btn)
        btn_container = QWidget()
        btn_container.setLayout(btn_row)
        db_form.addRow(btn_container)

        self._db_status = QLabel("")
        self._db_status.setWordWrap(True)
        db_form.addRow(self._db_status)

        outer.addWidget(db_card)

        # Le sélecteur d'environnement recharge le formulaire ci-dessus dès
        # que les champs existent (branché en dernier, après leur création).
        self._env_combo.currentIndexChanged.connect(self._on_environment_selected)

        # --- Authentification (comptes ProfitabilityTools, v1.10.1) --------
        # Section séparée de « Configuration de la base de données » ci-dessus
        # (IMPORTANT : sans rapport) : celle-ci concerne la base OUTILS qui
        # porte les comptes d'accès à l'application (voir app/auth/), pas les
        # données métier ICI_BI/TECH_BI. Réservée au rôle Administrateur —
        # c'est une action d'administration au même titre que l'écran
        # « Utilisateurs », auquel ce rôle donne déjà accès.
        from auth_partage.service import AuthService

        self._is_admin_for_auth = bool(
            self._current_user is not None
            and AuthService().can(self._current_user.role, "utilisateurs")
        )
        if self._is_admin_for_auth:
            outer.addWidget(_section("Authentification (comptes ProfitabilityTools)"))
            auth_card = QFrame()
            auth_card.setProperty("class", "Card")
            auth_layout = QVBoxLayout(auth_card)

            intro = QLabel(
                "Base qui porte les comptes de connexion à ProfitabilityTools "
                "(indépendante de la configuration ci-dessus, qui concerne les "
                "données métier ICI_BI/TECH_BI)."
            )
            intro.setWordWrap(True)
            intro.setProperty("class", "Muted")
            auth_layout.addWidget(intro)

            self._auth_status = QLabel("")
            self._auth_status.setWordWrap(True)
            auth_layout.addWidget(self._auth_status)
            self._refresh_auth_status()

            btn_outils = QPushButton("Connexion OUTILS…")
            btn_outils.clicked.connect(self._on_open_outils_connection)
            auth_layout.addWidget(btn_outils, alignment=Qt.AlignmentFlag.AlignLeft)

            outer.addWidget(auth_card)

        # --- Apparence -------------------------------------------------------
        outer.addWidget(_section("Apparence"))
        theme_card = QFrame()
        theme_card.setProperty("class", "Card")
        theme_form = QFormLayout(theme_card)
        self._theme_combo = QComboBox()
        self._theme_combo.addItems(["light", "dark"])
        self._theme_combo.setCurrentText(state.theme)
        self._theme_combo.currentTextChanged.connect(state.set_theme)
        theme_form.addRow("Thème :", self._theme_combo)
        outer.addWidget(theme_card)

        # --- À propos ----------------------------------------------------------
        outer.addWidget(_section("À propos"))
        about_card = QFrame()
        about_card.setProperty("class", "Card")
        about_form = QFormLayout(about_card)
        about_form.addRow("ProfitabilityTools", QLabel(f"v{app_version}"))
        about_form.addRow("PySide6", QLabel(pyside_version))
        outer.addWidget(about_card)

        outer.addStretch(1)

    # ------------------------------------------------------------------
    def _selected_environment(self) -> str:
        return self._env_combo.currentData()

    def _on_environment_selected(self, _index: int) -> None:
        """Recharge le formulaire avec les valeurs déjà enregistrées pour
        l'environnement nouvellement sélectionné — ne sauvegarde ni
        n'applique rien : l'utilisateur peut relire/modifier avant de
        cliquer sur Enregistrer/Appliquer. Les réglages de l'environnement
        quitté restent inchangés dans .env (ils n'ont jamais été touchés)."""
        cfg = get_sql_config(self._selected_environment())
        self._db_server.setText(cfg.server)
        self._db_ici_bi.setText(cfg.database_ici_bi)
        self._db_tech_bi.setText(cfg.database_tech_bi)
        self._db_trusted.setChecked(cfg.trusted_connection)
        self._db_user.setText(cfg.username)
        self._db_password.setText(cfg.password)
        self._db_driver.setText(cfg.driver)
        self._db_encrypt.setChecked(cfg.encrypt)
        self._db_trust_cert.setChecked(cfg.trust_server_certificate)
        self._db_timeout.setValue(cfg.timeout_seconds)
        self._db_status.setText("")

    def _apply_environment(self) -> None:
        try:
            # IMPORTANT : on utilise les valeurs actuelles du formulaire
            # (comme « Tester la connexion »), pas uniquement ce qui est
            # déjà enregistré dans .env — sinon un utilisateur qui vient
            # de tester avec succès mais n'a pas encore cliqué sur
            # « Enregistrer la configuration » se voit refuser
            # l'application avec un message « non configurée » trompeur.
            # On enregistre donc automatiquement le formulaire dans .env
            # avant d'appliquer, pour que Tester/Enregistrer/Appliquer
            # utilisent toujours exactement les mêmes valeurs.
            cfg = self._current_form_config()
            if not cfg.is_configured():
                raise SqlServerConnectionError(self._not_configured_message(cfg))
            self._save_db_config()
            apply_env_updates({"PROFITABILITY_ACTIVE_ENV": cfg.environment})
            provider = SqlServerDataProvider(cfg)
            self._state.set_provider(provider)
        except SqlServerConnectionError as exc:
            QMessageBox.warning(self, "Source de données", str(exc))
        except Exception as exc:  # noqa: BLE001 - ne jamais laisser fermer l'application
            QMessageBox.critical(
                self,
                "Source de données",
                f"Erreur inattendue lors du changement de source de données :\n\n{exc}",
            )

    def _on_trusted_toggled(self, checked: bool) -> None:
        """En authentification Windows, l'utilisateur/mot de passe SQL ne
        sont ni nécessaires ni utilisés (voir SqlServerConfig.trusted_connection) —
        on les grise pour éviter toute confusion, sans effacer une valeur
        déjà saisie (au cas où l'utilisateur décoche ensuite)."""
        self._db_user.setDisabled(checked)
        self._db_password.setDisabled(checked)

    def _current_form_config(self, environment: str | None = None) -> SqlServerConfig:
        """Construit un SqlServerConfig à partir des champs du formulaire,
        pour l'environnement sélectionné (ou celui passé explicitement),
        sans toucher à .env (utilisé pour « Tester la connexion »)."""
        return SqlServerConfig(
            server=self._db_server.text().strip(),
            database_ici_bi=self._db_ici_bi.text().strip() or "ICI_BI",
            database_tech_bi=self._db_tech_bi.text().strip() or "TECH_BI",
            username=self._db_user.text().strip(),
            password=self._db_password.text(),
            driver=self._db_driver.text().strip() or "ODBC Driver 18 for SQL Server",
            encrypt=self._db_encrypt.isChecked(),
            trust_server_certificate=self._db_trust_cert.isChecked(),
            timeout_seconds=self._db_timeout.value(),
            trusted_connection=self._db_trusted.isChecked(),
            environment=environment or self._selected_environment(),
        )

    def _not_configured_message(self, cfg: SqlServerConfig) -> str:
        label = ENVIRONMENT_LABELS.get(cfg.environment, cfg.environment)
        if cfg.trusted_connection:
            return (
                f"Connexion SQL Server « {label} » non configurée. Renseignez au minimum le "
                "serveur ci-dessus (l'authentification Windows ne nécessite pas d'utilisateur/"
                "mot de passe), puis réessayez."
            )
        return (
            f"Connexion SQL Server « {label} » non configurée. Renseignez au minimum le "
            "serveur, l'utilisateur et le mot de passe ci-dessus (ou cochez « Authentification "
            "Windows »), puis réessayez."
        )

    def _test_connection(self) -> None:
        cfg = self._current_form_config()
        if not cfg.is_configured():
            self._set_status(self._not_configured_message(cfg), error=True)
            return
        provider = SqlServerDataProvider(cfg)
        try:
            provider._connect()
            self._set_status("Connexion réussie.", error=False)
        except SqlServerConnectionError as exc:
            self._set_status(f"Échec de la connexion : {exc}", error=True)
        except Exception as exc:  # noqa: BLE001 - ne jamais laisser fermer l'application
            self._set_status(f"Échec inattendu du test de connexion : {exc}", error=True)
        finally:
            try:
                provider.close()
            except Exception:  # noqa: BLE001
                pass

    def _save_db_config(self) -> None:
        cfg = self._current_form_config()
        try:
            apply_env_updates(cfg.env_keys())
        except OSError as exc:
            self._set_status(f"Échec de l'écriture du fichier .env : {exc}", error=True)
            return
        label = ENVIRONMENT_LABELS.get(cfg.environment, cfg.environment)
        self._set_status(
            f"Configuration « {label} » enregistrée dans .env. Cliquez sur "
            "« Appliquer et recharger les données » pour l'utiliser.",
            error=False,
        )

    def _set_status(self, text: str, error: bool) -> None:
        self._db_status.setText(text)
        self._db_status.setProperty("class", "ErrorText" if error else "SuccessText")
        self._db_status.style().unpolish(self._db_status)
        self._db_status.style().polish(self._db_status)

    # ---------------------------------------------------- Authentification
    def _refresh_auth_status(self) -> None:
        """Affiche si l'authentification est centralisée sur OUTILS ou
        encore sur le repli local SQLite (voir app/auth/setup.py). N'est
        appelé que si la section est affichée (rôle Administrateur)."""
        from auth_partage import description as auth_description

        try:
            self._auth_status.setText(auth_description())
        except Exception as exc:  # noqa: BLE001 - ne doit jamais bloquer l'écran
            self._auth_status.setText(f"État indisponible : {exc}")

    def _on_open_outils_connection(self) -> None:
        from app.ui.dialogs.connexion_outils_dialog import ConnexionOutilsDialog

        boite = ConnexionOutilsDialog(theme=self._state.theme, parent=self)
        boite.exec()
        # Enregistré ou non (Annuler, ou « Tester » sans enregistrer), l'état
        # affiché doit toujours refléter la réalité du profil sur ce poste.
        self._refresh_auth_status()
