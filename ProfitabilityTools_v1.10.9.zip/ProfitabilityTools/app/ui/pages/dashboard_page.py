"""Dashboard principal (cahier des charges §11-12)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QScrollArea, QSizePolicy,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.core.kpi import (
    compute_kpi_summary, group_sum, monthly_series, top_contracts_by_claims_amount,
    top_contracts_by_premiums,
)
from app.ui.formatters import format_int, format_money, format_percent
from app.ui.safety import guarded_refresh
from app.ui.state import AppState
from app.ui.theme import palette_for
from app.ui.widgets.charts import bar_chart, donut_chart, line_chart
from app.ui.widgets.kpi_card import KpiCard
from app.ui.widgets.table_flex import (
    enable_flexible_header, section_header_row, sortable_item,
)


def _section_title(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setProperty("class", "SectionTitle")
    return lbl


class DashboardPage(QWidget):
    def __init__(self, state: AppState, parent=None):
        super().__init__(parent)
        self._state = state

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        self._content = QWidget()
        scroll.setWidget(self._content)
        self._layout = QVBoxLayout(self._content)
        self._layout.setContentsMargins(20, 16, 20, 20)
        self._layout.setSpacing(18)

        state.datasetChanged.connect(self.refresh)
        state.filtersChanged.connect(self.refresh)
        state.themeChanged.connect(lambda _m: self.refresh())
        self.refresh()

    def _clear(self) -> None:
        while self._layout.count():
            item = self._layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

    def refresh(self) -> None:
        # v1.8.2 : passe par le filet local (app/ui/safety.py) plutôt que de
        # laisser une exception remonter jusqu'à la boîte de dialogue globale
        # (bloquante, et répétée à chaque filtre si le problème est
        # déterministe) — voir app/ui/safety.py.
        guarded_refresh(self._layout, self._clear, self._do_refresh, "Dashboard")

    def _do_refresh(self) -> None:
        self._clear()
        rows = self._state.filtered_rows
        palette = palette_for(self._state.theme)
        kpi = compute_kpi_summary(rows)

        self._layout.addWidget(_section_title("Indicateurs clés"))
        self._layout.addWidget(self._build_kpi_grid(kpi))

        self._layout.addWidget(_section_title("Indicateurs analytiques (ratios dérivés, non contractuels)"))
        self._layout.addWidget(self._build_analytic_grid(kpi))

        self._layout.addWidget(_section_title("Évolution mensuelle"))
        self._layout.addWidget(self._build_evolution_charts(rows, palette))

        row2 = QHBoxLayout()
        row2.addWidget(self._card(donut_chart(
            "Répartition des commissions",
            {
                "Commission ICI": float(kpi.total_commission_ici),
                "Commission distributeur": float(kpi.total_commission_distributeur),
                "Commission TPA / frais gestion": float(kpi.total_commission_tpa),
                "Autres commissions": float(kpi.total_autres_commissions),
            },
            palette,
        )))
        row2.addWidget(self._card(donut_chart(
            "Sinistres par statut",
            {
                "Acceptés": float(kpi.nombre_sinistres_acceptes),
                "En cours": float(kpi.nombre_sinistres_en_cours),
                "Refusés": float(kpi.nombre_sinistres_refuses),
                "Inconnus": float(kpi.nombre_sinistres_inconnus),
            },
            palette,
        )))
        self._layout.addLayout(row2)

        self._layout.addWidget(_section_title("Performance par dimension"))
        self._layout.addWidget(self._build_performance_grid(rows, palette))

        self._layout.addWidget(_section_title("Top contrats"))
        self._layout.addWidget(self._build_top_contracts(rows))

        self._layout.addStretch(1)

    def _card(self, widget: QWidget) -> QFrame:
        frame = QFrame()
        frame.setProperty("class", "Card")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.addWidget(widget)
        return frame

    def _build_kpi_grid(self, kpi) -> QWidget:
        container = QWidget()
        grid = QGridLayout(container)
        grid.setSpacing(10)
        cards = [
            ("Total Primes TTC", format_money(kpi.total_primes_ttc)),
            ("Total Primes HT", format_money(kpi.total_primes_ht)),
            ("Part Assureur", format_money(kpi.total_part_assureur)),
            ("Total Commissions", format_money(kpi.total_commissions)),
            ("Commission ICI", format_money(kpi.total_commission_ici)),
            ("Commission Distributeur", format_money(kpi.total_commission_distributeur)),
            ("Commission TPA", format_money(kpi.total_commission_tpa)),
            ("Nombre d'adhésions", format_int(kpi.nombre_adhesions)),
            ("Nombre de résiliations", format_int(kpi.nombre_resiliations)),
            ("Sinistres (total)", format_int(kpi.nombre_sinistres_total)),
            ("Montant total des règlements", format_money(kpi.montant_total_reglement)),
            ("Sinistres acceptés", format_int(kpi.nombre_sinistres_acceptes)),
            ("Sinistres en cours", format_int(kpi.nombre_sinistres_en_cours)),
        ]
        cols = 4
        for i, (label, value) in enumerate(cards):
            grid.addWidget(KpiCard(label, value), i // cols, i % cols)
        return container

    def _build_analytic_grid(self, kpi) -> QWidget:
        container = QWidget()
        grid = QGridLayout(container)
        grid.setSpacing(10)
        cards = [
            ("Claim Frequency (sinistres / adhésions)", format_percent(kpi.claim_frequency)),
            ("Claims / Premiums HT", format_percent(kpi.claims_over_premiums_ht)),
            ("Commission Rate (commissions / primes HT)", format_percent(kpi.commission_rate)),
        ]
        for i, (label, value) in enumerate(cards):
            grid.addWidget(KpiCard(label, value), 0, i)
        return container

    def _build_evolution_charts(self, rows, palette) -> QWidget:
        series = monthly_series(rows)
        labels = [label for label, _ in series]
        primes = [float(v["primes_ttc"]) for _, v in series]
        sinistres = [float(v["sinistres_montant"]) for _, v in series]

        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._card(line_chart("Évolution mensuelle des primes TTC", labels, {"Primes TTC": primes}, palette)))
        layout.addWidget(self._card(line_chart("Évolution mensuelle des sinistres", labels, {"Montant sinistres": sinistres}, palette)))
        layout.addWidget(self._card(line_chart("Primes TTC vs Sinistres", labels, {"Primes TTC": primes, "Sinistres": sinistres}, palette)))
        return container

    def _build_performance_grid(self, rows, palette) -> QWidget:
        container = QWidget()
        grid = QGridLayout(container)
        grid.setSpacing(10)

        specs = [
            ("compagny", "Performance par compagnie"),
            ("distributor", "Performance par distributeur"),
            ("eligible_product", "Performance par produit"),
            ("tpa", "Performance par TPA"),
        ]
        for i, (field, title) in enumerate(specs):
            grouped = group_sum(rows, field, ["volumes_primes_ttc", "montant_total_reglement"], limit=8)
            categories = [k for k, _ in grouped]
            primes = [float(v["volumes_primes_ttc"]) for _, v in grouped]
            sinistres = [float(v["montant_total_reglement"]) for _, v in grouped]
            chart = bar_chart(title, categories, {"Primes TTC": primes, "Sinistres": sinistres}, palette)
            grid.addWidget(self._card(chart), i // 2, i % 2)
        return container

    def _build_top_contracts(self, rows) -> QWidget:
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)

        layout.addWidget(self._card(self._top_table(
            "Top 10 contrats par primes",
            top_contracts_by_premiums(rows, 10),
            "volumes_primes_ttc",
        )))
        layout.addWidget(self._card(self._top_table(
            "Top 10 contrats par sinistres",
            top_contracts_by_claims_amount(rows, 10),
            "montant_total_reglement",
        )))
        return container

    def _top_table(self, title: str, rows, value_field: str) -> QWidget:
        wrapper = QWidget()
        layout = QVBoxLayout(wrapper)
        layout.setContentsMargins(6, 6, 6, 6)

        table = QTableWidget(len(rows), 3)
        table.setHorizontalHeaderLabels(["Contrat", "Compagnie", "Montant"])
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setSortingEnabled(False)  # désactivé pendant le remplissage (voir Qt docs)
        for r, row in enumerate(rows):
            table.setItem(r, 0, QTableWidgetItem(row.identifiant_contrat_tdb))
            table.setItem(r, 1, QTableWidgetItem(row.compagny))
            table.setItem(r, 2, sortable_item(format_money(getattr(row, value_field)), getattr(row, value_field)))
        table.resizeColumnsToContents()
        table.setMinimumHeight(280)
        enable_flexible_header(table)
        table.setSortingEnabled(True)

        layout.addWidget(section_header_row(_section_title(title), table))
        layout.addWidget(table)
        return wrapper
