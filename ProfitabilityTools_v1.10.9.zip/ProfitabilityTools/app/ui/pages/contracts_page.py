"""Analyse par contrat (cahier des charges §14) : recherche + fiche détaillée
+ évolution historique si plusieurs périodes sont disponibles."""
from __future__ import annotations

from decimal import Decimal

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget,
)

from app.core.models import ProfitabilityRow
from app.ui.formatters import format_int, format_money
from app.ui.safety import guarded_call, guarded_refresh
from app.ui.state import AppState
from app.ui.widgets.table_flex import (
    date_sort_key, enable_flexible_header, section_header_row, sortable_item,
)


def _section(title: str) -> QLabel:
    lbl = QLabel(title)
    lbl.setProperty("class", "SectionTitle")
    return lbl


def _field_row(label: str, value: str) -> QWidget:
    w = QWidget()
    layout = QHBoxLayout(w)
    layout.setContentsMargins(0, 2, 0, 2)
    lbl = QLabel(label)
    lbl.setProperty("class", "Muted")
    lbl.setMinimumWidth(160)
    layout.addWidget(lbl)
    val = QLabel(value)
    val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    layout.addWidget(val, stretch=1)
    return w


class ContractsPage(QWidget):
    def __init__(self, state: AppState, parent=None):
        super().__init__(parent)
        self._state = state
        self._selected_contract: str | None = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 20)
        outer.addWidget(_section("Analyse par contrat"))

        splitter = QSplitter(Qt.Orientation.Horizontal, self)
        outer.addWidget(splitter, stretch=1)

        # --- Panneau de recherche -----------------------------------
        left = QWidget()
        left_layout = QVBoxLayout(left)
        self._search = QLineEdit()
        self._search.setPlaceholderText("Rechercher un contrat (identifiant)...")
        self._search.textChanged.connect(self._refresh_list)
        left_layout.addWidget(self._search)

        self._list = QListWidget()
        self._list.currentTextChanged.connect(self._on_select_contract)
        left_layout.addWidget(self._list)
        splitter.addWidget(left)

        # --- Panneau détail -------------------------------------------
        right = QWidget()
        self._detail_layout = QVBoxLayout(right)
        self._detail_layout.setContentsMargins(16, 0, 0, 0)
        self._empty_label = QLabel("Sélectionnez un contrat dans la liste à gauche.")
        self._empty_label.setProperty("class", "Muted")
        self._detail_layout.addWidget(self._empty_label)
        self._detail_layout.addStretch(1)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)

        state.datasetChanged.connect(self._refresh_list)
        self._refresh_list()

    def _refresh_list(self) -> None:
        # v1.8.2 : pas de layout générique ici (QListWidget mis à jour en
        # place) — voir app/ui/safety.py.
        guarded_call(self._refresh_list_body, "Contracts (liste)")

    def _refresh_list_body(self) -> None:
        text = self._search.text().strip().lower()
        contracts = sorted({r.identifiant_contrat_tdb for r in self._state.all_rows if r.identifiant_contrat_tdb})
        self._list.blockSignals(True)
        self._list.clear()
        for c in contracts:
            if text and text not in c.lower():
                continue
            QListWidgetItem(c, self._list)
        self._list.blockSignals(False)

    def _on_select_contract(self, contract_id: str) -> None:
        self._selected_contract = contract_id or None
        self._render_detail()

    def _clear_detail(self) -> None:
        while self._detail_layout.count():
            item = self._detail_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

    def _render_detail(self) -> None:
        # v1.8.2 : voir app/ui/safety.py.
        guarded_refresh(self._detail_layout, self._clear_detail, self._render_detail_body, "Contracts (détail)")

    def _render_detail_body(self) -> None:
        self._clear_detail()
        if not self._selected_contract:
            self._detail_layout.addWidget(self._empty_label)
            self._detail_layout.addStretch(1)
            return

        periods = sorted(
            (r for r in self._state.all_rows if r.identifiant_contrat_tdb == self._selected_contract),
            key=lambda r: (r.annee or 0, r.mois or 0),
        )
        if not periods:
            self._detail_layout.addWidget(QLabel("Aucune donnée pour ce contrat."))
            return

        latest = periods[-1]

        header = QLabel(self._selected_contract)
        header.setProperty("class", "SectionTitle")
        self._detail_layout.addWidget(header)

        grid_widget = QWidget()
        grid = QGridLayout(grid_widget)

        ident = QFrame()
        ident.setProperty("class", "Card")
        ident_layout = QVBoxLayout(ident)
        ident_layout.addWidget(_section("Identification"))
        for label, value in [
            ("Compagnie", latest.compagny), ("Distributeur", latest.distributor),
            ("TPA", latest.tpa), ("Produit", latest.eligible_product),
            ("Régularisation", latest.regularisation), ("Référence", latest.reference),
            ("Devise", latest.devise), ("Pays", latest.pays), ("Courtier", latest.courtier),
            ("Dernière période", latest.date_debut_periode_souscription_tdb or "—"),
        ]:
            ident_layout.addWidget(_field_row(label, value or "—"))
        grid.addWidget(ident, 0, 0)

        sum_adh = sum((p.number_of_subscription for p in periods), Decimal("0"))
        sum_res = sum((p.nbre_resiliation for p in periods), Decimal("0"))
        activite = QFrame()
        activite.setProperty("class", "Card")
        activite_layout = QVBoxLayout(activite)
        activite_layout.addWidget(_section("Activité (cumul toutes périodes)"))
        activite_layout.addWidget(_field_row("Adhésions", format_int(sum_adh)))
        activite_layout.addWidget(_field_row("Résiliations", format_int(sum_res)))
        activite_layout.addWidget(_field_row("Nombre de périodes", str(len(periods))))
        grid.addWidget(activite, 0, 1)

        finance = QFrame()
        finance.setProperty("class", "Card")
        finance_layout = QVBoxLayout(finance)
        finance_layout.addWidget(_section("Finance (cumul)"))
        for label, field in [
            ("Primes TTC", "volumes_primes_ttc"), ("Primes HT", "volumes_primes_ht"),
            ("Part assureur", "part_assureur"), ("Commission ICI", "commission_ici"),
            ("Commission distributeur", "montant_commission_distributeur"),
            ("Commission TPA", "commission_tpa"), ("Autres commissions", "sum_other_commission"),
            ("Total commissions", "total_com"),
        ]:
            total = sum((getattr(p, field) for p in periods), Decimal("0"))
            finance_layout.addWidget(_field_row(label, format_money(total)))
        grid.addWidget(finance, 1, 0)

        sinistres = QFrame()
        sinistres.setProperty("class", "Card")
        sinistres_layout = QVBoxLayout(sinistres)
        sinistres_layout.addWidget(_section("Sinistres (cumul)"))
        for label, field in [
            ("Total", "nombre_sinistres_total"), ("Acceptés", "nb_sinistres_acceptes"),
            ("Refusés", "nb_sinistres_refuses"), ("En cours", "nb_sinistres_en_cours"),
            ("Inconnus", "nb_sinistres_inconnus"),
        ]:
            total = sum((getattr(p, field) for p in periods), Decimal("0"))
            sinistres_layout.addWidget(_field_row(label, format_int(total)))
        for label, field in [
            ("Montant total", "montant_total_reglement"), ("Montant accepté", "montant_acceptes"),
            ("Montant refusé", "montant_refuses"), ("Montant en cours", "montant_en_cours"),
            ("Montant inconnu", "montant_inconnus"),
        ]:
            total = sum((getattr(p, field) for p in periods), Decimal("0"))
            sinistres_layout.addWidget(_field_row(label, format_money(total)))
        grid.addWidget(sinistres, 1, 1)

        self._detail_layout.addWidget(grid_widget)

        if len(periods) > 1:
            history_table = self._history_table(periods)
            self._detail_layout.addWidget(section_header_row(_section("Évolution historique"), history_table))
            self._detail_layout.addWidget(history_table)

        self._detail_layout.addStretch(1)

    def _history_table(self, periods: list[ProfitabilityRow]) -> QTableWidget:
        columns = ["Période", "Adhésions", "Primes TTC", "Primes HT", "Total commissions", "Sinistres", "Montant sinistres"]
        table = QTableWidget(len(periods), len(columns))
        table.setHorizontalHeaderLabels(columns)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSortingEnabled(False)  # désactivé pendant le remplissage (voir Qt docs)
        for r, p in enumerate(periods):
            cells = [
                sortable_item(p.date_debut_periode_souscription_tdb or "—", date_sort_key(p.date_debut_periode_souscription_tdb)),
                sortable_item(format_int(p.number_of_subscription), p.number_of_subscription),
                sortable_item(format_money(p.volumes_primes_ttc), p.volumes_primes_ttc),
                sortable_item(format_money(p.volumes_primes_ht), p.volumes_primes_ht),
                sortable_item(format_money(p.total_com), p.total_com),
                sortable_item(format_int(p.nombre_sinistres_total), p.nombre_sinistres_total),
                sortable_item(format_money(p.montant_total_reglement), p.montant_total_reglement),
            ]
            for c, item in enumerate(cells):
                table.setItem(r, c, item)
        table.resizeColumnsToContents()
        table.setMinimumHeight(min(40 + 28 * len(periods), 400))
        enable_flexible_header(table)
        table.setSortingEnabled(True)
        return table
