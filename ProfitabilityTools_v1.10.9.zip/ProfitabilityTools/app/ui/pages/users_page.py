"""Écran « Gestion des utilisateurs » (v1.10.0) — comptes ProfitabilityTools
(authentification applicative, voir app/auth/), pas les profils de connexion
SQL Server métier (écran Settings, inchangé).

Accès réservé au rôle Administrateur (habilitation "utilisateurs", voir
app/auth/setup.py::PERMISSIONS) : les comptes au rôle Lecteur n'ont ici
aucune action possible. Décision explicite de l'utilisateur (v1.10.0) :
pas de restriction d'écran par rôle pour les autres pages de l'application —
celle-ci est la seule exception, puisque la gestion des comptes est,
par nature, une fonction d'administration.

Toute la logique (création, modification, désactivation, règle du dernier
administrateur) vit dans auth_partage ; cette page ne fait qu'afficher la
liste et ouvrir les boîtes de dialogue déjà fournies par le module partagé
(UtilisateurDialog) — exactement comme le fait Orchestrator."""
from __future__ import annotations

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.auth.setup import APPLICATION_CODE
from app.ui.safety import guarded_call

logger = logging.getLogger("profitabilitytools.ui")

_COLUMNS = ["Login", "Nom", "Prénom", "E-mail", "Rôle", "Actif", "Dernière connexion"]


def _section(title: str) -> QLabel:
    lbl = QLabel(title)
    lbl.setProperty("class", "SectionTitle")
    return lbl


class UsersPage(QWidget):
    """`current_user` : compte actuellement connecté (auth_partage.service.
    CurrentUser) — nécessaire pour renseigner `cree_par` lors d'une création
    (UtilisateurDialog le lit via `self.parent().current_user`, convention
    reprise d'Orchestrator) et pour interdire qu'un administrateur se
    désactive lui-même par erreur depuis cette page (la règle du dernier
    administrateur actif, elle, est déjà appliquée côté auth_partage —
    cette page ajoute seulement une confirmation explicite avant d'agir sur
    son propre compte).
    """

    def __init__(self, current_user, parent=None):
        super().__init__(parent)
        self.current_user = current_user

        from auth_partage.service import AuthService

        self._auth = AuthService()
        self._comptes: list = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 20)
        outer.addWidget(_section("Gestion des utilisateurs"))

        intro = QLabel(
            "Comptes d'accès à ProfitabilityTools (indépendants des profils "
            "de connexion SQL Server métier configurés sur l'écran Settings). "
            "Rôle « Administrateur » : peut créer/modifier des comptes et "
            "accéder à cet écran. Rôle « Lecteur » : accès à toutes les "
            "autres pages, sans restriction."
        )
        intro.setWordWrap(True)
        intro.setProperty("class", "Muted")
        outer.addWidget(intro)

        boutons = QHBoxLayout()
        self._btn_nouveau = QPushButton("Nouvel utilisateur")
        self._btn_nouveau.setObjectName("PrimaryButton")
        self._btn_nouveau.clicked.connect(self._on_new)
        self._btn_modifier = QPushButton("Modifier")
        self._btn_modifier.clicked.connect(self._on_edit)
        self._btn_toggle = QPushButton("Activer / Désactiver")
        self._btn_toggle.clicked.connect(self._on_toggle_active)
        boutons.addWidget(self._btn_nouveau)
        boutons.addWidget(self._btn_modifier)
        boutons.addWidget(self._btn_toggle)
        boutons.addStretch(1)
        outer.addLayout(boutons)

        self._table = QTableWidget(0, len(_COLUMNS), self)
        self._table.setHorizontalHeaderLabels(_COLUMNS)
        self._table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self._table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self._table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self._table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.verticalHeader().setVisible(False)
        self._table.itemSelectionChanged.connect(self._update_button_state)
        outer.addWidget(self._table, stretch=1)

        self._update_button_state()
        self.refresh()

    # ------------------------------------------------------------------ #
    def refresh(self) -> None:
        guarded_call(self._refresh_body, "Gestion des utilisateurs")

    def _refresh_body(self) -> None:
        from auth_partage.service import analyser_applications

        self._comptes = self._auth.list_users(APPLICATION_CODE)
        self._table.setRowCount(len(self._comptes))
        for row, compte in enumerate(self._comptes):
            role = analyser_applications(compte.applications).get(APPLICATION_CODE, "")
            derniere = (
                compte.derniere_connexion.strftime("%d/%m/%Y %H:%M")
                if compte.derniere_connexion else "—"
            )
            valeurs = [
                compte.login, compte.nom or "", compte.prenom or "",
                compte.email or "", role,
                "Oui" if compte.actif else "Non", derniere,
            ]
            for col, valeur in enumerate(valeurs):
                item = QTableWidgetItem(valeur)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self._table.setItem(row, col, item)
        self._update_button_state()

    def _selected_compte(self):
        row = self._table.currentRow()
        if row < 0 or row >= len(self._comptes):
            return None
        return self._comptes[row]

    def _update_button_state(self) -> None:
        compte = self._selected_compte()
        self._btn_modifier.setEnabled(compte is not None)
        self._btn_toggle.setEnabled(compte is not None)

    # ------------------------------------------------------------------ #
    def _on_new(self) -> None:
        from auth_partage.ui.utilisateur import UtilisateurDialog

        boite = UtilisateurDialog(compte=None, parent=self)
        if boite.exec():
            self.refresh()

    def _on_edit(self) -> None:
        compte = self._selected_compte()
        if compte is None:
            return
        from auth_partage.ui.utilisateur import UtilisateurDialog

        boite = UtilisateurDialog(compte=compte, parent=self)
        if boite.exec():
            self.refresh()

    def _on_toggle_active(self) -> None:
        compte = self._selected_compte()
        if compte is None:
            return
        nouvel_etat = not compte.actif
        if compte.login == getattr(self.current_user, "login", None) and not nouvel_etat:
            reponse = QMessageBox.question(
                self, "Désactiver votre propre compte ?",
                "Vous êtes sur le point de désactiver votre propre compte "
                "(" + compte.login + "). Vous ne pourrez plus vous reconnecter "
                "à ProfitabilityTools sans qu'un autre administrateur ne le "
                "réactive. Continuer ?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reponse != QMessageBox.StandardButton.Yes:
                return

        ok, message = self._auth.set_active(compte.id, nouvel_etat)
        if not ok:
            QMessageBox.warning(self, "Opération refusée", message)
            return
        self.refresh()
