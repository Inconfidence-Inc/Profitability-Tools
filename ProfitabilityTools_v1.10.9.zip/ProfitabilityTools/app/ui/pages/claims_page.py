"""Page Claims (cahier des charges §7, §12) : vue dédiée sinistres."""
from __future__ import annotations

from PySide6.QtWidgets import QFrame, QGridLayout, QHBoxLayout, QScrollArea, QVBoxLayout, QWidget

from app.core.kpi import compute_kpi_summary, top_contracts_by_claims_amount
from app.ui.formatters import format_int, format_money
from app.ui.safety import guarded_refresh
from app.ui.state import AppState
from app.ui.theme import palette_for
from app.ui.widgets.charts import donut_chart
from app.ui.widgets.kpi_card import KpiCard
from app.ui.widgets.table_flex import (
    FrozenColumnTableView, enable_flexible_header, section_header_row,
)
from app.ui.widgets.table_model import ProfitabilityTableModel
from PySide6.QtWidgets import QTableView


def _section(title: str):
    from PySide6.QtWidgets import QLabel
    lbl = QLabel(title)
    lbl.setProperty("class", "SectionTitle")
    return lbl


_CLAIMS_COLUMNS = [
    "identifiant_contrat_tdb", "date_debut_periode_souscription_tdb", "compagny",
    "distributor", "tpa", "nombre_sinistres_total", "nb_sinistres_acceptes",
    "nb_sinistres_refuses", "nb_sinistres_en_cours", "nb_sinistres_inconnus",
    "montant_total_reglement",
]


class ClaimsPage(QWidget):
    def __init__(self, state: AppState, parent=None):
        super().__init__(parent)
        self._state = state

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        self._content = QWidget()
        scroll.setWidget(self._content)
        self._layout = QVBoxLayout(self._content)
        self._layout.setContentsMargins(20, 16, 20, 20)
        self._layout.setSpacing(16)

        state.datasetChanged.connect(self.refresh)
        state.filtersChanged.connect(self.refresh)
        state.themeChanged.connect(lambda _m: self.refresh())
        self.refresh()

    def _clear(self) -> None:
        while self._layout.count():
            item = self._layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

    def refresh(self) -> None:
        guarded_refresh(self._layout, self._clear, self._do_refresh, "Claims")  # v1.8.2

    def _do_refresh(self) -> None:
        self._clear()
        rows = self._state.filtered_rows
        palette = palette_for(self._state.theme)
        kpi = compute_kpi_summary(rows)

        self._layout.addWidget(_section("Sinistres — indicateurs"))
        kpi_container = QWidget()
        grid = QGridLayout(kpi_container)
        grid.setSpacing(10)
        cards = [
            ("Sinistres (total)", format_int(kpi.nombre_sinistres_total)),
            ("Acceptés", format_int(kpi.nombre_sinistres_acceptes)),
            ("Refusés", format_int(kpi.nombre_sinistres_refuses)),
            ("En cours", format_int(kpi.nombre_sinistres_en_cours)),
            ("Inconnus", format_int(kpi.nombre_sinistres_inconnus)),
            ("Montant total réglé", format_money(kpi.montant_total_reglement)),
            ("Claim Frequency", f"{kpi.claim_frequency:.1%}" if kpi.claim_frequency is not None else "—"),
            ("Claims / Premiums HT", f"{kpi.claims_over_premiums_ht:.1%}" if kpi.claims_over_premiums_ht is not None else "—"),
        ]
        for i, (label, value) in enumerate(cards):
            grid.addWidget(KpiCard(label, value), i // 4, i % 4)
        self._layout.addWidget(kpi_container)

        row = QHBoxLayout()
        donut = donut_chart(
            "Sinistres par statut",
            {
                "Acceptés": float(kpi.nombre_sinistres_acceptes),
                "Refusés": float(kpi.nombre_sinistres_refuses),
                "En cours": float(kpi.nombre_sinistres_en_cours),
                "Inconnus": float(kpi.nombre_sinistres_inconnus),
            },
            palette,
        )
        card = QFrame()
        card.setProperty("class", "Card")
        card_layout = QVBoxLayout(card)
        card_layout.addWidget(donut)
        row.addWidget(card, stretch=1)
        self._layout.addLayout(row)

        top = top_contracts_by_claims_amount(rows, 15)
        model = ProfitabilityTableModel(rows=top, columns=_CLAIMS_COLUMNS)
        table = FrozenColumnTableView()
        table.setModel(model)
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        table.setSortingEnabled(True)
        table.setMinimumHeight(420)
        enable_flexible_header(table)

        self._layout.addWidget(section_header_row(_section("Top 15 contrats par montant de sinistres"), table))
        self._layout.addWidget(table)

        self._layout.addStretch(1)
