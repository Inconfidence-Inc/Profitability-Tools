"""Section Data Quality (cahier des charges §17) + réconciliation SQL (§23)."""
from __future__ import annotations

import csv
from pathlib import Path

from PySide6.QtWidgets import (
    QFileDialog, QGridLayout, QHBoxLayout, QLabel, QMessageBox, QPushButton,
    QScrollArea, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.core.data_quality import build_data_quality_report
from app.core.reconciliation import reconcile
from app.ui.formatters import format_money
from app.ui.safety import guarded_refresh
from app.ui.state import AppState
from app.ui.widgets.kpi_card import KpiCard
from app.ui.widgets.table_flex import (
    date_sort_key, enable_flexible_header, section_header_row, sortable_item,
)


def _section(title: str) -> QLabel:
    lbl = QLabel(title)
    lbl.setProperty("class", "SectionTitle")
    return lbl


class DataQualityPage(QWidget):
    def __init__(self, state: AppState, parent=None):
        super().__init__(parent)
        self._state = state
        self._dirty = True

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        self._content = QWidget()
        scroll.setWidget(self._content)
        self._layout = QVBoxLayout(self._content)
        self._layout.setContentsMargins(20, 16, 20, 20)
        self._layout.setSpacing(16)

        # v1.8.0 : contrairement aux autres pages, cet écran parcourt la
        # liste BRUTE des sinistres (potentiellement ~1,3M lignes depuis
        # SRC_Sinistre_Transformer_Contenu, voir app/core/data_quality.py)
        # pour détecter les sinistres orphelins — un calcul coûteux en temps
        # et en objets temporaires. Comme toutes les pages sont construites
        # d'avance dans le QStackedWidget (voir app/ui/main_window.py) et se
        # reconnectent toutes aux mêmes signaux, ce calcul se déclenchait
        # auparavant à CHAQUE rechargement/changement de filtre, même quand
        # l'utilisateur regardait une autre page (Dashboard, Claims, ...) —
        # contribuant au risque de plantage juste après « Appliquer et
        # recharger les données ». On ne marque plus que l'écran est
        # "périmé" (_dirty) et on ne recalcule réellement que lorsque cette
        # page redevient visible (showEvent), ou immédiatement si elle
        # l'est déjà au moment du signal.
        state.datasetChanged.connect(self._mark_dirty)
        state.filtersChanged.connect(self._mark_dirty)
        self.refresh()

    def _mark_dirty(self) -> None:
        self._dirty = True
        if self.isVisible():
            self.refresh()

    def showEvent(self, event) -> None:  # noqa: N802 - signature Qt
        super().showEvent(event)
        if self._dirty:
            self.refresh()

    def _clear(self) -> None:
        while self._layout.count():
            item = self._layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

    def refresh(self) -> None:
        self._dirty = False
        # v1.8.2 : voir app/ui/safety.py.
        guarded_refresh(self._layout, self._clear, self._do_refresh, "Data Quality")

    def _do_refresh(self) -> None:
        self._clear()
        rows = self._state.filtered_rows
        sinistres_rows = self._state.sinistres_rows
        report = build_data_quality_report(rows, sinistres_rows)

        self._layout.addWidget(_section("Qualité des données"))
        note = QLabel(
            "Ces contrôles portent sur les lignes actuellement filtrées. "
            "Un décompte à 0 partout ne garantit pas l'absence totale d'anomalies hors filtre."
        )
        note.setProperty("class", "Muted")
        note.setWordWrap(True)
        self._layout.addWidget(note)

        counts = report.counts()
        grid_container = QWidget()
        grid = QGridLayout(grid_container)
        grid.setSpacing(10)
        for i, (label, value) in enumerate(counts.items()):
            grid.addWidget(KpiCard(label, str(value)), i // 4, i % 4)
        self._layout.addWidget(grid_container)

        self._layout.addWidget(self._simple_table(
            "Contrats sans référentiel",
            ["Contrat", "Compagnie", "Période"],
            [
                (
                    r.identifiant_contrat_tdb,
                    r.compagny,
                    (r.date_debut_periode_souscription_tdb or "—", date_sort_key(r.date_debut_periode_souscription_tdb)),
                )
                for r in report.contrats_sans_referentiel[:200]
            ],
        ))

        self._layout.addWidget(self._simple_table(
            "Tranches tarifaires non interprétables",
            ["Contrat", "Valeur source (PRICE_RANGE)"],
            [(r.identifiant_contrat_tdb, r.price_range) for r in report.price_ranges_non_interpretables[:200]],
        ))

        self._layout.addWidget(self._simple_table(
            "Tranches tarifaires suspectes (borne min > borne max)",
            ["Contrat", "Valeur source", "Bornes"],
            [(r.identifiant_contrat_tdb, r.price_range, r.bornes_combinees) for r in report.price_ranges_suspects[:200]],
        ))

        dup_rows = []
        for key, group in list(report.cles_dupliquees.items())[:100]:
            for r in group:
                dup_rows.append((key, r.compagny, (format_money(r.volumes_primes_ttc), r.volumes_primes_ttc)))
        self._layout.addWidget(self._simple_table(
            "Clés Key_Contrat_Date dupliquées (montants différents)",
            ["Clé", "Compagnie", "Primes TTC"], dup_rows,
        ))

        self._layout.addWidget(self._simple_table(
            "Sinistres non rattachables à un contrat/période",
            ["Numero_Police", "Date_Souscription_Adhesion", "Montant total règlement"],
            [
                (str(s.get("Numero_Police")), str(s.get("Date_Souscription_Adhesion")), str(s.get("Montant_Total_Reglement", "—")))
                for s in report.sinistres_orphelins[:200]
            ],
        ))

        self._layout.addWidget(_section("Réconciliation avec un export SQL de référence"))
        recon_note = QLabel(
            "Importez un export CSV du SQL historique (mêmes alias de colonnes que le SELECT de référence, "
            "notamment Key_Contrat_Date, Volumes_Primes_TTC, Volumes_Primes_HT, PartAssureur, Total_Com, "
            "NumberOfSubscription, NBRE_RESILIATION, Nombre_Sinistres_Total, Montant_Total_Règlement) "
            "pour comparer avec le dataset actuel."
        )
        recon_note.setWordWrap(True)
        recon_note.setProperty("class", "Muted")
        self._layout.addWidget(recon_note)

        btn = QPushButton("Importer un export SQL (CSV) et comparer")
        btn.clicked.connect(self._run_reconciliation)
        self._layout.addWidget(btn)

        self._recon_result = QLabel("")
        self._recon_result.setWordWrap(True)
        self._layout.addWidget(self._recon_result)

        self._layout.addStretch(1)

    def _simple_table(self, title: str, headers: list[str], data: list[tuple]) -> QWidget:
        """Construit une section (titre + bouton Colonnes + tableau). Chaque
        cellule de `data` est soit une valeur simple (triée comme du texte),
        soit un couple (affichage, valeur_brute_pour_le_tri) — ex. un montant
        formaté trié comme un Decimal, une date métier triée chronologiquement."""
        table = QTableWidget(len(data), len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSortingEnabled(False)  # désactivé pendant le remplissage (voir Qt docs)
        for r, values in enumerate(data):
            for c, v in enumerate(values):
                if isinstance(v, tuple) and len(v) == 2:
                    display, sort_value = v
                else:
                    display, sort_value = v, v
                table.setItem(r, c, sortable_item(display, sort_value))
        table.resizeColumnsToContents()
        table.setMinimumHeight(min(40 + 28 * max(len(data), 1), 300))
        if not data:
            table.setRowCount(1)
            table.setItem(0, 0, QTableWidgetItem("Aucune anomalie détectée."))
        enable_flexible_header(table)
        table.setSortingEnabled(True)

        wrapper = QWidget()
        layout = QVBoxLayout(wrapper)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(section_header_row(_section(title), table))
        layout.addWidget(table)
        return wrapper

    def _run_reconciliation(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Importer un export SQL (CSV)", "", "CSV (*.csv)")
        if not path:
            return
        try:
            sql_rows = []
            with open(path, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f, delimiter=";")
                for row in reader:
                    sql_rows.append(row)
            report = reconcile(self._state.filtered_rows, sql_rows)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Réconciliation", f"Échec de la lecture/comparaison : {exc}")
            return

        lines = [
            f"Lignes app : {report.app_row_count} | Lignes SQL : {report.sql_row_count} "
            f"({'OK' if report.row_count_matches else 'ÉCART'})",
            f"Clés uniquement côté app : {len(report.keys_only_in_app)}",
            f"Clés uniquement côté SQL : {len(report.keys_only_in_sql)}",
            f"Clés avec écarts de montants : {len(report.key_level_diffs)}",
        ]
        for diff in report.global_diffs:
            status = "OK" if diff.delta == 0 else f"ÉCART ({diff.delta})"
            lines.append(f"  • {diff.field}: app={diff.app_value} / sql={diff.sql_value} — {status}")
        lines.append("RÉCONCILIÉ" if report.is_fully_reconciled else "NON RÉCONCILIÉ — écarts détectés ci-dessus")
        self._recon_result.setText("\n".join(lines))
