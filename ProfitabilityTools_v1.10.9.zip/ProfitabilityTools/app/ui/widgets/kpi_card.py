"""Carte KPI (cahier des charges §11)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout


class KpiCard(QFrame):
    def __init__(self, label: str, value: str = "—", tooltip: str = "", parent=None):
        super().__init__(parent)
        self.setProperty("class", "Card")
        self.setObjectName("KpiCard")
        self.setFrameShape(QFrame.Shape.NoFrame)
        if tooltip:
            self.setToolTip(tooltip)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(4)

        self._label = QLabel(label, self)
        self._label.setProperty("class", "CardLabel")
        layout.addWidget(self._label)

        self._value = QLabel(value, self)
        self._value.setProperty("class", "CardValue")
        self._value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self._value)

    def set_value(self, value: str) -> None:
        self._value.setText(value)

    def set_label(self, label: str) -> None:
        self._label.setText(label)
