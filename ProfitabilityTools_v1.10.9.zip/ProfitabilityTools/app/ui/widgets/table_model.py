"""
Modèle de table pour Profitability Explorer (cahier des charges §15) :
tri, choix des colonnes visibles, formatage monétaire/dates.

Le tri et le filtrage textuel passent par un QSortFilterProxyModel appliqué
par-dessus ce modèle (voir explorer_page.py) — ce modèle reste une vue en
lecture seule sur les ProfitabilityRow déjà filtrées par la barre globale.
"""
from __future__ import annotations

from decimal import Decimal

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt

from app.core.models import COLUMN_LABELS, MONEY_FIELDS, ProfitabilityRow
from app.ui.formatters import format_date_fr, format_int, format_money

DEFAULT_VISIBLE_COLUMNS = [
    "identifiant_contrat_tdb", "date_debut_periode_souscription_tdb",
    "compagny", "distributor", "tpa", "eligible_product",
    "number_of_subscription", "volumes_primes_ttc", "volumes_primes_ht",
    "total_com", "nombre_sinistres_total", "montant_total_reglement",
]

_DATE_FIELDS = {"date_debut_periode_souscription_tdb", "date_fin_periode_souscription_tdb"}
_INT_FIELDS = {
    "annee", "mois", "number_of_subscription", "nbre_resiliation",
    "nombre_sinistres_total", "nb_sinistres_en_cours", "nb_sinistres_refuses",
    "nb_sinistres_acceptes", "nb_sinistres_inconnus",
}


class ProfitabilityTableModel(QAbstractTableModel):
    def __init__(self, rows: list[ProfitabilityRow] | None = None, columns: list[str] | None = None, parent=None):
        super().__init__(parent)
        self._rows: list[ProfitabilityRow] = rows or []
        self._columns: list[str] = columns or list(DEFAULT_VISIBLE_COLUMNS)

    # --- API publique --------------------------------------------------
    def set_rows(self, rows: list[ProfitabilityRow]) -> None:
        self.beginResetModel()
        self._rows = rows
        self.endResetModel()

    def set_columns(self, columns: list[str]) -> None:
        self.beginResetModel()
        self._columns = columns
        self.endResetModel()

    def columns(self) -> list[str]:
        return list(self._columns)

    def row_at(self, row_index: int) -> ProfitabilityRow | None:
        if 0 <= row_index < len(self._rows):
            return self._rows[row_index]
        return None

    def totals(self) -> dict[str, Decimal]:
        """Totaux pour les colonnes monétaires visibles (ligne de total, §15)."""
        out: dict[str, Decimal] = {}
        for col in self._columns:
            if col in MONEY_FIELDS:
                out[col] = sum((getattr(r, col) or Decimal("0") for r in self._rows), Decimal("0"))
        return out

    # --- QAbstractTableModel --------------------------------------------
    def rowCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._columns)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            field = self._columns[section]
            return COLUMN_LABELS.get(field, field)
        return str(section + 1)

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row = self._rows[index.row()]
        field = self._columns[index.column()]
        value = getattr(row, field, None)

        if role == Qt.ItemDataRole.DisplayRole:
            if field in MONEY_FIELDS:
                devise = row.devise if field in ("volumes_primes_ttc", "volumes_primes_ht", "part_assureur") else ""
                return format_money(value, devise)
            if field in _DATE_FIELDS:
                return format_date_fr(value)
            if field in _INT_FIELDS:
                return format_int(value)
            return "" if value is None else str(value)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if field in MONEY_FIELDS or field in _INT_FIELDS:
                return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            return int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        if role == Qt.ItemDataRole.UserRole:  # valeur brute, pour un tri correct
            return value

        return None

    def sort(self, column: int, order=Qt.SortOrder.AscendingOrder) -> None:  # noqa: N802
        field = self._columns[column]
        reverse = order == Qt.SortOrder.DescendingOrder

        def sort_key(row: ProfitabilityRow):
            value = getattr(row, field, None)
            if value is None:
                return (0, "")
            if isinstance(value, Decimal):
                return (1, value)
            return (1, str(value).lower())

        self.layoutAboutToBeChanged.emit()
        self._rows.sort(key=sort_key, reverse=reverse)
        self.layoutChanged.emit()
