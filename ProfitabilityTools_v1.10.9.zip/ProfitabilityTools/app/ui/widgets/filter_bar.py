"""
Barre de filtres globale (cahier des charges §13) : combinable, recherche
dans les listes longues, sélection multiple, bouton Reset, indication du
nombre de filtres actifs.
"""
from __future__ import annotations

from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QPushButton, QWidget

from app.ui.state import AppState, FilterState
from app.ui.widgets.multiselect_combo import MultiSelectCombo

# (attribut FilterState, champ ProfitabilityRow, libellé, convertisseur str->valeur)
_FIELDS = [
    ("annees", "annee", "Année", int),
    ("mois", "mois", "Mois", int),
    ("compagnies", "compagny", "Compagnie", str),
    ("distributeurs", "distributor", "Distributeur", str),
    ("tpas", "tpa", "TPA", str),
    ("produits", "eligible_product", "Produit éligible", str),
    ("regularisations", "regularisation", "Régularisation", str),
    ("contrats", "identifiant_contrat_tdb", "Contrat", str),
    ("references", "reference", "Référence", str),
    ("devises", "devise", "Devise", str),
    ("price_ranges", "price_range", "Tranche tarifaire", str),
    ("pays", "pays", "Pays", str),
    ("courtiers", "courtier", "Courtier", str),
]


class FilterBar(QWidget):
    def __init__(self, state: AppState, parent=None):
        super().__init__(parent)
        self._state = state
        self._combos: dict[str, MultiSelectCombo] = {}
        self._converters: dict[str, type] = {}

        outer = QHBoxLayout(self)
        outer.setContentsMargins(12, 8, 12, 8)
        outer.setSpacing(8)

        grid_container = QWidget(self)
        grid = QGridLayout(grid_container)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(6)

        cols = 6
        for i, (attr, _field, label, converter) in enumerate(_FIELDS):
            combo = MultiSelectCombo(label, grid_container)
            combo.selectionChanged.connect(self._on_filters_edited)
            self._combos[attr] = combo
            self._converters[attr] = converter
            grid.addWidget(combo, i // cols, i % cols)

        outer.addWidget(grid_container, stretch=1)

        side = QHBoxLayout()
        self._active_label = QLabel("Aucun filtre actif", self)
        self._active_label.setProperty("class", "Muted")
        side.addWidget(self._active_label)

        reset_btn = QPushButton("Réinitialiser les filtres", self)
        reset_btn.clicked.connect(self._on_reset)
        side.addWidget(reset_btn)
        outer.addLayout(side)

        state.datasetChanged.connect(self._refresh_options)
        self._refresh_options()

    def _refresh_options(self) -> None:
        for attr, field, _label, _converter in _FIELDS:
            combo = self._combos[attr]
            combo.blockSignals(True)
            values = self._state.distinct(field)
            combo.set_values(values)
            current = getattr(self._state.filters, attr)
            combo.set_selected_values({str(v) for v in current})
            combo.blockSignals(False)
        self._update_active_label()

    def _on_filters_edited(self) -> None:
        filters = FilterState()
        for attr, _field, _label, converter in _FIELDS:
            raw_values = self._combos[attr].selected_values()
            converted = set()
            for v in raw_values:
                try:
                    converted.add(converter(v))
                except (ValueError, TypeError):
                    continue
            setattr(filters, attr, converted)
        self._state.set_filters(filters)
        self._update_active_label()

    def _on_reset(self) -> None:
        self._state.reset_filters()
        for combo in self._combos.values():
            combo.blockSignals(True)
            combo.set_selected_values(set())
            combo.blockSignals(False)
        self._update_active_label()

    def _update_active_label(self) -> None:
        n = self._state.filters.active_count()
        if n == 0:
            self._active_label.setText("Aucun filtre actif")
        else:
            self._active_label.setText(f"{n} filtre(s) actif(s)")
