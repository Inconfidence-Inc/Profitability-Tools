"""
Utilitaires partagés pour rendre les tableaux de l'application plus
flexibles (demande utilisateur) :

- colonnes redimensionnables (glisser la largeur) sur tous les tableaux ;
- tri par clic sur l'en-tête, avec un tri correct (numérique/date) même
  quand la cellule affiche une valeur déjà formatée pour l'écran (montant,
  date métier dd/MM/yyyy) ;
- choix des colonnes visibles (afficher/masquer), indépendant du modèle de
  données sous-jacent — fonctionne aussi bien sur un QTableWidget que sur un
  QTableView avec modèle personnalisé (ProfitabilityTableModel) ;
- défilement horizontal doux et lisible (v1.9.0) : mode de défilement au
  pixel près plutôt que par cellule, et une première colonne « figée »
  (FrozenColumnTableView) qui reste visible pendant qu'on fait défiler les
  tableaux à beaucoup de colonnes (Profitability Explorer, Claims) — sans
  quoi on perd le repère (contrat, période) une fois les colonnes de droite
  affichées.

Ce module ne contient aucune règle métier : il affiche/masque/trie ce que
les pages lui donnent déjà (cahier des charges : « l'UI ne contient aucun
calcul métier »). Le parsing de date réutilise app.core.keys.parse_business_date
(déjà testé) plutôt que d'en réinventer un ici.
"""
from __future__ import annotations

from datetime import date
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QListWidget, QListWidgetItem,
    QMenu, QPushButton, QTableView, QTableWidgetItem, QWidget, QWidgetAction,
)

from app.core.keys import parse_business_date

# Hauteur de ligne par défaut un peu plus aérée que le défaut Qt (~30px),
# pour une meilleure lisibilité des tableaux de données (demande utilisateur,
# v1.9.0, Material Design — densité « confortable »).
_ROW_HEIGHT = 36


def enable_flexible_header(table) -> None:
    """Colonnes redimensionnables par glisser (mode Interactive, explicite
    pour ne jamais dépendre d'un défaut Qt), dernière colonne étirée pour
    occuper l'espace restant, défilement au pixel près (plus doux qu'au
    pixel par cellule) et lignes un peu plus aérées — comportement identique
    sur tous les tableaux de l'application."""
    header = table.horizontalHeader()
    header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    header.setStretchLastSection(True)
    header.setMinimumSectionSize(50)
    table.verticalHeader().setDefaultSectionSize(_ROW_HEIGHT)
    table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    # Nécessaire pour que la surbrillance au survol (QSS ::item:hover,
    # app/ui/theme.py) se mette à jour sans qu'un clic soit nécessaire.
    table.setMouseTracking(True)


class FrozenColumnTableView(QTableView):
    """QTableView dont la première colonne reste visible (« figée ») pendant
    le défilement horizontal — demande utilisateur (v1.9.0) : sur un tableau
    à beaucoup de colonnes (Profitability Explorer, Claims), faire défiler
    vers la droite faisait perdre le repère (quel contrat/quelle période).

    Reprend le principe de l'exemple officiel Qt « Frozen Column » : une
    seconde QTableView, superposée sur le tableau principal et limitée à la
    colonne 0, partage le même modèle et défile verticalement en même temps
    que lui. Usage : remplacer `QTableView()` par `FrozenColumnTableView()`
    — le reste de l'API (setModel, setSortingEnabled, etc.) est inchangé.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._frozen = QTableView(self)
        self._frozen.setObjectName("FrozenColumn")
        self._frozen.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._frozen.verticalHeader().hide()
        self._frozen.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        self._frozen.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        self._frozen.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self._frozen.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._frozen.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._frozen.setFrameShape(QTableView.Shape.NoFrame)
        self._frozen.setAlternatingRowColors(True)
        self.viewport().stackUnder(self._frozen)
        self._frozen.hide()

        self.horizontalHeader().sectionResized.connect(self._on_section_resized)
        self.verticalHeader().sectionResized.connect(self._on_row_resized)
        self.verticalScrollBar().valueChanged.connect(self._frozen.verticalScrollBar().setValue)
        self._frozen.verticalScrollBar().valueChanged.connect(self.verticalScrollBar().setValue)

    # --- modèle / sélection partagés avec le tableau principal ----------
    def setModel(self, model) -> None:  # noqa: N802 (nom imposé par Qt)
        super().setModel(model)
        self._frozen.setModel(model)
        if model is not None:
            model.modelReset.connect(self._sync_frozen_columns)
        self._frozen.setSelectionModel(self.selectionModel())
        self._sync_frozen_columns()
        self._frozen.show()

    def _sync_frozen_columns(self) -> None:
        model = self.model()
        if model is None:
            return
        for col in range(model.columnCount()):
            self._frozen.setColumnHidden(col, col != 0)
        self._frozen.setColumnWidth(0, self.columnWidth(0))
        self._update_frozen_geometry()

    # --- synchronisation géométrie (largeur colonne 0, hauteur lignes) --
    def _on_section_resized(self, col: int, _old: int, new: int) -> None:
        if col == 0:
            self._frozen.setColumnWidth(0, new)
            self._update_frozen_geometry()

    def _on_row_resized(self, row: int, _old: int, new: int) -> None:
        self._frozen.setRowHeight(row, new)

    def _update_frozen_geometry(self) -> None:
        self._frozen.setGeometry(
            self.frameWidth(),
            self.frameWidth() + self.horizontalHeader().height(),
            self.columnWidth(0),
            self.viewport().height(),
        )

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._update_frozen_geometry()


class SortableTableWidgetItem(QTableWidgetItem):
    """QTableWidgetItem dont le tri (clic sur l'en-tête) se base sur une
    valeur brute (Decimal, date, nombre...) plutôt que sur le texte déjà
    formaté pour l'affichage — ex. « 12 500,00 € » doit se trier comme
    12500.00, pas comme du texte, et « 05/01/2026 » doit se trier comme une
    vraie date, pas alphabétiquement."""

    def __init__(self, text: str, sort_value: Any = None):
        super().__init__(text)
        self._sort_value = text if sort_value is None else sort_value

    def __lt__(self, other) -> bool:  # noqa: D105
        other_value = getattr(other, "_sort_value", None)
        if other_value is None:
            return super().__lt__(other)
        try:
            return self._sort_value < other_value
        except TypeError:
            return str(self._sort_value) < str(other_value)


def sortable_item(display: Any, sort_value: Any = None) -> SortableTableWidgetItem:
    """Construit une cellule triable à partir d'une valeur déjà formatée pour
    l'affichage (display) et, optionnellement, de la valeur brute à utiliser
    pour le tri (sort_value) — ex. le Decimal derrière un montant formaté."""
    return SortableTableWidgetItem(str(display), sort_value)


def date_sort_key(raw: str | date | None) -> date:
    """Clé de tri pour une date métier dd/MM/yyyy (voir app.core.keys) : une
    date absente/invalide est classée en premier plutôt que de faire échouer
    le tri."""
    parsed = parse_business_date(raw) if raw else None
    return parsed or date.min


class ColumnVisibilityButton(QPushButton):
    """Bouton « Colonnes » générique : affiche/masque les colonnes d'un
    tableau (QTableView ou QTableWidget, peu importe) via son QHeaderView —
    ne touche jamais au modèle de données ni aux règles métier. Les libellés
    viennent directement des en-têtes déjà affichés dans le tableau."""

    def __init__(self, table, parent=None):
        super().__init__("Colonnes", parent)
        self._table = table
        self._header = table.horizontalHeader()

        model = table.model()
        column_count = model.columnCount() if model is not None else 0

        self._menu = QMenu(self)
        self._list = QListWidget(self._menu)
        self._list.setMinimumWidth(220)
        self._list.setMinimumHeight(min(28 * max(column_count, 1) + 12, 320))
        for col in range(column_count):
            label = model.headerData(col, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole)
            item = QListWidgetItem(str(label) if label is not None else f"Colonne {col + 1}", self._list)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                Qt.CheckState.Unchecked if self._header.isSectionHidden(col) else Qt.CheckState.Checked
            )
            item.setData(Qt.ItemDataRole.UserRole, col)
        self._list.itemChanged.connect(self._on_item_changed)
        action = QWidgetAction(self._menu)
        action.setDefaultWidget(self._list)
        self._menu.addAction(action)
        self.setMenu(self._menu)

    def _on_item_changed(self, item: QListWidgetItem) -> None:
        col = item.data(Qt.ItemDataRole.UserRole)
        hidden = item.checkState() != Qt.CheckState.Checked
        # Sécurité : ne jamais permettre de masquer la dernière colonne visible.
        if hidden and self._visible_count() <= 1:
            item.setCheckState(Qt.CheckState.Checked)
            return
        self._header.setSectionHidden(col, hidden)

    def _visible_count(self) -> int:
        header = self._header
        return sum(1 for c in range(header.count()) if not header.isSectionHidden(c))


def section_header_row(title_widget: QWidget, table) -> QWidget:
    """Ligne « titre de section + bouton Colonnes », alignés sur une même
    ligne — pour ne pas dupliquer cette mise en page dans chaque page."""
    row = QWidget()
    layout = QHBoxLayout(row)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.addWidget(title_widget)
    layout.addStretch(1)
    layout.addWidget(ColumnVisibilityButton(table))
    return row
