"""
Combo à sélection multiple avec recherche intégrée (cahier des charges §13 :
"recherche dans les listes longues", "sélection multiple").
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QVBoxLayout, QWidget, QWidgetAction, QMenu,
)


class MultiSelectCombo(QPushButton):
    """Bouton affichant un résumé ("Toutes", "3 sélectionnées", ...) qui ouvre
    un menu avec recherche + cases à cocher."""

    selectionChanged = Signal()

    def __init__(self, label: str, parent=None):
        super().__init__(parent)
        self._label = label
        self._all_values: list[str] = []
        self._selected: set[str] = set()
        self._checkboxes: dict[str, QCheckBox] = {}

        self._menu = QMenu(self)
        container = QWidget(self._menu)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)

        self._search = QLineEdit(container)
        self._search.setPlaceholderText("Rechercher...")
        self._search.textChanged.connect(self._on_search)
        layout.addWidget(self._search)

        self._list = QListWidget(container)
        self._list.setMaximumHeight(260)
        self._list.setMinimumWidth(220)
        layout.addWidget(self._list)

        actions_row = QVBoxLayout()
        clear_btn = QPushButton("Tout désélectionner", container)
        clear_btn.clicked.connect(self._clear_all)
        actions_row.addWidget(clear_btn)
        layout.addLayout(actions_row)

        widget_action = QWidgetAction(self._menu)
        widget_action.setDefaultWidget(container)
        self._menu.addAction(widget_action)
        self.setMenu(self._menu)
        self._update_text()

    def set_values(self, values: list[str]) -> None:
        self._all_values = list(values)
        self._selected &= set(values)  # ne garde que les valeurs encore valides
        self._rebuild_list()
        self._update_text()

    def _rebuild_list(self, filter_text: str = "") -> None:
        self._list.clear()
        self._checkboxes.clear()
        filter_text = filter_text.strip().lower()
        for value in self._all_values:
            if filter_text and filter_text not in value.lower():
                continue
            item = QListWidgetItem(self._list)
            checkbox = QCheckBox(value)
            checkbox.setChecked(value in self._selected)
            checkbox.stateChanged.connect(lambda _state, v=value: self._on_toggle(v))
            self._list.setItemWidget(item, checkbox)
            self._checkboxes[value] = checkbox

    def _on_search(self, text: str) -> None:
        self._rebuild_list(text)

    def _on_toggle(self, value: str) -> None:
        checkbox = self._checkboxes.get(value)
        if checkbox is None:
            return
        if checkbox.isChecked():
            self._selected.add(value)
        else:
            self._selected.discard(value)
        self._update_text()
        self.selectionChanged.emit()

    def _clear_all(self) -> None:
        self._selected.clear()
        for cb in self._checkboxes.values():
            cb.blockSignals(True)
            cb.setChecked(False)
            cb.blockSignals(False)
        self._update_text()
        self.selectionChanged.emit()

    def selected_values(self) -> set[str]:
        return set(self._selected)

    def set_selected_values(self, values: set[str]) -> None:
        self._selected = set(values) & set(self._all_values)
        self._rebuild_list(self._search.text())
        self._update_text()

    def _update_text(self) -> None:
        n = len(self._selected)
        if n == 0:
            self.setText(f"{self._label} : Tous")
        elif n == 1:
            self.setText(f"{self._label} : {next(iter(self._selected))}")
        else:
            self.setText(f"{self._label} : {n} sélectionnés")
