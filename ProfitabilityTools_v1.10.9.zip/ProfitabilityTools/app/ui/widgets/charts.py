"""
Fabriques de graphiques (cahier des charges §12) : courbes pour les
évolutions temporelles, barres pour les comparaisons, donut pour les
répartitions simples (avec modération — jamais plus d'une poignée de
catégories).
"""
from __future__ import annotations

from PySide6.QtCharts import (
    QBarCategoryAxis, QBarSeries, QBarSet, QChart, QChartView, QLineSeries,
    QPieSeries, QValueAxis,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter

# Palette catégorielle sobre, réutilisée pour toutes les séries (cf. skill dataviz).
_SERIES_COLORS = ["#2952A3", "#1F8A4C", "#B8860B", "#8E5FB0", "#C0392B", "#3892A6"]


def _base_chart(title: str, palette: dict) -> QChart:
    chart = QChart()
    chart.setTitle(title)
    chart.legend().setVisible(True)
    chart.legend().setAlignment(Qt.AlignmentFlag.AlignBottom)
    chart.setBackgroundBrush(QColor(palette["surface"]))
    chart.setTitleBrush(QColor(palette["text"]))
    chart.legend().setLabelColor(QColor(palette["text"]))
    return chart


def _view(chart: QChart) -> QChartView:
    view = QChartView(chart)
    view.setRenderHint(QPainter.RenderHint.Antialiasing)
    view.setMinimumHeight(260)
    return view


def line_chart(title: str, categories: list[str], series_data: dict[str, list[float]], palette: dict) -> QChartView:
    chart = _base_chart(title, palette)
    axis_x = QBarCategoryAxis()
    axis_x.append(categories or [""])
    axis_x.setLabelsColor(QColor(palette["text_muted"]))

    axis_y = QValueAxis()
    axis_y.setLabelsColor(QColor(palette["text_muted"]))

    chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)
    chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)

    for i, (name, values) in enumerate(series_data.items()):
        line = QLineSeries()
        line.setName(name)
        line.setColor(QColor(_SERIES_COLORS[i % len(_SERIES_COLORS)]))
        for x, v in enumerate(values):
            line.append(x, float(v))
        chart.addSeries(line)
        line.attachAxis(axis_x)
        line.attachAxis(axis_y)

    if not series_data:
        chart.addSeries(QLineSeries())

    return _view(chart)


def bar_chart(title: str, categories: list[str], series_data: dict[str, list[float]], palette: dict, horizontal: bool = False) -> QChartView:
    chart = _base_chart(title, palette)
    bar_series = QBarSeries()
    for i, (name, values) in enumerate(series_data.items()):
        bar_set = QBarSet(name)
        bar_set.append([float(v) for v in values])
        bar_set.setColor(QColor(_SERIES_COLORS[i % len(_SERIES_COLORS)]))
        bar_series.append(bar_set)
    chart.addSeries(bar_series)

    axis_x = QBarCategoryAxis()
    axis_x.append(categories or [""])
    axis_x.setLabelsColor(QColor(palette["text_muted"]))
    axis_y = QValueAxis()
    axis_y.setLabelsColor(QColor(palette["text_muted"]))

    chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)
    chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)
    bar_series.attachAxis(axis_x)
    bar_series.attachAxis(axis_y)

    return _view(chart)


def donut_chart(title: str, data: dict[str, float], palette: dict) -> QChartView:
    chart = _base_chart(title, palette)
    series = QPieSeries()
    series.setHoleSize(0.45)
    for i, (name, value) in enumerate(data.items()):
        sl = series.append(name, float(value))
        sl.setLabelVisible(True)
        sl.setLabelColor(QColor(palette["text"]))
        sl.setColor(QColor(_SERIES_COLORS[i % len(_SERIES_COLORS)]))
    chart.addSeries(series)
    return _view(chart)
