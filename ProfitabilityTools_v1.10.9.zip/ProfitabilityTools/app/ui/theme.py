"""
Thème Material Design (clair / sombre) — cahier des charges §18.

Depuis la v1.2.0, ce thème suit les conventions Material Design 3 (Google) :
  - Jetons de couleur "tonal" (surface / surface-container à plusieurs
    niveaux, container/on-container par couleur sémantique) plutôt que de
    simples couleurs plates — permet une hiérarchie visuelle cohérente en
    clair comme en sombre.
  - Formes différenciées par type de composant ("shape scale" M3) :
    boutons en pilule (forme "full"), cartes/tableaux en coins moyens
    (12px), champs de saisie en coins extra-petits (4px), badges/chips en
    pilule.
  - États "state layer" (survol/appui) via des surimpressions semi-
    transparentes plutôt que des changements de couleur brutaux.
  - Élévation : les cartes reçoivent une véritable ombre portée (voir
    app/ui/main_window.py::_apply_elevation, QGraphicsDropShadowEffect —
    le QSS seul ne permet pas de box-shadow) en plus d'un ton de surface
    légèrement rehaussé (élévation "tonale", propre à Material 3).

La palette reste sobre et orientée finance/assurance : l'accent bleu de
marque existant (#2952A3) est conservé comme couleur "primary".
"""
from __future__ import annotations

LIGHT = {
    # --- Surfaces (échelle d'élévation tonale M3) ---
    "bg": "#F6F7FB",
    "surface": "#FFFFFF",
    "surface_container_low": "#F7F8FC",
    "surface_container": "#F0F2F9",
    "surface_container_high": "#E9ECF6",
    "surface_alt": "#F0F2F5",  # rétro-compatibilité (alias de surface_container)
    "outline": "#C6C9D6",
    "outline_variant": "#E1E4E9",
    "border": "#E1E4E9",  # rétro-compatibilité (alias d'outline_variant)

    # --- Texte ---
    "text": "#1B1C22",
    "on_surface_variant": "#45474F",
    "text_muted": "#5B5E6B",

    # --- Primary (accent de marque) ---
    "accent": "#2952A3",
    "accent_hover": "#1F3F82",
    "primary": "#2952A3",
    "on_primary": "#FFFFFF",
    "primary_container": "#DAE2FF",
    "on_primary_container": "#00174B",

    # --- Couleurs sémantiques (container tonal + on-container) ---
    "success": "#1F8A4C",
    "success_container": "#C3F2D3",
    "on_success_container": "#00210E",
    "warning": "#8A5A00",
    "warning_container": "#FFDEA1",
    "on_warning_container": "#2A1800",
    "danger": "#BA1A1A",
    "danger_container": "#FFDAD6",
    "on_danger_container": "#410002",

    # --- Sidebar (Navigation Drawer M3 — surface "inverse" sombre conservée
    #     comme identité visuelle de marque) ---
    "sidebar_bg": "#111827",
    "sidebar_text": "#C7CCDA",
    "sidebar_text_active": "#FFFFFF",
    "sidebar_active_bg": "#2952A3",
    "sidebar_hover_bg": "rgba(255,255,255,0.08)",

    # (r, g, b, a) — consommé côté Python par QColor(*shadow_color) pour
    # l'ombre portée réelle des cartes (voir main_window.py::_apply_elevation).
    "shadow_color": (20, 24, 38, 60),
}

DARK = {
    "bg": "#101319",
    "surface": "#15181F",
    "surface_container_low": "#191C24",
    "surface_container": "#1F222C",
    "surface_container_high": "#262A35",
    "surface_alt": "#1F222C",
    "outline": "#8D909C",
    "outline_variant": "#3C3F4A",
    "border": "#3C3F4A",

    "text": "#E4E5EC",
    "on_surface_variant": "#C5C6D0",
    "text_muted": "#A0A3B0",

    "accent": "#AFC6FF",
    "accent_hover": "#C7D7FF",
    "primary": "#AFC6FF",
    "on_primary": "#062E67",
    "primary_container": "#1F3F82",
    "on_primary_container": "#DAE2FF",

    "success": "#8CD9A8",
    "success_container": "#00522A",
    "on_success_container": "#A8F3BF",
    "warning": "#F0BE63",
    "warning_container": "#5B4300",
    "on_warning_container": "#FFDEA1",
    "danger": "#FFB4AB",
    "danger_container": "#93000A",
    "on_danger_container": "#FFDAD6",

    "sidebar_bg": "#0A0E17",
    "sidebar_text": "#AEB6C4",
    "sidebar_text_active": "#FFFFFF",
    "sidebar_active_bg": "#3A5DA8",
    "sidebar_hover_bg": "rgba(255,255,255,0.06)",

    "shadow_color": (0, 0, 0, 120),
}

# Échelle de formes Material 3 : chaque famille de composant a un rayon dédié.
_SHAPE_EXTRA_SMALL = "4px"   # champs de saisie
_SHAPE_SMALL = "8px"        # petits éléments (badge non-pilule, tooltip)
_SHAPE_MEDIUM = "12px"      # cartes, tableau, onglets
_SHAPE_FULL = "18px"        # boutons, chips (forme pilule)


def build_stylesheet(palette: dict) -> str:
    p = palette
    return f"""
    QWidget {{
        background-color: {p['bg']};
        color: {p['text']};
        font-family: "Roboto", "Segoe UI", "Helvetica Neue", Arial, sans-serif;
        font-size: 13px;
    }}
    QMainWindow {{ background-color: {p['bg']}; }}

    /* --- Sidebar (Navigation Drawer M3) --- */
    QListWidget#Sidebar {{
        background-color: {p['sidebar_bg']};
        border: none;
        padding: 12px 8px;
        outline: 0;
    }}
    QListWidget#Sidebar::item {{
        color: {p['sidebar_text']};
        padding: 10px 16px;
        border-radius: {_SHAPE_FULL};
        margin: 2px 4px;
    }}
    QListWidget#Sidebar::item:selected {{
        background-color: {p['sidebar_active_bg']};
        color: {p['sidebar_text_active']};
        font-weight: 600;
    }}
    QListWidget#Sidebar::item:hover:!selected {{
        background-color: {p['sidebar_hover_bg']};
    }}

    /* --- Header (Top App Bar M3) --- */
    QFrame#Header {{
        background-color: {p['surface']};
        border-bottom: 1px solid {p['outline_variant']};
    }}
    QLabel#HeaderLogo {{ margin-right: 10px; }}
    QLabel#HeaderTitle {{ font-size: 18px; font-weight: 600; letter-spacing: 0.1px; }}
    QLabel#EnvBadge {{
        background-color: {p['primary_container']};
        color: {p['on_primary_container']};
        border-radius: {_SHAPE_FULL};
        padding: 4px 14px;
        font-weight: 700;
        font-size: 11px;
    }}
    QLabel#EnvBadgeProd {{
        background-color: {p['danger_container']};
        color: {p['on_danger_container']};
        border-radius: {_SHAPE_FULL};
        padding: 4px 14px;
        font-weight: 700;
        font-size: 11px;
    }}

    /* --- Cards (élévation tonale ; l'ombre portée réelle est appliquée en
         Python via QGraphicsDropShadowEffect — voir main_window.py) --- */
    QFrame.Card {{
        background-color: {p['surface_container_low']};
        border: 1px solid {p['outline_variant']};
        border-radius: {_SHAPE_MEDIUM};
    }}
    QLabel.CardLabel {{ color: {p['text_muted']}; font-size: 12px; font-weight: 500; }}
    QLabel.CardValue {{ font-size: 24px; font-weight: 700; letter-spacing: -0.2px; }}
    QLabel.SectionTitle {{ font-size: 15px; font-weight: 600; padding: 4px 0px; letter-spacing: 0.1px; }}
    QLabel.Muted {{ color: {p['text_muted']}; }}
    QLabel.SuccessText {{
        color: {p['on_success_container']};
        background-color: {p['success_container']};
        border-radius: {_SHAPE_SMALL};
        padding: 6px 10px;
        font-weight: 600;
    }}
    QLabel.ErrorText {{
        color: {p['on_danger_container']};
        background-color: {p['danger_container']};
        border-radius: {_SHAPE_SMALL};
        padding: 6px 10px;
        font-weight: 600;
    }}

    /* --- Buttons (Filled / Outlined M3 — forme pilule) --- */
    QPushButton {{
        background-color: transparent;
        color: {p['primary']};
        border: 1px solid {p['outline']};
        border-radius: {_SHAPE_FULL};
        padding: 9px 20px;
        font-weight: 600;
    }}
    QPushButton:hover {{ background-color: {p['surface_container']}; }}
    QPushButton:pressed {{ background-color: {p['surface_container_high']}; }}
    QPushButton:disabled {{ color: {p['text_muted']}; border-color: {p['outline_variant']}; }}
    QPushButton#PrimaryButton {{
        background-color: {p['primary']};
        color: {p['on_primary']};
        border: none;
    }}
    QPushButton#PrimaryButton:hover {{ background-color: {p['accent_hover']}; }}
    QPushButton#PrimaryButton:pressed {{ background-color: {p['accent_hover']}; }}

    /* --- Inputs (Outlined text field M3 — coins extra-petits) --- */
    QLineEdit, QComboBox, QDateEdit, QSpinBox {{
        background-color: {p['surface']};
        color: {p['text']};
        border: 1px solid {p['outline']};
        border-radius: {_SHAPE_EXTRA_SMALL};
        padding: 6px 10px;
        selection-background-color: {p['primary_container']};
        selection-color: {p['on_primary_container']};
    }}
    QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QSpinBox:focus {{
        border: 2px solid {p['primary']};
        padding: 5px 9px;
    }}
    QComboBox::drop-down {{ border: none; width: 22px; }}
    QComboBox QAbstractItemView {{
        background-color: {p['surface']};
        border: 1px solid {p['outline_variant']};
        border-radius: {_SHAPE_EXTRA_SMALL};
        selection-background-color: {p['primary_container']};
        selection-color: {p['on_primary_container']};
        outline: 0;
    }}
    QCheckBox::indicator {{
        width: 16px; height: 16px;
        border: 2px solid {p['outline']};
        border-radius: 3px;
        background-color: {p['surface']};
    }}
    QCheckBox::indicator:checked {{
        background-color: {p['primary']};
        border-color: {p['primary']};
    }}

    /* --- Table (Data table M3) --- */
    QTableView {{
        background-color: {p['surface_container_low']};
        alternate-background-color: {p['surface']};
        gridline-color: {p['outline_variant']};
        border: 1px solid {p['outline_variant']};
        border-radius: {_SHAPE_MEDIUM};
        selection-background-color: {p['primary_container']};
        selection-color: {p['on_primary_container']};
    }}
    QTableView::item {{
        padding: 6px 10px;
        border: none;
    }}
    QTableView::item:hover {{
        background-color: {p['surface_container_high']};
    }}
    QTableView::item:selected {{
        background-color: {p['primary_container']};
        color: {p['on_primary_container']};
    }}
    /* Colonne figée (FrozenColumnTableView, v1.9.0) : même fond que le
       tableau principal, avec une ligne de séparation nette pour signaler
       qu'elle reste visible pendant le défilement horizontal. */
    QTableView#FrozenColumn {{
        background-color: {p['surface_container_low']};
        alternate-background-color: {p['surface']};
        border: none;
        border-right: 2px solid {p['outline']};
        selection-background-color: {p['primary_container']};
        selection-color: {p['on_primary_container']};
    }}
    QHeaderView::section {{
        background-color: {p['surface_container']};
        color: {p['on_surface_variant']};
        padding: 8px 6px;
        border: none;
        border-bottom: 1px solid {p['outline_variant']};
        font-weight: 600;
        font-size: 12px;
    }}

    /* --- Tabs / misc --- */
    QTabWidget::pane {{ border: 1px solid {p['outline_variant']}; border-radius: {_SHAPE_MEDIUM}; }}
    QTabBar::tab {{
        background-color: transparent;
        color: {p['text_muted']};
        padding: 8px 18px;
        border-radius: {_SHAPE_FULL};
        margin: 4px 2px;
    }}
    QTabBar::tab:selected {{
        background-color: {p['primary_container']};
        color: {p['on_primary_container']};
        font-weight: 600;
    }}
    QScrollArea {{ border: none; }}
    QScrollBar:vertical {{
        background-color: transparent;
        width: 10px;
        margin: 2px;
    }}
    QScrollBar::handle:vertical {{
        background-color: {p['outline']};
        border-radius: 5px;
        min-height: 24px;
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
    QScrollBar:horizontal {{
        background-color: transparent;
        height: 12px;
        margin: 2px;
    }}
    QScrollBar::handle:horizontal {{
        background-color: {p['outline']};
        border-radius: 6px;
        min-width: 24px;
    }}
    QScrollBar::handle:horizontal:hover {{ background-color: {p['accent']}; }}
    QScrollBar::handle:vertical:hover {{ background-color: {p['accent']}; }}
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal,
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: none; }}
    QToolTip {{
        background-color: {p['surface_container_high']};
        color: {p['text']};
        border: 1px solid {p['outline_variant']};
        border-radius: {_SHAPE_SMALL};
        padding: 6px 8px;
    }}
    """


def palette_for(mode: str) -> dict:
    return DARK if mode == "dark" else LIGHT
