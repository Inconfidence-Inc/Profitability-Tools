"""
État applicatif partagé : dataset ProfitabilityTools courant, filtres
globaux actifs (cahier des charges §13) et notification des pages via
signaux Qt. Aucune règle métier ici — uniquement de la coordination UI ;
tous les calculs restent dans app.core.*.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import logging

from PySide6.QtCore import QObject, Signal

from app.core.aggregation import build_profitability_dataset
from app.core.models import ProfitabilityRow
from app.data.provider import DataProvider

logger = logging.getLogger("profitabilitytools.state")


@dataclass
class FilterState:
    annees: set[int] = field(default_factory=set)
    mois: set[int] = field(default_factory=set)
    compagnies: set[str] = field(default_factory=set)
    distributeurs: set[str] = field(default_factory=set)
    tpas: set[str] = field(default_factory=set)
    produits: set[str] = field(default_factory=set)
    regularisations: set[str] = field(default_factory=set)
    pays: set[str] = field(default_factory=set)
    courtiers: set[str] = field(default_factory=set)
    contrats: set[str] = field(default_factory=set)
    references: set[str] = field(default_factory=set)
    devises: set[str] = field(default_factory=set)
    price_ranges: set[str] = field(default_factory=set)

    def is_empty(self) -> bool:
        return not any(
            [
                self.annees, self.mois, self.compagnies, self.distributeurs,
                self.tpas, self.produits, self.regularisations, self.pays,
                self.courtiers, self.contrats,
                self.references, self.devises, self.price_ranges,
            ]
        )

    def active_count(self) -> int:
        return sum(
            len(x) for x in [
                self.annees, self.mois, self.compagnies, self.distributeurs,
                self.tpas, self.produits, self.regularisations, self.pays,
                self.courtiers, self.contrats,
                self.references, self.devises, self.price_ranges,
            ]
        )

    def clone(self) -> "FilterState":
        return FilterState(
            annees=set(self.annees), mois=set(self.mois),
            compagnies=set(self.compagnies), distributeurs=set(self.distributeurs),
            tpas=set(self.tpas), produits=set(self.produits),
            regularisations=set(self.regularisations), pays=set(self.pays),
            courtiers=set(self.courtiers), contrats=set(self.contrats),
            references=set(self.references), devises=set(self.devises),
            price_ranges=set(self.price_ranges),
        )


def apply_filters(rows: list[ProfitabilityRow], filters: FilterState) -> list[ProfitabilityRow]:
    if filters.is_empty():
        return list(rows)

    out = []
    for r in rows:
        if filters.annees and r.annee not in filters.annees:
            continue
        if filters.mois and r.mois not in filters.mois:
            continue
        if filters.compagnies and r.compagny not in filters.compagnies:
            continue
        if filters.distributeurs and r.distributor not in filters.distributeurs:
            continue
        if filters.tpas and r.tpa not in filters.tpas:
            continue
        if filters.produits and r.eligible_product not in filters.produits:
            continue
        if filters.regularisations and r.regularisation not in filters.regularisations:
            continue
        if filters.pays and r.pays not in filters.pays:
            continue
        if filters.courtiers and r.courtier not in filters.courtiers:
            continue
        if filters.contrats and r.identifiant_contrat_tdb not in filters.contrats:
            continue
        if filters.references and r.reference not in filters.references:
            continue
        if filters.devises and r.devise not in filters.devises:
            continue
        if filters.price_ranges and r.price_range not in filters.price_ranges:
            continue
        out.append(r)
    return out


class AppState(QObject):
    datasetChanged = Signal()
    filtersChanged = Signal()
    dataModeChanged = Signal(str)
    themeChanged = Signal(str)
    loadError = Signal(str)

    def __init__(self, provider: DataProvider, theme: str = "light"):
        super().__init__()
        self._provider = provider
        self._rows: list[ProfitabilityRow] = []
        self._sinistres_rows: list[dict] = []
        self._filters = FilterState()
        self._theme = theme

    # --- provider / dataset -------------------------------------------------
    @property
    def provider(self) -> DataProvider:
        return self._provider

    def reload(self) -> None:
        """Recharge le dataset ET les sinistres bruts (pour Data Quality) en
        une seule fois, avec une gestion d'erreur unique : aucune page ne
        doit jamais appeler un DataProvider directement (une connexion SQL
        Server non configurée/indisponible ne doit jamais faire planter
        l'UI — voir app.data.sqlserver_provider.SqlServerConnectionError).
        Chaque source n'est récupérée qu'une seule fois (pas de double
        appel réseau/SQL entre le dataset consolidé et les sinistres bruts)."""
        try:
            part1 = self._provider.fetch_part1_rows()
            referentiel = self._provider.fetch_referentiel_rows()
            part2 = self._provider.fetch_part2_rows()
            sinistres = self._provider.fetch_sinistres_rows()
            self._sinistres_rows = sinistres
            self._rows = build_profitability_dataset(
                part1, referentiel, part2, sinistres, is_demo_data=self._provider.is_demo
            )
        except Exception as exc:  # noqa: BLE001 - remonté proprement à l'UI
            self._rows = []
            self._sinistres_rows = []
            self.loadError.emit(str(exc))
            self.datasetChanged.emit()
            return

        # datasetChanged déclenche le refresh() de toutes les pages (Dashboard,
        # Explorer, Contracts, Claims, Data Quality) : une donnée réelle peut
        # révéler un cas limite absent du jeu DEMO (valeur inattendue dans un
        # graphique, un tri, ...). Sans ce try/except, une exception levée à
        # ce stade remonterait non interceptée à travers le signal Qt et
        # fermerait l'application entière sans message (comportement par
        # défaut de PySide6/Qt sur une exception Python non gérée dans un
        # slot) — voir aussi le filet de sécurité global dans app/main.py.
        try:
            self.datasetChanged.emit()
        except Exception as exc:  # noqa: BLE001
            logger.exception("Échec du rafraîchissement de l'interface après rechargement des données")
            self.loadError.emit(
                f"Les données ont été chargées mais l'affichage a échoué : {exc}"
            )

    @property
    def sinistres_rows(self) -> list[dict]:
        """Lignes sinistres brutes (déjà chargées lors du dernier reload()),
        utilisées par la page Data Quality pour détecter les sinistres
        orphelins — jamais rechargées à la volée depuis l'UI."""
        return self._sinistres_rows

    def set_provider(self, provider: DataProvider) -> None:
        self._provider = provider
        self._filters = FilterState()
        self.reload()
        self.dataModeChanged.emit(provider.mode_name)

    @property
    def all_rows(self) -> list[ProfitabilityRow]:
        return self._rows

    @property
    def filtered_rows(self) -> list[ProfitabilityRow]:
        return apply_filters(self._rows, self._filters)

    # --- filtres --------------------------------------------------------
    @property
    def filters(self) -> FilterState:
        return self._filters

    def set_filters(self, filters: FilterState) -> None:
        self._filters = filters
        self.filtersChanged.emit()

    def reset_filters(self) -> None:
        self._filters = FilterState()
        self.filtersChanged.emit()

    # --- theme ------------------------------------------------------------
    @property
    def theme(self) -> str:
        return self._theme

    def set_theme(self, theme: str) -> None:
        self._theme = theme
        self.themeChanged.emit(theme)

    # --- distinct values pour peupler les filtres -------------------------
    def distinct(self, field_name: str) -> list[str]:
        values = {str(getattr(r, field_name)) for r in self._rows if getattr(r, field_name) not in (None, "")}
        return sorted(values)
