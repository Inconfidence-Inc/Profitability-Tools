"""Point d'entrée ProfitabilityTools."""
from __future__ import annotations

import logging
import os
import sys
import traceback
from pathlib import Path

# Permet de lancer ce fichier directement (double-clic sur app/main.py, ou
# "python app/main.py" depuis le dossier app) même si le package "app"
# n'est pas sur sys.path dans ce cas. La façon recommandée reste
# "python -m app.main" depuis la racine du projet (ou lancer.bat), mais on
# ne veut pas que l'application refuse de démarrer si l'utilisateur double-
# clique directement sur ce fichier.
if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PySide6.QtWidgets import QApplication, QDialog, QMessageBox  # noqa: E402

from app.auth.setup import ensure_auth_backend_ready  # noqa: E402
from app.config.settings import get_app_settings  # noqa: E402
from app.data.sqlserver_provider import build_provider_from_env  # noqa: E402
from app.ui.icons import app_icon  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402

# Fichier de log toujours écrit à côté du projet (racine), y compris pour un
# exécutable construit en mode --windowed (build_exe.bat) qui n'a AUCUNE
# console : c'est alors la seule trace visible d'une erreur.
LOG_PATH = Path(__file__).resolve().parents[1] / "profitabilitytools_error.log"


def _configure_logging() -> None:
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    try:
        handlers.append(logging.FileHandler(LOG_PATH, encoding="utf-8"))
    except OSError:
        pass  # dossier non inscriptible : on continue avec la console seule
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )


def _install_global_excepthook() -> None:
    """Filet de sécurité global : sans ceci, une exception Python levée
    dans un slot Qt (un clic de bouton, un signal, ...) fait fermer
    l'application ENTIÈRE de façon abrupte et silencieuse (comportement par
    défaut de PySide6/Qt), en particulier dans un exécutable --windowed où
    il n'y a aucune console pour voir l'erreur. En installant notre propre
    sys.excepthook, on journalise l'erreur et on affiche une boîte de
    dialogue au lieu de laisser Qt fermer le programme sans explication."""

    def _handle(exc_type, exc_value, exc_tb) -> None:
        logging.getLogger("profitabilitytools").critical(
            "Erreur non gérée dans l'application", exc_info=(exc_type, exc_value, exc_tb)
        )
        try:
            detail = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
            QMessageBox.critical(
                None,
                "ProfitabilityTools — erreur inattendue",
                "Une erreur inattendue est survenue. L'application reste ouverte, "
                "mais l'opération en cours a échoué.\n\n"
                f"Détail journalisé dans :\n{LOG_PATH}\n\n"
                f"{exc_type.__name__}: {exc_value}",
            )
            logging.getLogger("profitabilitytools").debug(detail)
        except Exception:
            pass  # ne jamais lever depuis le gestionnaire d'erreurs lui-même

    sys.excepthook = _handle


def _login() -> object | None:
    """Affiche la boîte de connexion ProfitabilityTools (v1.10.0, module
    partagé auth_partage — voir app/auth/) et renvoie le compte connecté
    (auth_partage.service.CurrentUser), ou None si la base d'authentification
    locale n'a pas pu être créée, ou si l'utilisateur annule la connexion —
    dans les deux cas, l'application doit se fermer proprement, sans message
    d'erreur pour une simple annulation."""
    ok, message = ensure_auth_backend_ready()
    auth_logger = logging.getLogger("profitabilitytools.auth")
    if not ok:
        auth_logger.error("Échec d'initialisation de l'authentification : %s", message)
        QMessageBox.critical(
            None, "ProfitabilityTools — authentification",
            "Impossible d'initialiser la base d'authentification locale :\n\n"
            f"{message}",
        )
        return None
    auth_logger.info(message)

    from app.ui.dialogs.login_screen import build_login_dialog

    boite = build_login_dialog(sous_titre="Analyse de rentabilité — ICI Assurance")
    if boite.exec() != QDialog.Accepted:
        return None
    return boite.current_user


def main() -> int:
    _configure_logging()

    app = QApplication(sys.argv)
    app.setApplicationName("ProfitabilityTools")
    app.setOrganizationName("ICI Assurance")
    app.setWindowIcon(app_icon())  # icône fenêtre/barre des tâches (v1.5.0)

    _install_global_excepthook()

    settings = get_app_settings()
    provider = build_provider_from_env()

    # Boucle de déconnexion (v1.10.0) : se déconnecter depuis le header
    # rouvre l'écran de connexion sans redémarrer tout le processus — une
    # nouvelle MainWindow est reconstruite pour le compte qui se reconnecte
    # (ou un autre), plutôt que de réutiliser une fenêtre qui porterait
    # encore des widgets/état du compte précédent.
    while True:
        current_user = _login()
        if current_user is None:
            return 0  # annulation ou échec d'amorçage déjà signalé : fermeture propre

        etat = {"deconnexion": False}
        window = MainWindow(
            provider, theme=settings.theme,
            current_user=current_user,
            on_logout=lambda: etat.__setitem__("deconnexion", True),
        )
        window.show()
        app.exec()
        if not etat["deconnexion"]:
            return 0


if __name__ == "__main__":
    # Filet de sécurité supplémentaire : si une erreur survient AVANT que
    # QApplication/l'excepthook global ne soient en place (ex. import qui
    # échoue), la fenêtre de console ne doit jamais se refermer instantanément
    # sans que l'erreur soit lisible, et l'erreur doit aussi être journalisée
    # (utile en exécutable --windowed, sans console).
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except BaseException:
        traceback.print_exc()
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write("\n--- Erreur fatale au démarrage ---\n")
                traceback.print_exc(file=f)
        except OSError:
            pass
        try:
            _app = QApplication.instance() or QApplication(sys.argv)
            QMessageBox.critical(
                None,
                "ProfitabilityTools — erreur fatale",
                "Une erreur empêche le démarrage de l'application.\n"
                f"Détail journalisé dans :\n{LOG_PATH}",
            )
        except Exception:
            pass
        try:
            input("\nUne erreur est survenue (détail ci-dessus). Appuyez sur Entrée pour fermer...")
        except Exception:
            pass
        sys.exit(1)
