"""Lecture/écriture du fichier .env depuis l'interface (onglet Settings).

RÈGLE DE SÉCURITÉ (cahier des charges §21) — inchangée : les identifiants ne
sont jamais codés en dur dans le code source. Ce module ne fait qu'écrire,
depuis l'UI, les valeurs saisies par l'utilisateur dans le fichier .env
local (non versionné — voir .gitignore) : c'est strictement équivalent à
éditer .env à la main, juste plus pratique. Les valeurs ne sont jamais
journalisées (aucun appel logger ici) et ne transitent jamais ailleurs que
dans le fichier .env et les variables d'environnement du process courant.
"""
from __future__ import annotations

import os
from pathlib import Path

DEFAULT_ENV_PATH = Path(__file__).resolve().parents[2] / ".env"

# Commentaire d'en-tête utilisé quand .env n'existe pas encore (première
# sauvegarde depuis l'UI) — reprend celui de .env.example pour ne jamais
# perdre le rappel de sécurité.
_HEADER = (
    "# ============================================================================\n"
    "# ProfitabilityTools — configuration d'environnement\n"
    "# Ce fichier ne doit JAMAIS être versionné (voir .gitignore) : c'est le seul\n"
    "# endroit où les identifiants SQL Server doivent apparaître — jamais dans le\n"
    "# code source (cahier des charges §21).\n"
    "# Généré/mis à jour depuis l'onglet Settings de l'application.\n"
    "# ============================================================================\n"
)


def _parse_line_key(line: str) -> str | None:
    stripped = line.strip()
    if not stripped or stripped.startswith("#") or "=" not in stripped:
        return None
    return stripped.split("=", 1)[0].strip()


def write_env_values(updates: dict[str, str], env_path: Path = DEFAULT_ENV_PATH) -> Path:
    """Met à jour (ou crée) le fichier .env avec les paires clé/valeur de
    `updates`, en conservant l'ordre, les commentaires et les clés non
    concernées déjà présentes. Une clé absente du fichier est ajoutée à la
    fin. Retourne le chemin écrit."""
    existing_lines: list[str] = []
    if env_path.exists():
        existing_lines = env_path.read_text(encoding="utf-8").splitlines(keepends=True)

    remaining = dict(updates)
    new_lines: list[str] = []
    for line in existing_lines:
        key = _parse_line_key(line)
        if key is not None and key in remaining:
            new_lines.append(f"{key}={remaining.pop(key)}\n")
        else:
            new_lines.append(line if line.endswith("\n") else line + "\n")

    if not existing_lines:
        new_lines.append(_HEADER)
        new_lines.append("\n")

    if remaining:
        if new_lines and new_lines[-1].strip() != "":
            new_lines.append("\n")
        for key, value in remaining.items():
            new_lines.append(f"{key}={value}\n")

    env_path.write_text("".join(new_lines), encoding="utf-8")
    return env_path


def reload_env(env_path: Path = DEFAULT_ENV_PATH) -> None:
    """Recharge le fichier .env dans les variables d'environnement du process
    courant, en écrasant les valeurs déjà chargées (override=True) — nécessaire
    après une sauvegarde depuis l'UI pour que le changement soit pris en compte
    sans redémarrer l'application."""
    try:
        from dotenv import load_dotenv
    except ImportError:  # pragma: no cover — dotenv optionnel
        return
    if env_path.exists():
        load_dotenv(env_path, override=True)


def apply_env_updates(updates: dict[str, str], env_path: Path = DEFAULT_ENV_PATH) -> None:
    """Écrit les valeurs dans .env puis les recharge immédiatement dans
    os.environ, pour que get_sql_config()/get_app_settings() reflètent
    aussitôt les nouvelles valeurs saisies dans l'UI."""
    write_env_values(updates, env_path)
    reload_env(env_path)
    # Filet de sécurité si python-dotenv n'est pas installé : on applique
    # quand même les valeurs saisies aux variables d'environnement du
    # process courant (sans passer par le fichier).
    for key, value in updates.items():
        os.environ[key] = value
