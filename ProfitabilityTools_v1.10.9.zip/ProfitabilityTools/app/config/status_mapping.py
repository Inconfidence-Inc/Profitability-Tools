"""
Configuration centralisée du mapping des statuts de sinistres (cahier des
charges §8).

IMPORTANT : ce mapping doit pouvoir évoluer sans réécrire l'application.
Pour ajouter une variante métier, il suffit d'ajouter une entrée dans
CLAIM_STATUS_MAPPING ci-dessous (clé = libellé source normalisé en
minuscules sans accents, valeur = une des 4 catégories de
ClaimStatusCategory). Toute valeur non trouvée retombe sur INCONNU.

Depuis la v1.8.0, ce mapping est réellement utilisé : la source sinistres
réelle est [TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu], une table au
niveau du sinistre brut (un sinistre par ligne, champ Statut_Technique_Sinistre),
et non plus une table pré-agrégée. Les libellés ci-dessous reproduisent la
liste réelle des valeurs distinctes de Statut_Technique_Sinistre fournie par
l'utilisateur (requête GROUP BY sur la table réelle), avec deux décisions
explicitement validées avec lui (ambiguës, donc non devinées) :
  - "Annulé gestion" -> REFUS (assimilé à une clôture sans indemnisation,
    comme "Terminé sans suite"/"Terminé - prescrit").
  - "En attente de prescription" / "En attente prescription" -> EN_COURS
    (dossier encore ouvert, pas une décision définitive).
_normalize_label ne retire PAS les tirets ("-" vs "–" tiret cadratin) ni les
apostrophes — seulement la casse, les accents et les espaces superflus — d'où
la présence de variantes avec/sans tiret ci-dessous pour un même libellé
métier (ex. "Terminé - refusé" vs "Terminé Refuse").
"""
from __future__ import annotations

import unicodedata


class ClaimStatusCategory:
    ACCEPT = "ACCEPT"
    REFUS = "REFUS"
    EN_COURS = "EN_COURS"
    INCONNU = "INCONNU"

    ALL = (ACCEPT, REFUS, EN_COURS, INCONNU)


def _normalize_label(label: str) -> str:
    """minuscule, sans accents, espaces normalisés — clé de recherche stable."""
    if label is None:
        return ""
    text = unicodedata.normalize("NFKD", str(label))
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return " ".join(text.strip().lower().split())


# Libellés métier connus -> catégorie normalisée (cahier des charges §8,
# complété en v1.8.0 avec les valeurs réelles de Statut_Technique_Sinistre
# sur TECH_BI.dbo.SRC_Sinistre_Transformer_Contenu — volumes observés en
# commentaire pour traçabilité, décroissants).
_RAW_MAPPING: dict[str, str] = {
    # ACCEPT
    "termine - accepte": ClaimStatusCategory.ACCEPT,            # "Terminé - accepté" (603138)
    "termine accepte": ClaimStatusCategory.ACCEPT,               # "Terminé accepte" (29081)
    "termine – accepte": ClaimStatusCategory.ACCEPT,        # "Terminé – accepté" (10455, tiret cadratin)
    "regle": ClaimStatusCategory.ACCEPT,                         # "Réglé" (9484)
    # REFUS
    "termine - refuse apres instruction": ClaimStatusCategory.REFUS,   # (214547)
    "termine sans suite": ClaimStatusCategory.REFUS,                    # (149067)
    "termine - prescrit": ClaimStatusCategory.REFUS,                    # (78201)
    "termine - refuse avant instruction": ClaimStatusCategory.REFUS,    # (46650)
    "termine - refuse": ClaimStatusCategory.REFUS,                      # "Terminé - refusé" (24333)
    "annule gestion": ClaimStatusCategory.REFUS,                        # "Annulé gestion" (17877) — validé avec l'utilisateur
    "termine refuse": ClaimStatusCategory.REFUS,                        # "Terminé Refuse" (5571)
    "refuse": ClaimStatusCategory.REFUS,                                # "Refusé" (5233)
    "sans suite": ClaimStatusCategory.REFUS,                            # "Sans suite" (7143)
    "prescrit": ClaimStatusCategory.REFUS,                              # "Prescrit" (8)
    # EN_COURS
    "en cours - accepte": ClaimStatusCategory.EN_COURS,                 # "En cours - accepté" (26235)
    "en attente de prescription": ClaimStatusCategory.EN_COURS,         # (12870) — validé avec l'utilisateur
    "en cours": ClaimStatusCategory.EN_COURS,                           # (9032)
    "en cours accepte": ClaimStatusCategory.EN_COURS,                   # "En cours accepte" (3887)
    "en cours d'instruction": ClaimStatusCategory.EN_COURS,             # (2797)
    "en cours d instruction": ClaimStatusCategory.EN_COURS,             # variante sans apostrophe
    "en cours de reglement": ClaimStatusCategory.EN_COURS,              # "En cours de règlement" (501)
    "en attente prescription": ClaimStatusCategory.EN_COURS,            # "En attente prescription" (161)
    # INCONNU : NULL (665) retombe automatiquement sur INCONNU (clé vide, cf. normalize_claim_status).
}

# Table publique, normalisée à l'import (clé = libellé normalisé).
CLAIM_STATUS_MAPPING: dict[str, str] = {
    _normalize_label(k): v for k, v in _RAW_MAPPING.items()
}


def add_status_mapping(raw_label: str, category: str) -> None:
    """Permet d'enrichir le mapping à chaud (config, UI Settings, etc.)."""
    if category not in ClaimStatusCategory.ALL:
        raise ValueError(f"Catégorie inconnue: {category!r}")
    CLAIM_STATUS_MAPPING[_normalize_label(raw_label)] = category


def normalize_claim_status(raw_label: str | None) -> str:
    """Retourne ACCEPT / REFUS / EN_COURS / INCONNU pour un libellé source."""
    key = _normalize_label(raw_label)
    if not key:
        return ClaimStatusCategory.INCONNU
    return CLAIM_STATUS_MAPPING.get(key, ClaimStatusCategory.INCONNU)
