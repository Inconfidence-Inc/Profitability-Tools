"""
Configuration de l'application, chargée depuis l'environnement (.env).

RÈGLE DE SÉCURITÉ (cahier des charges §21) :
Aucun identifiant, mot de passe ou paramètre de connexion SQL Server ne doit
jamais être codé en dur ici ni ailleurs dans le code. Tout passe par des
variables d'environnement, chargées via python-dotenv depuis un fichier
.env (non versionné — voir .env.example à la racine du projet).

MULTI-ENVIRONNEMENT (v1.6.0, réduit à DEUX profils en v1.10.4) :
Sur demande explicite de l'utilisateur, l'application gère deux profils de
connexion SQL Server indépendants — Recette et Production — plutôt qu'un
profil unique. Chacun est mémorisé sous ses propres clés .env préfixées
(PROFITABILITY_DB_<ENV>_...), de sorte que changer d'environnement actif ne
modifie jamais les réglages de l'autre : les valeurs saisies pour Recette
restent telles quelles tant qu'on ne les modifie pas explicitement, même
après être passé sur Production puis revenu sur Recette (cahier des charges
de la demande : "les données enregistrées doivent rester stockées jusqu'à
la prochaine modification").

Un troisième profil "Local" existait jusqu'en v1.10.3 ; il a été retiré à la
demande explicite de l'utilisateur (v1.10.4), qui souhaite que toute
connexion passe directement par le serveur (Recette ou Production), sans
profil local distinct. Un ancien fichier .env antérieur à ce retrait qui
contenait PROFITABILITY_ACTIVE_ENV=LOCAL et/ou des clés
PROFITABILITY_DB_LOCAL_* continue de démarrer normalement : l'environnement
actif retombe automatiquement sur DEFAULT_ENVIRONMENT (voir
_normalize_environment ci-dessous) et les clés LOCAL devenues orphelines
sont simplement ignorées (elles ne sont ni lues ni supprimées).

Le mode DEMO (données fictives, sélectionnable jusqu'à la v1.5.0) a été
retiré de l'application à la demande de l'utilisateur : ProfitabilityTools
fonctionne désormais exclusivement avec une connexion SQL Server réelle. Le
générateur de données fictives reste disponible pour les tests automatisés
et les captures d'écran de la documentation (voir tests/support/demo_data_provider.py).
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv

    _ENV_PATH = Path(__file__).resolve().parents[2] / ".env"
    if _ENV_PATH.exists():
        load_dotenv(_ENV_PATH)
except ImportError:  # python-dotenv optionnel si les variables sont déjà exportées
    pass


# --- Environnements de connexion disponibles (v1.6.0 ; "Local" retiré en
# v1.10.4 à la demande explicite de l'utilisateur — toute connexion passe
# désormais directement par le serveur, Recette ou Production) -------------
ENVIRONMENTS: tuple[str, ...] = ("RECETTE", "PRODUCTION")
ENVIRONMENT_LABELS: dict[str, str] = {
    "RECETTE": "Recette",
    "PRODUCTION": "Production",
}
DEFAULT_ENVIRONMENT = "RECETTE"


def _normalize_environment(environment: str | None) -> str:
    env = (environment or DEFAULT_ENVIRONMENT).strip().upper()
    return env if env in ENVIRONMENTS else DEFAULT_ENVIRONMENT


def _get_bool(val: str | None, default: bool) -> bool:
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _get_int(val: str | None, default: int) -> int:
    """Comme _get_bool : une valeur absente OU mal formée (ex. un .env
    corrompu ou édité à la main avec une valeur non numérique) ne doit
    jamais empêcher l'application de démarrer — elle retombe silencieusement
    sur la valeur par défaut plutôt que de lever une exception non gérée
    (bug corrigé en v1.5.0 : un ancien code appelait int(...) directement
    sur la valeur du délai de connexion, ce qui plantait tout le démarrage
    de l'application pour une simple valeur invalide)."""
    if val is None:
        return default
    try:
        return int(val.strip())
    except ValueError:
        return default


def _env_value(environment: str, suffix: str) -> str | None:
    """Lit PROFITABILITY_DB_<ENV>_<suffix> ; si absente ET environment ==
    DEFAULT_ENVIRONMENT, retombe sur l'ancienne clé sans préfixe
    d'environnement PROFITABILITY_DB_<suffix> — migration automatique et
    sans perte des fichiers .env créés avant la v1.6.0 (qui ne géraient
    qu'un seul profil, implicitement celui par défaut : "Local" jusqu'en
    v1.10.3, "Recette" depuis le retrait de "Local" en v1.10.4). Lecture
    seule : ceci ne réécrit ni ne supprime jamais l'ancienne clé ; le
    prochain "Enregistrer la configuration" sur l'écran Settings écrit la
    clé préfixée définitive pour l'environnement choisi."""
    prefixed = os.environ.get(f"PROFITABILITY_DB_{environment}_{suffix}")
    if prefixed is not None:
        return prefixed
    if environment == DEFAULT_ENVIRONMENT:
        return os.environ.get(f"PROFITABILITY_DB_{suffix}")
    return None


@dataclass(frozen=True)
class SqlServerConfig:
    """Paramètres de connexion SQL Server pour UN environnement (Recette ou
    Production) — lus uniquement depuis l'environnement.

    Deux modes d'authentification (cahier des charges §21, extension v1.3.0) :
      - SQL Server Authentication (par défaut) : nécessite server + username
        + password, transmis via UID/PWD dans la chaîne ODBC.
      - Authentification Windows ("connexion locale"/"trusted connection") :
        utilise la session Windows courante de l'utilisateur — aucun
        identifiant/mot de passe SQL à saisir ni à stocker. Ne fonctionne
        que si le compte Windows courant a des droits sur le serveur SQL
        (poste joint au domaine de l'entreprise, ou serveur local) ; c'est
        l'équivalent de "Windows Authentication" dans SQL Server Management
        Studio (Trusted_Connection=yes côté ODBC).
    """

    server: str
    database_ici_bi: str
    database_tech_bi: str
    username: str
    password: str
    driver: str
    encrypt: bool
    trust_server_certificate: bool
    timeout_seconds: int
    trusted_connection: bool = False
    environment: str = DEFAULT_ENVIRONMENT

    @classmethod
    def from_env(cls, environment: str = DEFAULT_ENVIRONMENT) -> "SqlServerConfig":
        env = _normalize_environment(environment)
        return cls(
            server=_env_value(env, "SERVER") or "",
            database_ici_bi=_env_value(env, "ICI_BI") or "ICI_BI",
            database_tech_bi=_env_value(env, "TECH_BI") or "TECH_BI",
            username=_env_value(env, "USER") or "",
            password=_env_value(env, "PASSWORD") or "",
            driver=_env_value(env, "DRIVER") or "ODBC Driver 18 for SQL Server",
            encrypt=_get_bool(_env_value(env, "ENCRYPT"), True),
            trust_server_certificate=_get_bool(_env_value(env, "TRUST_CERT"), False),
            timeout_seconds=_get_int(_env_value(env, "TIMEOUT"), 30),
            trusted_connection=_get_bool(_env_value(env, "TRUSTED_CONNECTION"), False),
            environment=env,
        )

    def is_configured(self) -> bool:
        if self.trusted_connection:
            return bool(self.server)
        return bool(self.server and self.username and self.password)

    def odbc_connection_string(self) -> str:
        """Construit la chaîne de connexion ODBC (requêtes paramétrées ensuite — jamais de SQL concaténé)."""
        parts = [
            f"DRIVER={{{self.driver}}}",
            f"SERVER={self.server}",
            f"DATABASE={self.database_ici_bi}",
        ]
        if self.trusted_connection:
            parts.append("Trusted_Connection=yes")
        else:
            parts.append(f"UID={self.username}")
            parts.append(f"PWD={self.password}")
        parts.append(f"Encrypt={'yes' if self.encrypt else 'no'}")
        parts.append(f"TrustServerCertificate={'yes' if self.trust_server_certificate else 'no'}")
        parts.append(f"Connection Timeout={self.timeout_seconds}")
        return ";".join(parts)

    def env_keys(self) -> dict[str, str]:
        """Paires clé/valeur .env (préfixées par cet environnement), prêtes
        à être passées à app.config.env_writer.apply_env_updates. Utilisé
        par l'écran Settings pour enregistrer CE profil sans jamais toucher
        aux clés des deux autres environnements."""
        env = _normalize_environment(self.environment)
        prefix = f"PROFITABILITY_DB_{env}_"
        return {
            f"{prefix}SERVER": self.server,
            f"{prefix}ICI_BI": self.database_ici_bi,
            f"{prefix}TECH_BI": self.database_tech_bi,
            f"{prefix}USER": self.username,
            f"{prefix}PASSWORD": self.password,
            f"{prefix}TRUSTED_CONNECTION": "true" if self.trusted_connection else "false",
            f"{prefix}DRIVER": self.driver,
            f"{prefix}ENCRYPT": "true" if self.encrypt else "false",
            f"{prefix}TRUST_CERT": "true" if self.trust_server_certificate else "false",
            f"{prefix}TIMEOUT": str(self.timeout_seconds),
        }


@dataclass(frozen=True)
class AppSettings:
    active_environment: str  # "RECETTE" | "PRODUCTION"
    theme: str  # "light" ou "dark"

    @classmethod
    def from_env(cls) -> "AppSettings":
        active_environment = _normalize_environment(os.environ.get("PROFITABILITY_ACTIVE_ENV"))
        theme = os.environ.get("PROFITABILITY_THEME", "light").strip().lower()
        if theme not in ("light", "dark"):
            theme = "light"
        return cls(active_environment=active_environment, theme=theme)


def get_sql_config(environment: str | None = None) -> SqlServerConfig:
    """Configuration SQL Server pour `environment` (RECETTE/PRODUCTION),
    ou pour l'environnement actif (PROFITABILITY_ACTIVE_ENV) si omis."""
    if environment is None:
        environment = get_app_settings().active_environment
    return SqlServerConfig.from_env(environment)


def get_app_settings() -> AppSettings:
    return AppSettings.from_env()
