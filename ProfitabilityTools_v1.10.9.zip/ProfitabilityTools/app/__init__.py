"""ProfitabilityTools — application PySide6 d'analyse de profitabilité ICI Assurance."""

__version__ = "1.10.9"
