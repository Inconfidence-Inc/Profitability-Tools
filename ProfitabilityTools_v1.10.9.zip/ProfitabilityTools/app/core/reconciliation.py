"""
Stratégie de réconciliation avec le SQL historique (cahier des charges §23).

Compare le dataset produit par l'application (liste de ProfitabilityRow) à
un extrait du résultat SQL de référence (liste de dicts, mêmes alias de
colonnes que le SELECT final du SQL fourni §25), globalement puis par
Key_Contrat_Date, et fait ressortir les écarts.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from app.core.models import ProfitabilityRow
from app.core.money import to_decimal

# Colonnes numériques comparées (nom champ app -> alias colonne SQL de référence)
_COMPARED_FIELDS: dict[str, str] = {
    "volumes_primes_ttc": "Volumes_Primes_TTC",
    "volumes_primes_ht": "Volumes_Primes_HT",
    "part_assureur": "PartAssureur",
    "total_com": "Total_Com",
    "number_of_subscription": "NumberOfSubscription",
    "nbre_resiliation": "NBRE_RESILIATION",
    "nombre_sinistres_total": "Nombre_Sinistres_Total",
    "montant_total_reglement": "Montant_Total_Règlement",
}


@dataclass
class FieldDiff:
    field: str
    app_value: Decimal
    sql_value: Decimal

    @property
    def delta(self) -> Decimal:
        return self.app_value - self.sql_value


@dataclass
class KeyReconciliation:
    key_contrat_date: str
    diffs: list[FieldDiff]

    @property
    def has_diff(self) -> bool:
        return any(d.delta != 0 for d in self.diffs)


@dataclass
class ReconciliationReport:
    app_row_count: int
    sql_row_count: int
    global_diffs: list[FieldDiff]
    keys_only_in_app: list[str]
    keys_only_in_sql: list[str]
    key_level_diffs: list[KeyReconciliation]

    @property
    def row_count_matches(self) -> bool:
        return self.app_row_count == self.sql_row_count

    @property
    def is_fully_reconciled(self) -> bool:
        return (
            self.row_count_matches
            and not any(d.delta != 0 for d in self.global_diffs)
            and not self.keys_only_in_app
            and not self.keys_only_in_sql
            and not any(k.has_diff for k in self.key_level_diffs)
        )


def reconcile(
    app_rows: Iterable[ProfitabilityRow],
    sql_reference_rows: Iterable[dict],
) -> ReconciliationReport:
    app_rows = list(app_rows)
    sql_rows = list(sql_reference_rows)

    app_by_key: dict[str, list[ProfitabilityRow]] = {}
    for r in app_rows:
        if r.key_contrat_date:
            app_by_key.setdefault(r.key_contrat_date, []).append(r)

    sql_by_key: dict[str, list[dict]] = {}
    for r in sql_rows:
        key = r.get("Key_Contrat_Date")
        if key:
            sql_by_key.setdefault(str(key), []).append(r)

    global_diffs: list[FieldDiff] = []
    for app_field, sql_field in _COMPARED_FIELDS.items():
        app_total = sum((to_decimal(getattr(r, app_field)) for r in app_rows), Decimal("0"))
        sql_total = sum((to_decimal(r.get(sql_field)) for r in sql_rows), Decimal("0"))
        global_diffs.append(FieldDiff(field=app_field, app_value=app_total, sql_value=sql_total))

    keys_only_in_app = sorted(set(app_by_key) - set(sql_by_key))
    keys_only_in_sql = sorted(set(sql_by_key) - set(app_by_key))

    key_level_diffs: list[KeyReconciliation] = []
    for key in sorted(set(app_by_key) & set(sql_by_key)):
        app_group = app_by_key[key]
        sql_group = sql_by_key[key]
        diffs: list[FieldDiff] = []
        for app_field, sql_field in _COMPARED_FIELDS.items():
            app_total = sum((to_decimal(getattr(r, app_field)) for r in app_group), Decimal("0"))
            sql_total = sum((to_decimal(r.get(sql_field)) for r in sql_group), Decimal("0"))
            diffs.append(FieldDiff(field=app_field, app_value=app_total, sql_value=sql_total))
        recon = KeyReconciliation(key_contrat_date=key, diffs=diffs)
        if recon.has_diff:
            key_level_diffs.append(recon)

    return ReconciliationReport(
        app_row_count=len(app_rows),
        sql_row_count=len(sql_rows),
        global_diffs=global_diffs,
        keys_only_in_app=keys_only_in_app,
        keys_only_in_sql=keys_only_in_sql,
        key_level_diffs=key_level_diffs,
    )
