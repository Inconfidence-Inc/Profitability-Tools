"""
Dédoublonnage des sinistres (cahier des charges §9).

Règle métier : lorsqu'un même sinistre apparaît plusieurs fois pour
Numéro_Police + Numéro_Dossier, ne pas le compter plusieurs fois. La ligne
conservée est celle dont le montant total de règlement est le plus élevé.

Depuis la v1.8.0, la source réelle des sinistres est bien une source brute
([TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu], un sinistre par ligne
— voir app/data/sqlserver_provider.py), mais l'utilisateur a confirmé que
chaque ligne y représente un sinistre unique (pas de doublons
Numero_Police + Numero_Dossier observés) : ce module n'est donc PAS appelé
par app.core.aggregation pour cette source. Il reste fourni prêt à l'emploi
(et couvert par tests/test_claims_dedup.py) pour une future source qui en
aurait réellement besoin.
"""
from __future__ import annotations

from typing import Any, Iterable

from app.core.money import to_decimal


def dedupe_claims(
    rows: Iterable[dict[str, Any]],
    police_field: str = "Numero_Police",
    dossier_field: str = "Numero_Dossier",
    montant_field: str = "Montant_Total_Reglement",
) -> list[dict[str, Any]]:
    """Retourne une ligne par (police, dossier), celle au montant le plus élevé.

    En cas d'égalité de montant, la première ligne rencontrée est conservée
    (comportement déterministe et documenté).
    """
    best: dict[tuple[Any, Any], dict[str, Any]] = {}
    best_amount: dict[tuple[Any, Any], Any] = {}

    for row in rows:
        key = (row.get(police_field), row.get(dossier_field))
        amount = to_decimal(row.get(montant_field))
        if key not in best or amount > best_amount[key]:
            best[key] = row
            best_amount[key] = amount

    return list(best.values())
