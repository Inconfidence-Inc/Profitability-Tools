"""
Modèle de données du dataset consolidé ProfitabilityTools (cahier des
charges §4, §6, §7).

RAPPEL IMPORTANT (§1, §24) : "Profitability" n'est PAS une formule
(ex: Prime - Sinistres). C'est ce dataset consolidé lui-même, obtenu après
rapprochement/nettoyage/agrégation/enrichissement des sources. Les KPI et
ratios analytiques (app/core/kpi.py) sont des outils construits AU-DESSUS
de ce dataset, jamais sa définition.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal


@dataclass
class ProfitabilityRow:
    # --- Dimensions (§4) ---
    date_debut_periode_souscription_tdb: str | None = None
    date_fin_periode_souscription_tdb: str | None = None
    compagny: str = ""
    distributor: str = ""
    tpa: str = ""
    eligible_product: str = ""
    regularisation: str = ""
    pays: str = ""
    courtier: str = ""
    identifiant_contrat_tdb: str = ""
    key_contrat_date: str | None = None
    reference: str = ""
    devise: str = ""
    annee: int | None = None
    mois: int | None = None
    price_range: str = ""
    bornes_combinees: str = ""
    borne_min: Decimal | None = None
    borne_max: Decimal | None = None

    # --- Activité / Primes (§6) ---
    number_of_subscription: Decimal = field(default_factory=lambda: Decimal("0"))
    nbre_resiliation: Decimal = field(default_factory=lambda: Decimal("0"))
    volumes_primes_ttc: Decimal = field(default_factory=lambda: Decimal("0"))
    volumes_primes_ht: Decimal = field(default_factory=lambda: Decimal("0"))
    part_assureur: Decimal = field(default_factory=lambda: Decimal("0"))

    # --- Commissions (§6) ---
    commission_ici: Decimal = field(default_factory=lambda: Decimal("0"))
    montant_commission_distributeur: Decimal = field(default_factory=lambda: Decimal("0"))
    commission_tpa: Decimal = field(default_factory=lambda: Decimal("0"))
    sum_other_commission: Decimal = field(default_factory=lambda: Decimal("0"))
    total_com: Decimal = field(default_factory=lambda: Decimal("0"))

    # --- Sinistres (§7) ---
    nombre_sinistres_total: Decimal = field(default_factory=lambda: Decimal("0"))
    montant_total_reglement: Decimal = field(default_factory=lambda: Decimal("0"))
    nb_sinistres_en_cours: Decimal = field(default_factory=lambda: Decimal("0"))
    nb_sinistres_refuses: Decimal = field(default_factory=lambda: Decimal("0"))
    nb_sinistres_acceptes: Decimal = field(default_factory=lambda: Decimal("0"))
    nb_sinistres_inconnus: Decimal = field(default_factory=lambda: Decimal("0"))
    montant_en_cours: Decimal = field(default_factory=lambda: Decimal("0"))
    montant_refuses: Decimal = field(default_factory=lambda: Decimal("0"))
    montant_acceptes: Decimal = field(default_factory=lambda: Decimal("0"))
    montant_inconnus: Decimal = field(default_factory=lambda: Decimal("0"))

    # --- Traçabilité / Data Quality ---
    has_referentiel_match: bool = False
    has_claims_match: bool = False
    is_demo_data: bool = False

    def to_dict(self) -> dict:
        from dataclasses import asdict

        return asdict(self)


COLUMN_LABELS: dict[str, str] = {
    "date_debut_periode_souscription_tdb": "Début période",
    "date_fin_periode_souscription_tdb": "Fin période",
    "compagny": "Compagnie",
    "distributor": "Distributeur",
    "tpa": "TPA",
    "eligible_product": "Produit éligible",
    "regularisation": "Régularisation",
    "pays": "Pays",
    "courtier": "Courtier",
    "identifiant_contrat_tdb": "Contrat",
    "key_contrat_date": "Clé contrat-date",
    "reference": "Référence",
    "devise": "Devise",
    "annee": "Année",
    "mois": "Mois",
    "price_range": "Tranche tarifaire (source)",
    "bornes_combinees": "Bornes tarifaires",
    "number_of_subscription": "Adhésions",
    "nbre_resiliation": "Résiliations",
    "volumes_primes_ttc": "Primes TTC",
    "volumes_primes_ht": "Primes HT",
    "part_assureur": "Part assureur",
    "commission_ici": "Commission ICI",
    "montant_commission_distributeur": "Commission distributeur",
    "commission_tpa": "Commission TPA / Frais gestion",
    "sum_other_commission": "Autres commissions",
    "total_com": "Total commissions",
    "nombre_sinistres_total": "Sinistres (total)",
    "montant_total_reglement": "Montant règlements (total)",
    "nb_sinistres_en_cours": "Sinistres en cours",
    "nb_sinistres_refuses": "Sinistres refusés",
    "nb_sinistres_acceptes": "Sinistres acceptés",
    "nb_sinistres_inconnus": "Sinistres inconnus",
    "montant_en_cours": "Montant en cours",
    "montant_refuses": "Montant refusé",
    "montant_acceptes": "Montant accepté",
    "montant_inconnus": "Montant inconnu",
}

MONEY_FIELDS = {
    "volumes_primes_ttc", "volumes_primes_ht", "part_assureur",
    "commission_ici", "montant_commission_distributeur", "commission_tpa",
    "sum_other_commission", "total_com", "montant_total_reglement",
    "montant_en_cours", "montant_refuses", "montant_acceptes", "montant_inconnus",
}
