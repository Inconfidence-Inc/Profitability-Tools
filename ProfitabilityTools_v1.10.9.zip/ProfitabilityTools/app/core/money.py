"""
Utilitaires financiers Decimal-safe.

RÈGLE (cahier des charges §6) : ne jamais utiliser de flottants imprécis
pour les calculs financiers. Toutes les fonctions ci-dessous travaillent en
decimal.Decimal, avec NULL/None systématiquement traité comme 0 dans les
calculs financiers (§6), et une précision à 2 décimales cohérente avec le
DECIMAL(18,2) utilisé côté SQL Server.
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

TWO_PLACES = Decimal("0.01")


def to_decimal(value: Any, default: Decimal = Decimal("0")) -> Decimal:
    """Convertit une valeur quelconque (None, str, int, float, Decimal) en Decimal.

    NULL / None / chaîne vide / valeur non convertible -> `default` (0 par défaut),
    conformément à la règle métier "NULL doit être considéré comme 0 dans les
    calculs financiers".
    """
    if value is None:
        return default
    if isinstance(value, Decimal):
        return value
    if isinstance(value, str):
        text = value.strip().replace("\xa0", "").replace(" ", "")
        if text == "":
            return default
        text = text.replace(",", ".")
        try:
            return Decimal(text)
        except InvalidOperation:
            return default
    try:
        # Passer par str évite les artefacts binaires d'un float natif.
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return default


def quantize_money(value: Decimal) -> Decimal:
    """Arrondit à 2 décimales (DECIMAL(18,2)), arrondi half-up (convention financière)."""
    return value.quantize(TWO_PLACES, rounding=ROUND_HALF_UP)


def safe_div(numerator: Decimal, denominator: Decimal, default: Decimal = Decimal("0")) -> Decimal:
    """Division sécurisée : dénominateur nul ou None -> `default` (jamais d'exception)."""
    denom = to_decimal(denominator)
    if denom == 0:
        return default
    return to_decimal(numerator) / denom
