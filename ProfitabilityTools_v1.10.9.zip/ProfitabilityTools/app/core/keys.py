"""
Clé fonctionnelle Key_Contrat_Date et parsing des dates métier (cahier des
charges §3-4).

Le SQL de référence stocke DATE DEBUT/FIN PERIODE SOUSCRIPTION en texte au
format dd/MM/yyyy (confirmé par les CONVERT(..., 103) explicites du script
de référence) et construit :

    Key_Contrat_Date = IDENTIFIANT_CONTRAT + "_" + FORMAT(date, 'ddMMyyyy')

Ce module reproduit exactement cette construction.
"""
from __future__ import annotations

from datetime import date, datetime

# Le style SQL Server 103 = dd/mm/yyyy (format métier confirmé côté SQL).
_SOURCE_DATE_FORMAT = "%d/%m/%Y"
_KEY_DATE_FORMAT = "%d%m%Y"


class InvalidBusinessDateError(ValueError):
    """La date source ne respecte pas le format métier dd/MM/yyyy attendu."""


def parse_business_date(raw_value: str | date | datetime | None) -> date | None:
    """Parse une date au format métier dd/MM/yyyy. Retourne None si vide/invalide.

    Une date invalide est une anomalie de Data Quality (§17), pas une exception
    qui doit interrompre le traitement — elle est donc remontée comme None et
    doit être comptabilisée par la couche data_quality.
    """
    if raw_value is None:
        return None
    if isinstance(raw_value, datetime):
        return raw_value.date()
    if isinstance(raw_value, date):
        return raw_value
    text = str(raw_value).strip()
    if not text:
        return None
    try:
        return datetime.strptime(text, _SOURCE_DATE_FORMAT).date()
    except ValueError:
        # Tolérance : certaines extractions renvoient déjà un ISO yyyy-mm-dd.
        try:
            return datetime.strptime(text, "%Y-%m-%d").date()
        except ValueError:
            return None


def build_key_contrat_date(identifiant_contrat: str | None, date_debut_periode: str | date | datetime | None) -> str | None:
    """Reproduit CONCAT(IDENTIFIANT_CONTRAT, '_', FORMAT(date, 'ddMMyyyy')).

    Retourne None si l'identifiant contrat est vide ou si la date est
    invalide/manquante (impossible de construire une clé fiable) — ce cas
    doit être signalé en Data Quality plutôt que produire une clé fausse.
    """
    if identifiant_contrat is None or str(identifiant_contrat).strip() == "":
        return None
    parsed = parse_business_date(date_debut_periode)
    if parsed is None:
        return None
    return f"{str(identifiant_contrat).strip()}_{parsed.strftime(_KEY_DATE_FORMAT)}"


def derive_annee_mois(date_debut_periode: str | date | datetime | None) -> tuple[int | None, int | None]:
    """YEAR()/MONTH() de la date de début de période de souscription."""
    parsed = parse_business_date(date_debut_periode)
    if parsed is None:
        return None, None
    return parsed.year, parsed.month
