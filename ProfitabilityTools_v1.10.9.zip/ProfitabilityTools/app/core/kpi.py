"""
KPI et ratios analytiques (cahier des charges §11).

IMPORTANT : les ratios ci-dessous (claim_frequency, claims_over_premiums_ht,
commission_rate, ...) sont des indicateurs ANALYTIQUES construits au-dessus
du dataset ProfitabilityTools. Ils ne redéfinissent jamais "Profitability"
elle-même (§1, §24). Toute division par zéro est sécurisée (safe_div).
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from app.core.models import ProfitabilityRow
from app.core.money import safe_div, to_decimal


@dataclass
class KpiSummary:
    total_primes_ttc: Decimal
    total_primes_ht: Decimal
    total_part_assureur: Decimal
    total_commissions: Decimal
    total_commission_ici: Decimal
    total_commission_distributeur: Decimal
    total_commission_tpa: Decimal
    total_autres_commissions: Decimal
    nombre_adhesions: Decimal
    nombre_resiliations: Decimal
    nombre_sinistres_total: Decimal
    montant_total_reglement: Decimal
    nombre_sinistres_acceptes: Decimal
    nombre_sinistres_en_cours: Decimal
    nombre_sinistres_refuses: Decimal
    nombre_sinistres_inconnus: Decimal
    nombre_lignes: int

    # --- Ratios analytiques dérivés (division sécurisée) ---
    claim_frequency: Decimal
    claims_over_premiums_ht: Decimal
    commission_rate: Decimal


def compute_kpi_summary(rows: Iterable[ProfitabilityRow]) -> KpiSummary:
    rows = list(rows)

    total_primes_ttc = sum((r.volumes_primes_ttc for r in rows), Decimal("0"))
    total_primes_ht = sum((r.volumes_primes_ht for r in rows), Decimal("0"))
    total_part_assureur = sum((r.part_assureur for r in rows), Decimal("0"))
    total_commission_ici = sum((r.commission_ici for r in rows), Decimal("0"))
    total_commission_distributeur = sum((r.montant_commission_distributeur for r in rows), Decimal("0"))
    total_commission_tpa = sum((r.commission_tpa for r in rows), Decimal("0"))
    total_autres_commissions = sum((r.sum_other_commission for r in rows), Decimal("0"))
    total_commissions = sum((r.total_com for r in rows), Decimal("0"))

    nombre_adhesions = sum((r.number_of_subscription for r in rows), Decimal("0"))
    nombre_resiliations = sum((r.nbre_resiliation for r in rows), Decimal("0"))

    nombre_sinistres_total = sum((r.nombre_sinistres_total for r in rows), Decimal("0"))
    montant_total_reglement = sum((r.montant_total_reglement for r in rows), Decimal("0"))
    nombre_sinistres_acceptes = sum((r.nb_sinistres_acceptes for r in rows), Decimal("0"))
    nombre_sinistres_en_cours = sum((r.nb_sinistres_en_cours for r in rows), Decimal("0"))
    nombre_sinistres_refuses = sum((r.nb_sinistres_refuses for r in rows), Decimal("0"))
    nombre_sinistres_inconnus = sum((r.nb_sinistres_inconnus for r in rows), Decimal("0"))

    return KpiSummary(
        total_primes_ttc=total_primes_ttc,
        total_primes_ht=total_primes_ht,
        total_part_assureur=total_part_assureur,
        total_commissions=total_commissions,
        total_commission_ici=total_commission_ici,
        total_commission_distributeur=total_commission_distributeur,
        total_commission_tpa=total_commission_tpa,
        total_autres_commissions=total_autres_commissions,
        nombre_adhesions=nombre_adhesions,
        nombre_resiliations=nombre_resiliations,
        nombre_sinistres_total=nombre_sinistres_total,
        montant_total_reglement=montant_total_reglement,
        nombre_sinistres_acceptes=nombre_sinistres_acceptes,
        nombre_sinistres_en_cours=nombre_sinistres_en_cours,
        nombre_sinistres_refuses=nombre_sinistres_refuses,
        nombre_sinistres_inconnus=nombre_sinistres_inconnus,
        nombre_lignes=len(rows),
        claim_frequency=safe_div(nombre_sinistres_total, nombre_adhesions),
        claims_over_premiums_ht=safe_div(montant_total_reglement, total_primes_ht),
        commission_rate=safe_div(total_commissions, total_primes_ht),
    )


def top_contracts_by_premiums(rows: Iterable[ProfitabilityRow], limit: int = 10) -> list[ProfitabilityRow]:
    return sorted(rows, key=lambda r: r.volumes_primes_ttc, reverse=True)[:limit]


def top_contracts_by_claims_amount(rows: Iterable[ProfitabilityRow], limit: int = 10) -> list[ProfitabilityRow]:
    return sorted(rows, key=lambda r: r.montant_total_reglement, reverse=True)[:limit]


def group_sum(
    rows: Iterable[ProfitabilityRow],
    group_field: str,
    value_fields: list[str],
    limit: int | None = None,
) -> list[tuple[str, dict[str, Decimal]]]:
    """Regroupe et somme `value_fields` par valeur de `group_field`, trié par
    la première value_field décroissante. Utilisé pour les graphiques de
    performance par compagnie/distributeur/produit/TPA (§12)."""
    buckets: dict[str, dict[str, Decimal]] = {}
    for r in rows:
        key = str(getattr(r, group_field) or "Non renseigné")
        bucket = buckets.setdefault(key, {f: Decimal("0") for f in value_fields})
        for f in value_fields:
            bucket[f] += to_decimal(getattr(r, f))

    items = list(buckets.items())
    if value_fields:
        primary = value_fields[0]
        items.sort(key=lambda kv: kv[1][primary], reverse=True)
    if limit:
        items = items[:limit]
    return items


def monthly_series(rows: Iterable[ProfitabilityRow]) -> list[tuple[str, dict[str, Decimal]]]:
    """Série chronologique (AAAA-MM) de primes/sinistres/adhésions pour les
    graphiques d'évolution mensuelle (§12)."""
    buckets: dict[tuple[int, int], dict[str, Decimal]] = {}
    for r in rows:
        if r.annee is None or r.mois is None:
            continue
        key = (r.annee, r.mois)
        bucket = buckets.setdefault(
            key, {"primes_ttc": Decimal("0"), "primes_ht": Decimal("0"),
                  "sinistres_montant": Decimal("0"), "adhesions": Decimal("0"),
                  "sinistres_nombre": Decimal("0")}
        )
        bucket["primes_ttc"] += r.volumes_primes_ttc
        bucket["primes_ht"] += r.volumes_primes_ht
        bucket["sinistres_montant"] += r.montant_total_reglement
        bucket["adhesions"] += r.number_of_subscription
        bucket["sinistres_nombre"] += r.nombre_sinistres_total

    out = []
    for (annee, mois) in sorted(buckets.keys()):
        label = f"{annee}-{mois:02d}"
        out.append((label, buckets[(annee, mois)]))
    return out
