"""
Normalisation des tranches tarifaires — PRICE_RANGE / BORNES_COMBINEES
(cahier des charges §10).

Ce module reproduit EXACTEMENT la chaîne OUTER APPLY (V1 -> V2 -> V3) du SQL
de référence, étape par étape, afin que la réconciliation avec le SQL reste
possible (cahier des charges §23). Voir les hypothèses documentées ci-dessous
— elles reproduisent des comportements réels du SQL existant, y compris ses
limites connues, plutôt que de les "corriger" silencieusement (règle §24).

Étapes reproduites :
  1) Step1 (V1) : suppression (insensible à la casse) des mots-clés
     'Moins de', 'Plus de', 'et plus', 'PVMC de', 'PVMC', 'TTC', 'euro',
     'EUR', 'PLN', 'ALL'.
  2) Step2 (V2) : remplacement de ' a ' (avec espaces), '/', 'à' par '|'
     (séparateur d'intervalle), suppression de '€', normalisation d'un
     double-espace.
  3) Step3 (V3 / FinalClean) : si un motif "chiffre espace chiffre" est
     détecté, tous les espaces restants sont transformés en '|' (le SQL ne
     distingue alors plus un séparateur de milliers d'un séparateur
     d'intervalle — limite connue, voir HYPOTHÈSE 1 ci-dessous) ; les
     espaces insécables sont supprimés ; les virgules deviennent des points
     (séparateur décimal) ; si le résultat contient un point suivi d'au
     moins 3 chiffres, ce point est traité comme un séparateur de milliers
     et supprimé (ex: "1.500" -> "1500"), sinon il est conservé comme
     séparateur décimal.
  4) Bornes finales :
       - borne_min = 0                          si le libellé ORIGINAL commence par "Moins de"
                    = partie gauche du '|'       si un '|' est présent dans FinalClean
                    = FinalClean entier           sinon
       - borne_max = 999999                      si le libellé ORIGINAL contient "plus" ou commence par ">"
                    = partie droite du '|'        si un '|' est présent dans FinalClean
                    = None                        sinon (y compris pour "Moins de X" — voir HYPOTHÈSE 2)

HYPOTHÈSE 1 (confirmée par le SQL, non corrigée) : une valeur unique écrite
avec un espace comme séparateur de milliers (ex. "1 500" pour 1500) est
interprétée à tort comme un intervalle "1 - 500". C'est un comportement
existant du SQL de référence, reproduit tel quel. La couche Data Quality
(§17) doit permettre de repérer ces cas suspects (borne_min > borne_max,
ou écart important entre les deux bornes pour une valeur qui ressemble à un
montant unique).

HYPOTHÈSE 2 (confirmée par le SQL, non corrigée) : pour "Moins de X", la
borne_max obtenue est None (le SQL ne réutilise jamais X comme borne_max
dans cette branche). Le cahier des charges ne spécifie que la borne_min
(= 0) pour ce cas ; on ne comble donc pas ce vide silencieusement.

Précision numérique : les bornes sont conservées en Decimal, quantifiées à
2 décimales (cohérent avec le DECIMAL(18,2) du SQL de référence).
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

# Conventions métier (cahier des charges §10)
BORNE_MAX_CONVENTIONNELLE = Decimal("999999.00")
BORNE_MIN_MOINS_DE = Decimal("0.00")

_KEYWORDS_TO_STRIP = (
    "Moins de",
    "Plus de",
    "et plus",
    "PVMC de",
    "PVMC",
    "TTC",
    "euro",
    "EUR",
    "PLN",
    "ALL",
)

_DIGIT_SPACE_DIGIT_RE = re.compile(r"[0-9] [0-9]")
_DOT_THEN_3_DIGITS_RE = re.compile(r"\.[0-9]{3}")


@dataclass(frozen=True)
class PriceRangeResult:
    original: str          # PRICE_RANGE — valeur source jamais perdue (§10)
    borne_min: Decimal | None
    borne_max: Decimal | None
    bornes_combinees: str  # ex: "100.00 - 500.00", reproduisant CONCAT (NULL -> chaîne vide)

    def is_unparsed(self) -> bool:
        """Vrai si aucune borne n'a pu être déterminée à partir d'un libellé non vide."""
        return bool(self.original.strip()) and self.borne_min is None and self.borne_max is None

    def looks_suspicious(self) -> bool:
        """Heuristique Data Quality : bornes incohérentes (min > max)."""
        return (
            self.borne_min is not None
            and self.borne_max is not None
            and self.borne_min > self.borne_max
        )


def _case_insensitive_strip(text: str, keyword: str) -> str:
    return re.sub(re.escape(keyword), "", text, flags=re.IGNORECASE)


def _step1(original: str) -> str:
    text = original or ""
    for kw in _KEYWORDS_TO_STRIP:
        text = _case_insensitive_strip(text, kw)
    return text.strip()


def _step2(step1: str) -> str:
    text = step1
    text = text.replace(" a ", "|")
    text = text.replace("/", "|")
    text = text.replace("à", "|")
    text = text.replace("€", "")
    text = text.replace("  ", " ")  # une seule passe, comme le SQL d'origine
    return text.strip()


def _step3_final_clean(step2: str) -> str:
    text = step2
    if _DIGIT_SPACE_DIGIT_RE.search(text):
        text = text.replace(" ", "|")
    text = text.replace("\xa0", "")  # CHAR(160)
    text = text.replace(",", ".")
    if _DOT_THEN_3_DIGITS_RE.search(text):
        text = text.replace(".", "")
    return text.strip()


def _try_decimal(text: str) -> Decimal | None:
    text = (text or "").strip()
    if not text:
        return None
    try:
        return Decimal(text).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None


def normalize_price_range(raw_label: str | None) -> PriceRangeResult:
    """Normalise un libellé CODE CRITERE TARIFAIRE 1 en (borne_min, borne_max, BORNES_COMBINEES)."""
    original = "" if raw_label is None else str(raw_label)

    step1 = _step1(original)
    step2 = _step2(step1)
    final_clean = _step3_final_clean(step2)

    original_lower = original.strip().lower()
    starts_moins_de = original_lower.startswith("moins de")
    contains_plus = "plus" in original_lower
    starts_gt = original_lower.startswith(">")

    if "|" in final_clean:
        left, right = final_clean.split("|", 1)
    else:
        left, right = final_clean, None

    # borne_min
    if starts_moins_de:
        borne_min = BORNE_MIN_MOINS_DE
    elif "|" in final_clean:
        borne_min = _try_decimal(left)
    else:
        borne_min = _try_decimal(final_clean)

    # borne_max
    if contains_plus or starts_gt:
        borne_max = BORNE_MAX_CONVENTIONNELLE
    elif "|" in final_clean:
        borne_max = _try_decimal(right)
    else:
        borne_max = None

    min_str = f"{borne_min:.2f}" if borne_min is not None else ""
    max_str = f"{borne_max:.2f}" if borne_max is not None else ""
    bornes_combinees = f"{min_str} - {max_str}"

    return PriceRangeResult(
        original=original,
        borne_min=borne_min,
        borne_max=borne_max,
        bornes_combinees=bornes_combinees,
    )
