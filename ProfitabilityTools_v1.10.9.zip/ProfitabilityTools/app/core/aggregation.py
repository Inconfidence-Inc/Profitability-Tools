"""
Construction du dataset consolidé ProfitabilityTools.

RAPPEL : "Profitability" = ce dataset consolidé lui-même (§1, §24), pas une
formule. Ce module ne fait qu'assembler/enrichir les sources ; les KPI et
ratios analytiques vivent dans app/core/kpi.py, au-dessus de ce dataset.

Sources attendues depuis la v1.7.0/v1.8.0 (noms de colonnes = noms SQL
Server réels, confirmés par l'utilisateur à partir des vraies requêtes de
génération — voir app/data/sqlserver_provider.py pour le détail) :

  - part1_rows       : lignes de [TECH_BI].[dbo].[SRC_TDBPART1]
  - referentiel_rows : lignes de [ICI_BI].[dbo].[FONC_Référentiel programmes]
                        (uniquement contrat/date_debut/date_fin, pour le
                        contrôle Data Quality "contrat sans référentiel" —
                        voir app/core/referentiel.py)
  - part2_rows       : lignes de [TECH_BI].[dbo].[SRC_TDBPART2]
  - sinistres_rows   : lignes BRUTES (un sinistre par ligne, v1.8.0) de
                        [TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu] —
                        regroupées ici par (Numero_Police, année+mois de
                        Date_Souscription_Adhesion), voir
                        _build_sinistres_index ci-dessous.

Mapping métier confirmé par l'utilisateur (v1.7.0) :
  - TPA = gestionnaire_1 (pas gestionnaire_2)
  - Courtier = courtier_1
  - Régularisation (remplace l'ancien "Fait générateur", qui n'existe pas
    dans la vraie source) = regularisation, directement sur SRC_TDBPART1
  - Pays, Produit éligible = pays, libelle_produit, directement sur
    SRC_TDBPART1 (plus besoin de les chercher dans le référentiel)
  - Commission TPA = montant_total_frais_gestion
  - Total_Com = commission_ici + commission_distributeur + commission_tpa
    + autres_commissions_1 + autres_commissions_2 + autres_commissions_3
    (inchangé, voir app/core/commissions.py)

Hypothèse documentée (validée avec l'utilisateur, toujours en vigueur) : pas
de vraie somme en cas de lignes Part1 distinctes pour une même clé
Key_Contrat_Date — ce module ne dédoublonne que les lignes strictement
identiques sur tous les champs. Les cas de clés dupliquées avec des
montants différents doivent être signalés par app/core/data_quality.py.

Sinistres (v1.8.0) — règles confirmées par l'utilisateur :
  - Rattachement au contrat : Numero_Police du sinistre = identifiant_contrat
    de Part1.
  - Rattachement à la période : comparaison en ANNÉE+MOIS entre
    Date_Souscription_Adhesion (date réelle d'adhésion du sinistre) et
    date_debut_periode_souscription de Part1 (toujours un 1er du mois) — une
    égalité stricte de date ne matcherait presque jamais puisque
    Date_Souscription_Adhesion est un jour quelconque du mois.
  - Pas de dédoublonnage : chaque ligne de
    SRC_Sinistre_Transformer_Contenu représente un sinistre unique (confirmé
    par l'utilisateur) — app/core/claims_dedup.py reste disponible mais
    n'est pas utilisé pour cette source.
  - Montant = Montant_Total_Reglement (PAS Montant_Total_Reglement_FR,
    confirmé explicitement par l'utilisateur).
  - Statut = Statut_Technique_Sinistre, mappé via
    app/config/status_mapping.py vers les 4 catégories Accepté/Refusé/En
    cours/Inconnu (valeurs réelles + 2 décisions ambiguës validées avec
    l'utilisateur : "Annulé gestion" -> Refusé, "En attente de
    prescription" -> En cours — voir ce module pour le détail).
"""
from __future__ import annotations

from dataclasses import astuple
from decimal import Decimal
from typing import Any, Iterable

from app.config.status_mapping import ClaimStatusCategory, normalize_claim_status
from app.core.commissions import compute_sum_other_commission, compute_total_com
from app.core.keys import build_key_contrat_date, derive_annee_mois
from app.core.models import ProfitabilityRow
from app.core.money import to_decimal
from app.core.price_range import normalize_price_range
from app.core.referentiel import build_referentiel_periods_index, has_referentiel_covering_period

_SINISTRES_ZERO_FIELDS = (
    "Nombre_Sinistres_Total",
    "Montant_Total_Règlement",
    "Nb_Sinistres_En_Cours",
    "Nb_Sinistres_Refusés",
    "Nb_Sinistres_Acceptés",
    "Nb_Sinistres_Inconnus",
    "Montant_En_Cours",
    "Montant_Refusés",
    "Montant_Acceptés",
    "Montant_Inconnus",
)

# Catégorie de statut normalisée -> (champ compteur, champ montant) dans un
# "bucket" de regroupement sinistres (voir _build_sinistres_index).
_STATUS_CATEGORY_FIELDS: dict[str, tuple[str, str]] = {
    ClaimStatusCategory.EN_COURS: ("Nb_Sinistres_En_Cours", "Montant_En_Cours"),
    ClaimStatusCategory.REFUS: ("Nb_Sinistres_Refusés", "Montant_Refusés"),
    ClaimStatusCategory.ACCEPT: ("Nb_Sinistres_Acceptés", "Montant_Acceptés"),
    ClaimStatusCategory.INCONNU: ("Nb_Sinistres_Inconnus", "Montant_Inconnus"),
}


def _norm_contrat(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _build_part2_montants_index(part2_rows: Iterable[dict[str, Any]]) -> dict[tuple[str, Any], Decimal]:
    """SUM(nombre_resiliations) par (contrat, date_debut) — seule donnée de
    Part2 réellement consommée ici en dehors de la tranche tarifaire."""
    index: dict[tuple[str, Any], Decimal] = {}
    for row in part2_rows:
        key = (_norm_contrat(row.get("identifiant_contrat")), row.get("date_debut_periode_souscription"))
        index[key] = index.get(key, Decimal("0")) + to_decimal(row.get("nombre_resiliations"))
    return index


def _reference_sort_key(row: dict[str, Any]) -> tuple[int, str]:
    """ORDER BY reference (ASC, NULLS FIRST — comportement par défaut SQL Server)."""
    value = row.get("reference")
    if value is None:
        return (0, "")
    return (1, str(value))


def _build_part2_tarif_index(part2_rows: Iterable[dict[str, Any]]) -> dict[tuple[str, Any], dict[str, Any]]:
    """Une ligne (reference, tranche tarifaire) par (contrat, date_debut),
    celle dont reference est la plus petite — choix arbitraire du SQL de
    référence, reproduit tel quel."""
    buckets: dict[tuple[str, Any], list[dict[str, Any]]] = {}
    for row in part2_rows:
        key = (_norm_contrat(row.get("identifiant_contrat")), row.get("date_debut_periode_souscription"))
        buckets.setdefault(key, []).append(row)

    index: dict[tuple[str, Any], dict[str, Any]] = {}
    for key, rows in buckets.items():
        index[key] = sorted(rows, key=_reference_sort_key)[0]
    return index


def _new_sinistres_bucket() -> dict[str, Decimal]:
    return {field: Decimal("0") for field in _SINISTRES_ZERO_FIELDS}


def _build_sinistres_index(
    sinistres_rows: Iterable[dict[str, Any]],
) -> dict[tuple[str, int | None, int | None], dict[str, Decimal]]:
    """Regroupe les sinistres bruts de SRC_Sinistre_Transformer_Contenu par
    (Numero_Police normalisé, année, mois) — année/mois dérivés de
    Date_Souscription_Adhesion, comparés à ceux de date_debut_periode_souscription
    côté Part1 (voir docstring de module). Chaque ligne source est un
    sinistre unique (pas de dédoublonnage, confirmé par l'utilisateur)."""
    index: dict[tuple[str, int | None, int | None], dict[str, Decimal]] = {}
    for row in sinistres_rows:
        police = _norm_contrat(row.get("Numero_Police"))
        if not police:
            continue
        annee, mois = derive_annee_mois(row.get("Date_Souscription_Adhesion"))
        key = (police, annee, mois)
        bucket = index.setdefault(key, _new_sinistres_bucket())

        montant = to_decimal(row.get("Montant_Total_Reglement"))
        bucket["Nombre_Sinistres_Total"] += Decimal("1")
        bucket["Montant_Total_Règlement"] += montant

        category = normalize_claim_status(row.get("Statut_Technique_Sinistre"))
        count_field, amount_field = _STATUS_CATEGORY_FIELDS[category]
        bucket[count_field] += Decimal("1")
        bucket[amount_field] += montant

    return index


def build_profitability_dataset(
    part1_rows: Iterable[dict[str, Any]],
    referentiel_rows: Iterable[dict[str, Any]],
    part2_rows: Iterable[dict[str, Any]],
    sinistres_rows: Iterable[dict[str, Any]],
    *,
    is_demo_data: bool = False,
) -> list[ProfitabilityRow]:
    part1_rows = list(part1_rows)
    part2_rows = list(part2_rows)

    referentiel_periods = build_referentiel_periods_index(referentiel_rows)
    part2_montants = _build_part2_montants_index(part2_rows)
    part2_tarif = _build_part2_tarif_index(part2_rows)
    sinistres_index = _build_sinistres_index(sinistres_rows)

    output: list[ProfitabilityRow] = []
    seen_exact: set[tuple] = set()

    for row in part1_rows:
        contrat_raw = row.get("identifiant_contrat")
        contrat = _norm_contrat(contrat_raw)
        date_debut = row.get("date_debut_periode_souscription")
        date_fin = row.get("date_fin_periode_souscription")

        has_referentiel_match = has_referentiel_covering_period(
            referentiel_periods, contrat_raw, date_debut, date_fin
        )

        key_contrat_date = build_key_contrat_date(contrat_raw, date_debut)
        annee, mois = derive_annee_mois(date_debut)

        tarif = part2_tarif.get((contrat, date_debut))
        reference = ((tarif or {}).get("reference")) or ""
        price_range_raw = ((tarif or {}).get("code_critere_tarifaire_1")) or ""
        price = normalize_price_range(price_range_raw)

        nbre_resiliation = part2_montants.get((contrat, date_debut), Decimal("0"))

        commission_ici = to_decimal(row.get("montant_total_commission_ici"))
        commission_distributeur = to_decimal(row.get("montant_total_commission_distributeur"))
        commission_tpa = to_decimal(row.get("montant_total_frais_gestion"))
        sum_other = compute_sum_other_commission(
            row.get("montant_total_autres_commissions_1"),
            row.get("montant_total_autres_commissions_2"),
            row.get("montant_total_autres_commissions_3"),
        )
        total_com = compute_total_com(commission_ici, commission_distributeur, commission_tpa, sum_other)

        sinistres_key = (contrat, annee, mois) if contrat and annee is not None and mois is not None else None
        sinistres = sinistres_index.get(sinistres_key) if sinistres_key else None
        has_claims_match = sinistres is not None
        s = {f: to_decimal((sinistres or {}).get(f)) for f in _SINISTRES_ZERO_FIELDS}

        out_row = ProfitabilityRow(
            date_debut_periode_souscription_tdb=date_debut,
            date_fin_periode_souscription_tdb=date_fin,
            compagny=row.get("compagnie") or "",
            distributor=row.get("libelle_distributeur") or "",
            tpa=row.get("gestionnaire_1") or "",
            eligible_product=row.get("libelle_produit") or "",
            regularisation=row.get("regularisation") or "",
            pays=row.get("pays") or "",
            courtier=row.get("courtier_1") or "",
            identifiant_contrat_tdb=contrat,
            key_contrat_date=key_contrat_date,
            reference=reference,
            devise=row.get("code_devise_quittance") or "",
            annee=annee,
            mois=mois,
            price_range=price.original,
            bornes_combinees=price.bornes_combinees,
            borne_min=price.borne_min,
            borne_max=price.borne_max,
            number_of_subscription=to_decimal(row.get("nombre_total_adhesions")),
            nbre_resiliation=nbre_resiliation,
            volumes_primes_ttc=to_decimal(row.get("montant_total_ttc")),
            volumes_primes_ht=to_decimal(row.get("montant_total_ht")),
            part_assureur=to_decimal(row.get("montant_total_prime_assureur")),
            commission_ici=commission_ici,
            montant_commission_distributeur=commission_distributeur,
            commission_tpa=commission_tpa,
            sum_other_commission=sum_other,
            total_com=total_com,
            nombre_sinistres_total=s["Nombre_Sinistres_Total"],
            montant_total_reglement=s["Montant_Total_Règlement"],
            nb_sinistres_en_cours=s["Nb_Sinistres_En_Cours"],
            nb_sinistres_refuses=s["Nb_Sinistres_Refusés"],
            nb_sinistres_acceptes=s["Nb_Sinistres_Acceptés"],
            nb_sinistres_inconnus=s["Nb_Sinistres_Inconnus"],
            montant_en_cours=s["Montant_En_Cours"],
            montant_refuses=s["Montant_Refusés"],
            montant_acceptes=s["Montant_Acceptés"],
            montant_inconnus=s["Montant_Inconnus"],
            has_referentiel_match=has_referentiel_match,
            has_claims_match=has_claims_match,
            is_demo_data=is_demo_data,
        )

        # Dédoublonnage de sécurité : seules les lignes STRICTEMENT identiques
        # sur tous les champs sont fusionnées (comportement réel du GROUP BY
        # SQL, qui ne fait pas de vraie somme — cf. docstring du module).
        fingerprint = astuple(out_row)
        if fingerprint in seen_exact:
            continue
        seen_exact.add(fingerprint)
        output.append(out_row)

    return output
