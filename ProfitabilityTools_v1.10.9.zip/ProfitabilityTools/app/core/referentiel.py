"""
Référentiel programmes — contrôle Data Quality "contrat sans référentiel".

Depuis la v1.7.0 (confirmé par l'utilisateur à partir de la vraie requête de
génération de TDB Part1), ce module NE sert plus à enrichir le dataset avec
Produit/Pays/Régularisation — ces attributs sont désormais portés
directement par SRC_TDBPART1 (voir app/data/sqlserver_provider.py et
app/core/aggregation.py). Son seul rôle restant est de vérifier qu'un
contrat+période a bien une version de référentiel programme qui le couvre,
pour le signaler dans Data Quality (has_referentiel_match / "Contrats sans
référentiel") — exactement comme fait la vraie requête de génération :

    LEFT JOIN [FONC_Référentiel programmes] prog
        ON prog.[N° CONTRAT ] = bord.IDENTIFIANT_CONTRAT
       AND CONVERT(DATE, prog.DATE_DEBUT, 103) <= CONVERT(DATE, bord.DATE_DEBUT_PERIODE_SOUSCRIPTION, 103)
       AND CONVERT(DATE, prog.DATE_FIN,   103) >= CONVERT(DATE, bord.DATE_FIN_PERIODE_SOUSCRIPTION, 103)

Remplace l'ancienne logique "dernière version par UPDATE DATE" (toujours
utilisée jusqu'en v1.6.0), qui ne reflétait pas la vraie règle métier : une
version de référentiel n'est valable que pour la période qu'elle couvre
réellement (DATE_DEBUT/DATE_FIN de la version), pas "la plus récente
globalement".
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Iterable

from app.core.keys import parse_business_date

COL_CONTRAT = "contrat"
COL_DATE_DEBUT = "date_debut"
COL_DATE_FIN = "date_fin"


def _norm_contrat(value: Any) -> str:
    return "" if value is None else str(value).strip()


def build_referentiel_periods_index(
    rows: Iterable[dict[str, Any]],
) -> dict[str, list[tuple[date, date]]]:
    """Index contrat -> liste de (date_debut, date_fin) des versions valides.

    Les lignes sans contrat, ou dont les dates ne sont pas interprétables,
    sont ignorées (elles ne peuvent jamais produire de correspondance — un
    contrat qui n'a QUE de telles lignes sera donc correctement signalé
    "sans référentiel")."""
    index: dict[str, list[tuple[date, date]]] = {}
    for row in rows:
        contrat = _norm_contrat(row.get(COL_CONTRAT))
        if not contrat:
            continue
        debut = parse_business_date(row.get(COL_DATE_DEBUT))
        fin = parse_business_date(row.get(COL_DATE_FIN))
        if debut is None or fin is None:
            continue
        index.setdefault(contrat, []).append((debut, fin))
    return index


def has_referentiel_covering_period(
    index: dict[str, list[tuple[date, date]]],
    identifiant_contrat: str | None,
    date_debut_periode: str | date | datetime | None,
    date_fin_periode: str | date | datetime | None,
) -> bool:
    """Vrai si une version de référentiel pour ce contrat couvre entièrement
    la période [date_debut_periode, date_fin_periode] (bornes incluses),
    reproduisant la jointure par plage de dates confirmée ci-dessus."""
    contrat = _norm_contrat(identifiant_contrat)
    if not contrat:
        return False
    periods = index.get(contrat)
    if not periods:
        return False

    debut = parse_business_date(date_debut_periode)
    fin = parse_business_date(date_fin_periode)
    if debut is None or fin is None:
        return False

    return any(p_debut <= debut and p_fin >= fin for p_debut, p_fin in periods)
