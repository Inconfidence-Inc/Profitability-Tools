"""
Section Data Quality (cahier des charges §17).

Chaque fonction retourne une liste de ProfitabilityRow (ou de dict pour les
sinistres orphelins) correspondant à une catégorie d'anomalie, avec un
DataQualityReport agrégeant les compteurs pour l'écran Data Quality.

Depuis la v1.8.0, les sinistres orphelins (non rattachables à un
contrat/période) sont détectés sur la base du rattachement réel : clé
(Numero_Police normalisé, année, mois dérivés de Date_Souscription_Adhesion),
cohérente avec le regroupement fait par app.core.aggregation — et non plus
sur l'ancienne clé Key_Contrat_Date (la source sinistres n'est plus
pré-agrégée, voir app/data/sqlserver_provider.py).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from app.core.keys import derive_annee_mois
from app.core.models import ProfitabilityRow


def _norm_contrat(value: object) -> str:
    return "" if value is None else str(value).strip()


@dataclass
class DataQualityReport:
    contrats_sans_referentiel: list[ProfitabilityRow]
    contrats_sans_sinistres: list[ProfitabilityRow]
    price_ranges_non_interpretables: list[ProfitabilityRow]
    price_ranges_suspects: list[ProfitabilityRow]
    dates_invalides: list[ProfitabilityRow]
    cles_dupliquees: dict[str, list[ProfitabilityRow]]
    sinistres_orphelins: list[dict]

    def counts(self) -> dict[str, int]:
        return {
            "Contrats sans référentiel": len(self.contrats_sans_referentiel),
            "Contrats sans sinistres": len(self.contrats_sans_sinistres),
            "Price ranges non interprétables": len(self.price_ranges_non_interpretables),
            "Price ranges suspects (bornes incohérentes)": len(self.price_ranges_suspects),
            "Dates invalides": len(self.dates_invalides),
            "Clés Key_Contrat_Date dupliquées (montants différents)": len(self.cles_dupliquees),
            "Sinistres non rattachables à un contrat/période": len(self.sinistres_orphelins),
        }


def _find_duplicate_keys(rows: list[ProfitabilityRow]) -> dict[str, list[ProfitabilityRow]]:
    """Key_Contrat_Date apparaissant plusieurs fois avec des montants
    financiers différents (cf. hypothèse documentée dans aggregation.py :
    le SQL de référence ne les somme pas automatiquement)."""
    by_key: dict[str, list[ProfitabilityRow]] = {}
    for row in rows:
        if not row.key_contrat_date:
            continue
        by_key.setdefault(row.key_contrat_date, []).append(row)

    duplicates: dict[str, list[ProfitabilityRow]] = {}
    for key, group in by_key.items():
        if len(group) < 2:
            continue
        amounts = {
            (r.volumes_primes_ttc, r.volumes_primes_ht, r.total_com)
            for r in group
        }
        if len(amounts) > 1:
            duplicates[key] = group
    return duplicates


def build_data_quality_report(
    rows: Iterable[ProfitabilityRow],
    sinistres_rows: Iterable[dict] | None = None,
) -> DataQualityReport:
    rows = list(rows)
    sinistres_rows = list(sinistres_rows or [])

    contrats_sans_referentiel = [r for r in rows if not r.has_referentiel_match]
    contrats_sans_sinistres = [r for r in rows if not r.has_claims_match]

    price_ranges_non_interpretables = [
        r for r in rows if r.price_range.strip() and r.borne_min is None and r.borne_max is None
    ]
    price_ranges_suspects = [
        r for r in rows
        if r.borne_min is not None and r.borne_max is not None and r.borne_min > r.borne_max
    ]

    dates_invalides = [
        r for r in rows
        if r.key_contrat_date is None and str(r.identifiant_contrat_tdb or "").strip() != ""
    ]

    cles_dupliquees = _find_duplicate_keys(rows)

    known_periods = {
        (r.identifiant_contrat_tdb, r.annee, r.mois)
        for r in rows
        if r.identifiant_contrat_tdb and r.annee is not None and r.mois is not None
    }

    def _is_orphan(s: dict) -> bool:
        police = _norm_contrat(s.get("Numero_Police"))
        if not police:
            return True
        annee, mois = derive_annee_mois(s.get("Date_Souscription_Adhesion"))
        return (police, annee, mois) not in known_periods

    sinistres_orphelins = [s for s in sinistres_rows if _is_orphan(s)]

    return DataQualityReport(
        contrats_sans_referentiel=contrats_sans_referentiel,
        contrats_sans_sinistres=contrats_sans_sinistres,
        price_ranges_non_interpretables=price_ranges_non_interpretables,
        price_ranges_suspects=price_ranges_suspects,
        dates_invalides=dates_invalides,
        cles_dupliquees=cles_dupliquees,
        sinistres_orphelins=sinistres_orphelins,
    )
