"""
Export CSV / Excel du dataset ProfitabilityTools (cahier des charges §15).

Les montants sont exportés comme des nombres (Decimal -> float au moment de
l'écriture uniquement, jamais pour un calcul) afin de rester exploitables
dans Excel ; les colonnes non monétaires sont exportées en texte.
"""
from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable

from app.core.models import COLUMN_LABELS, MONEY_FIELDS, ProfitabilityRow


def _row_values(row: ProfitabilityRow, columns: list[str]) -> list:
    values = []
    for col in columns:
        value = getattr(row, col, None)
        if col in MONEY_FIELDS and value is not None:
            values.append(float(value))
        elif value is None:
            values.append("")
        else:
            values.append(value)
    return values


def export_to_csv(rows: Iterable[ProfitabilityRow], columns: list[str], file_path: str | Path) -> None:
    rows = list(rows)
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow([COLUMN_LABELS.get(c, c) for c in columns])
        for row in rows:
            writer.writerow(_row_values(row, columns))


def export_to_excel(rows: Iterable[ProfitabilityRow], columns: list[str], file_path: str | Path) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font

    rows = list(rows)
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "ProfitabilityTools"

    headers = [COLUMN_LABELS.get(c, c) for c in columns]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)

    for row in rows:
        ws.append(_row_values(row, columns))

    for i, col in enumerate(columns, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = max(14, len(COLUMN_LABELS.get(col, col)) + 2)

    wb.save(str(path))
