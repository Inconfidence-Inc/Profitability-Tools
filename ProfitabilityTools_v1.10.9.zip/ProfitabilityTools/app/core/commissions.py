"""
Primes et commissions (cahier des charges §6).

Reproduit exactement les règles confirmées par l'utilisateur à partir des
vraies colonnes de [TECH_BI].[dbo].[SRC_TDBPART1] (v1.7.0) :

    Sum_Other_Commission = montant_total_autres_commissions_1 + 2 + 3   (NULL -> 0)

    Total_Com = Commission_ICI                (= montant_total_commission_ici)
              + montant_total_commission_distributeur
              + Commission_TPA                (= montant_total_frais_gestion)
              + Sum_Other_Commission

Toutes les valeurs NULL sont traitées comme 0. Tous les montants sont
manipulés en Decimal (voir app/core/money.py) — jamais en float.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.core.money import to_decimal


def compute_sum_other_commission(
    autre_1: Any, autre_2: Any, autre_3: Any
) -> Decimal:
    return to_decimal(autre_1) + to_decimal(autre_2) + to_decimal(autre_3)


def compute_total_com(
    commission_ici: Any,
    commission_distributeur: Any,
    commission_tpa: Any,
    sum_other_commission: Any,
) -> Decimal:
    return (
        to_decimal(commission_ici)
        + to_decimal(commission_distributeur)
        + to_decimal(commission_tpa)
        + to_decimal(sum_other_commission)
    )
