"""Tests pour app.ui.theme — garde-fous sur la feuille de style Material
Design (v1.2.0, affinée v1.9.0) : vérifie que les règles ajoutées pour la
lisibilité des tableaux (barre de défilement horizontale visible,
surbrillance au survol, colonne figée) sont bien présentes dans la feuille
générée, pour les deux palettes (clair/sombre), plutôt que de dépendre
uniquement d'une vérification visuelle manuelle.
"""
from __future__ import annotations

import pytest

from app.ui.theme import DARK, LIGHT, build_stylesheet, palette_for


@pytest.mark.parametrize("palette", [LIGHT, DARK])
def test_stylesheet_styles_horizontal_scrollbar(palette):
    """v1.9.0 : avant ce correctif, seule QScrollBar:vertical était stylée —
    la barre horizontale (seule façon de voir les colonnes au-delà de la
    largeur de l'écran sur Profitability Explorer) utilisait le rendu natif
    non thémé, peu visible. Elle doit maintenant avoir ses propres règles."""
    css = build_stylesheet(palette)
    assert "QScrollBar:horizontal" in css
    assert "QScrollBar::handle:horizontal" in css


@pytest.mark.parametrize("palette", [LIGHT, DARK])
def test_stylesheet_styles_table_item_hover_and_frozen_column(palette):
    css = build_stylesheet(palette)
    assert "QTableView::item:hover" in css
    assert "QTableView#FrozenColumn" in css


def test_palette_for_returns_light_by_default():
    assert palette_for("autre_chose") == LIGHT
    assert palette_for("dark") == DARK
