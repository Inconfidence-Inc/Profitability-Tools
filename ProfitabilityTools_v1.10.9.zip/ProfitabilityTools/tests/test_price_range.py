from decimal import Decimal

from app.core.price_range import normalize_price_range


def test_moins_de():
    r = normalize_price_range("Moins de 500")
    assert r.borne_min == Decimal("0.00")
    assert r.borne_max is None  # comportement du SQL de référence (hypothèse documentée)
    assert r.original == "Moins de 500"


def test_plus_de():
    r = normalize_price_range("Plus de 500")
    assert r.borne_min == Decimal("500.00")
    assert r.borne_max == Decimal("999999.00")


def test_et_plus():
    r = normalize_price_range("500 et plus")
    assert r.borne_max == Decimal("999999.00")


def test_intervalle_avec_a_accent():
    r = normalize_price_range("100 à 500")
    assert r.borne_min == Decimal("100.00")
    assert r.borne_max == Decimal("500.00")


def test_intervalle_avec_a_lettre():
    r = normalize_price_range("100 a 500")
    assert r.borne_min == Decimal("100.00")
    assert r.borne_max == Decimal("500.00")


def test_intervalle_avec_slash():
    r = normalize_price_range("100 / 500")
    assert r.borne_min == Decimal("100.00")
    assert r.borne_max == Decimal("500.00")


def test_pvmc_de():
    r = normalize_price_range("PVMC de 300")
    assert r.borne_min == Decimal("300.00")


def test_devise_et_ttc_nettoyes():
    r = normalize_price_range("300 EUR TTC")
    assert r.borne_min == Decimal("300.00")


def test_superieur_a():
    r = normalize_price_range(">1000")
    assert r.borne_max == Decimal("999999.00")


def test_valeur_vide():
    r = normalize_price_range("")
    assert r.borne_min is None
    assert r.borne_max is None
    assert r.is_unparsed() is False  # chaîne vide : rien à interpréter, pas une anomalie


def test_valeur_non_interpretable_est_une_anomalie():
    r = normalize_price_range("valeur totalement illisible ###")
    assert r.is_unparsed() is True


def test_original_toujours_preserve():
    r = normalize_price_range("Moins de 500")
    assert r.original == "Moins de 500"  # jamais perdu, même transformé


def test_bornes_combinees_format():
    r = normalize_price_range("100 à 500")
    assert r.bornes_combinees == "100.00 - 500.00"


def test_bornes_combinees_moins_de_borne_max_vide():
    r = normalize_price_range("Moins de 500")
    assert r.bornes_combinees == "0.00 - "


def test_milliers_espace_est_mal_interprete_comme_intervalle_connu():
    # Limite connue et documentée du SQL de référence : "1 500" (1500 avec
    # espace comme séparateur de milliers) est interprété comme "1 - 500".
    r = normalize_price_range("1 500")
    assert r.borne_min == Decimal("1.00")
    assert r.borne_max == Decimal("500.00")
    assert r.looks_suspicious() is False  # min < max donc pas détecté par l'heuristique simple
