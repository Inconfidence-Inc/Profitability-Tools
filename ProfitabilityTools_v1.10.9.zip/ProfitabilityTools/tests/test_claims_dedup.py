from app.core.claims_dedup import dedupe_claims


def test_keeps_highest_amount_for_same_dossier():
    rows = [
        {"Numero_Police": "P1", "Numero_Dossier": "D1", "Montant_Total_Reglement": 100},
        {"Numero_Police": "P1", "Numero_Dossier": "D1", "Montant_Total_Reglement": 250},
        {"Numero_Police": "P1", "Numero_Dossier": "D1", "Montant_Total_Reglement": 50},
    ]
    result = dedupe_claims(rows)
    assert len(result) == 1
    assert result[0]["Montant_Total_Reglement"] == 250


def test_distinct_dossiers_are_preserved():
    rows = [
        {"Numero_Police": "P1", "Numero_Dossier": "D1", "Montant_Total_Reglement": 100},
        {"Numero_Police": "P1", "Numero_Dossier": "D2", "Montant_Total_Reglement": 200},
        {"Numero_Police": "P2", "Numero_Dossier": "D1", "Montant_Total_Reglement": 300},
    ]
    result = dedupe_claims(rows)
    assert len(result) == 3


def test_tie_keeps_first_seen():
    rows = [
        {"Numero_Police": "P1", "Numero_Dossier": "D1", "Montant_Total_Reglement": 100, "tag": "first"},
        {"Numero_Police": "P1", "Numero_Dossier": "D1", "Montant_Total_Reglement": 100, "tag": "second"},
    ]
    result = dedupe_claims(rows)
    assert len(result) == 1
    assert result[0]["tag"] == "first"
