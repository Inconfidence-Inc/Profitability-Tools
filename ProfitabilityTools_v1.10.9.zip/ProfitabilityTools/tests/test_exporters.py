from decimal import Decimal
from pathlib import Path

from app.core.exporters import export_to_csv, export_to_excel
from app.core.models import ProfitabilityRow


def _rows():
    return [
        ProfitabilityRow(identifiant_contrat_tdb="C1", compagny="X", volumes_primes_ttc=Decimal("123.45")),
        ProfitabilityRow(identifiant_contrat_tdb="C2", compagny="Y", volumes_primes_ttc=Decimal("67.00")),
    ]


def test_export_to_csv(tmp_path: Path):
    out = tmp_path / "export.csv"
    export_to_csv(_rows(), ["identifiant_contrat_tdb", "compagny", "volumes_primes_ttc"], out)
    assert out.exists()
    content = out.read_text(encoding="utf-8-sig")
    assert "C1" in content
    assert "123.45" in content


def test_export_to_excel(tmp_path: Path):
    out = tmp_path / "export.xlsx"
    export_to_excel(_rows(), ["identifiant_contrat_tdb", "compagny", "volumes_primes_ttc"], out)
    assert out.exists()

    from openpyxl import load_workbook
    wb = load_workbook(out)
    ws = wb.active
    assert ws.cell(row=2, column=1).value == "C1"
    assert ws.cell(row=2, column=3).value == 123.45
