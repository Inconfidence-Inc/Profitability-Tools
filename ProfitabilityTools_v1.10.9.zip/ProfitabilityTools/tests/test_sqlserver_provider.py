"""Tests pour SqlServerDataProvider._connect/_fetch_all (v1.10.3).

Contexte du correctif couvert ici : `cursor.timeout = _QUERY_TIMEOUT_SECONDS`
(introduit en v1.8.2) levait en réalité `'pyodbc.Cursor' object has no
attribute 'timeout' and no __dict__ for setting new attributes` dès la
première requête sur un VRAI pyodbc.Cursor — pyodbc.Cursor est un type C qui
n'autorise aucun attribut arbitraire, contrairement à pyodbc.Connection qui
expose bien `timeout` comme attribut settable. Ce bug était invisible dans
les tests existants car le seul faux pyodbc utilisé ailleurs
(tests/test_settings_page.py::fake_pyodbc) est un simple objet Python
ordinaire, qui accepte silencieusement n'importe quelle affectation
d'attribut — à l'opposé du comportement réel de pyodbc.

Les faux objets ci-dessous utilisent `__slots__` pour reproduire fidèlement
cette contrainte : toute tentative d'affecter un attribut non prévu lève
AttributeError, exactement comme le vrai pyodbc. C'est ce qui aurait permis
de détecter ce bug avant livraison."""
from __future__ import annotations

import sys
import types

import pytest

from app.config.settings import SqlServerConfig
from app.data.sqlserver_provider import SqlServerDataProvider, SqlServerConnectionError


class _FakeCursor:
    """Reproduit le vrai pyodbc.Cursor : AUCUN attribut arbitraire ne peut
    être affecté (pas de `timeout`, notamment)."""

    __slots__ = ("_rows", "description")

    def __init__(self, rows: list[tuple]):
        self._rows = list(rows)
        self.description = [("colonne_a",), ("colonne_b",)]

    def execute(self, query, params=()):
        return self

    def fetchmany(self, size):
        batch, self._rows = self._rows[:size], self._rows[size:]
        return batch

    def close(self):
        pass


class _FakeConnection:
    """Reproduit le vrai pyodbc.Connection : `timeout` EST un attribut
    valide (contrairement au curseur) ; rien d'autre ne l'est."""

    __slots__ = ("timeout", "_rows")

    def __init__(self, rows: list[tuple]):
        self._rows = rows

    def cursor(self):
        return _FakeCursor(self._rows)

    def close(self):
        pass


@pytest.fixture
def fake_pyodbc_strict(monkeypatch):
    """Comme fake_pyodbc (tests/test_settings_page.py) mais avec des objets
    `__slots__` qui refusent tout attribut imprévu, pour détecter ce type
    de régression au lieu de le masquer silencieusement."""
    rows = [("valeur_a1", "valeur_b1"), ("valeur_a2", "valeur_b2")]
    fake_module = types.ModuleType("pyodbc")
    fake_module.connect = lambda *a, **k: _FakeConnection(rows)
    monkeypatch.setitem(sys.modules, "pyodbc", fake_module)
    return fake_module


def _config() -> SqlServerConfig:
    return SqlServerConfig(
        server="serveur-test", database_ici_bi="ICI_BI", database_tech_bi="TECH_BI",
        username="user", password="pwd", driver="ODBC Driver 18 for SQL Server",
        encrypt=True, trust_server_certificate=False, timeout_seconds=30,
    )


def test_connect_sets_query_timeout_on_connection_not_cursor(fake_pyodbc_strict):
    """Non-régression directe du bug remonté par l'utilisateur : la
    connexion s'établit et le délai d'exécution s'affecte sans
    AttributeError."""
    provider = SqlServerDataProvider(_config())
    conn = provider._connect()
    assert conn.timeout == 300  # _QUERY_TIMEOUT_SECONDS


def test_fetch_part1_rows_succeeds_with_real_pyodbc_cursor_constraints(fake_pyodbc_strict):
    """Bout en bout : fetch_part1_rows() (comme tout autre fetch_*_rows())
    doit réussir face à un curseur qui se comporte comme le vrai pyodbc —
    c'est exactement ce que l'utilisateur a vu échouer en conditions
    réelles (écran « Chargement des données »)."""
    provider = SqlServerDataProvider(_config())
    rows = provider.fetch_part1_rows()
    assert rows == [
        {"colonne_a": "valeur_a1", "colonne_b": "valeur_b1"},
        {"colonne_a": "valeur_a2", "colonne_b": "valeur_b2"},
    ]


def test_fetch_all_reuses_cached_connection_across_calls(fake_pyodbc_strict):
    """Le timeout n'est affecté qu'une fois, à la connexion (pas à chaque
    requête) — vérifié indirectement en s'assurant que plusieurs fetch
    successifs réutilisent la même connexion sans erreur."""
    provider = SqlServerDataProvider(_config())
    provider.fetch_part1_rows()
    conn_after_first = provider._conn
    provider.fetch_referentiel_rows()
    assert provider._conn is conn_after_first


def test_not_configured_raises_before_touching_pyodbc(fake_pyodbc_strict):
    provider = SqlServerDataProvider(
        SqlServerConfig(
            server="", database_ici_bi="ICI_BI", database_tech_bi="TECH_BI",
            username="", password="", driver="ODBC Driver 18 for SQL Server",
            encrypt=True, trust_server_certificate=False, timeout_seconds=30,
        )
    )
    with pytest.raises(SqlServerConnectionError):
        provider._connect()
