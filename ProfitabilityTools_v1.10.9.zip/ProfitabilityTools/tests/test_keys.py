from app.core.keys import build_key_contrat_date, derive_annee_mois, parse_business_date


def test_build_key_contrat_date_example_from_cahier_des_charges():
    # CONTRACT123 + 01/01/2026 -> "CONTRACT123_01012026"
    assert build_key_contrat_date("CONTRACT123", "01/01/2026") == "CONTRACT123_01012026"


def test_build_key_contrat_date_missing_contrat():
    assert build_key_contrat_date("", "01/01/2026") is None
    assert build_key_contrat_date(None, "01/01/2026") is None


def test_build_key_contrat_date_invalid_date():
    assert build_key_contrat_date("CONTRACT123", "n'importe quoi") is None
    assert build_key_contrat_date("CONTRACT123", None) is None


def test_parse_business_date_ddmmyyyy():
    d = parse_business_date("25/12/2026")
    assert (d.day, d.month, d.year) == (25, 12, 2026)


def test_parse_business_date_invalid_returns_none():
    assert parse_business_date("31/02/2026") is None  # 31 février n'existe pas
    assert parse_business_date("pas une date") is None
    assert parse_business_date(None) is None


def test_derive_annee_mois():
    assert derive_annee_mois("15/03/2026") == (2026, 3)


def test_derive_annee_mois_invalid():
    assert derive_annee_mois("invalide") == (None, None)
