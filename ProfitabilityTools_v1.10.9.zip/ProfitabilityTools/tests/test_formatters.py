"""Tests pour app.ui.formatters — formatage d'affichage uniquement (jamais
utilisé pour les calculs, cf. docstring du module).

v1.8.2 : ajoute un filet défensif sur format_money/format_percent (une
valeur numérique malformée ne doit jamais faire planter le rendu d'un
tableau entier), en plus des cas nominaux jusqu'ici non couverts par aucun
test."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation

from app.ui.formatters import format_date_fr, format_int, format_money, format_percent


def test_format_money_none_is_dash():
    assert format_money(None) == "—"


def test_format_money_positive():
    assert format_money(Decimal("1234.5")) == "1 234,50"


def test_format_money_negative():
    assert format_money(Decimal("-42.9")) == "-42,90"


def test_format_money_with_devise():
    assert format_money(Decimal("10"), "EUR") == "10,00 EUR"


def test_format_money_nan_does_not_crash():
    """v1.8.2 : Decimal('NaN') lève InvalidOperation sur une comparaison
    (`value < 0`) — ne doit jamais remonter jusqu'à l'UI."""
    nan = Decimal("NaN")
    with __import__("pytest").raises(InvalidOperation):
        bool(nan < 0)  # confirme que le cas serait bien problématique sans filet
    assert format_money(nan) == str(nan)  # filet défensif : pas d'exception


def test_format_percent_none_is_dash():
    assert format_percent(None) == "—"


def test_format_percent_basic():
    assert format_percent(Decimal("0.825")) == "82.5%"


def test_format_percent_nan_does_not_crash():
    # Contrairement à format_money (la comparaison `< 0` lève sur NaN), la
    # multiplication et le formatage d'un Decimal NaN ne lèvent pas — le cas
    # ne passe donc pas par le filet défensif, mais reste bien sans crash.
    assert format_percent(Decimal("NaN")) == "NaN%"


def test_format_int_none_is_dash():
    assert format_int(None) == "—"


def test_format_int_basic():
    assert format_int(5473) == "5 473"


def test_format_date_fr_passthrough():
    assert format_date_fr("27/01/2026") == "27/01/2026"
    assert format_date_fr(None) == "—"
