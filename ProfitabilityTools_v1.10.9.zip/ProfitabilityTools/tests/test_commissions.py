from decimal import Decimal

from app.core.commissions import compute_sum_other_commission, compute_total_com


def test_sum_other_commission_all_present():
    assert compute_sum_other_commission(10, 20, 30) == Decimal("60")


def test_sum_other_commission_with_nulls():
    assert compute_sum_other_commission(None, 20, None) == Decimal("20")


def test_sum_other_commission_all_null():
    assert compute_sum_other_commission(None, None, None) == Decimal("0")


def test_total_com_full_example():
    # Commission ICI + Commission distributeur + Frais gestion/TPA + autres 1+2+3
    sum_other = compute_sum_other_commission(1, 2, 3)
    total = compute_total_com(
        commission_ici=100,
        commission_distributeur=50,
        commission_tpa=25,
        sum_other_commission=sum_other,
    )
    assert total == Decimal("181")  # 100+50+25+6


def test_total_com_handles_nulls():
    total = compute_total_com(None, None, None, None)
    assert total == Decimal("0")
