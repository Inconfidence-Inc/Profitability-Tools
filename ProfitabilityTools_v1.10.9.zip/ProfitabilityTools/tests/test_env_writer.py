"""Tests pour app.config.env_writer (onglet Settings — écriture de .env)."""
from __future__ import annotations

import os

from app.config.env_writer import apply_env_updates, write_env_values


def test_write_env_values_creates_file_when_missing(tmp_path):
    env_path = tmp_path / ".env"
    assert not env_path.exists()

    write_env_values({"PROFITABILITY_DB_SERVER": "srv1"}, env_path=env_path)

    assert env_path.exists()
    content = env_path.read_text(encoding="utf-8")
    assert "PROFITABILITY_DB_SERVER=srv1" in content


def test_write_env_values_updates_existing_key_in_place(tmp_path):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "# commentaire\nPROFITABILITY_DATA_MODE=DEMO\nPROFITABILITY_DB_SERVER=old\n",
        encoding="utf-8",
    )

    write_env_values({"PROFITABILITY_DB_SERVER": "new-server"}, env_path=env_path)

    lines = env_path.read_text(encoding="utf-8").splitlines()
    assert lines[0] == "# commentaire"
    assert "PROFITABILITY_DATA_MODE=DEMO" in lines
    assert "PROFITABILITY_DB_SERVER=new-server" in lines
    # L'ancienne valeur ne doit plus apparaître, et il ne doit pas y avoir de doublon.
    assert sum(1 for l in lines if l.startswith("PROFITABILITY_DB_SERVER=")) == 1


def test_write_env_values_appends_new_key_without_touching_others(tmp_path):
    env_path = tmp_path / ".env"
    env_path.write_text("PROFITABILITY_DATA_MODE=DEMO\n", encoding="utf-8")

    write_env_values({"PROFITABILITY_DB_USER": "alice"}, env_path=env_path)

    content = env_path.read_text(encoding="utf-8")
    assert "PROFITABILITY_DATA_MODE=DEMO" in content
    assert "PROFITABILITY_DB_USER=alice" in content


def test_apply_env_updates_reflects_in_os_environ(tmp_path, monkeypatch):
    env_path = tmp_path / ".env"
    monkeypatch.delenv("PROFITABILITY_DB_SERVER", raising=False)

    apply_env_updates({"PROFITABILITY_DB_SERVER": "srv-test"}, env_path=env_path)

    assert os.environ.get("PROFITABILITY_DB_SERVER") == "srv-test"
    # Nettoyage pour ne pas polluer les autres tests du process.
    del os.environ["PROFITABILITY_DB_SERVER"]


def test_apply_env_updates_password_never_written_with_extra_whitespace(tmp_path):
    env_path = tmp_path / ".env"
    apply_env_updates({"PROFITABILITY_DB_PASSWORD": "S3cr3t!"}, env_path=env_path)

    content = env_path.read_text(encoding="utf-8")
    assert "PROFITABILITY_DB_PASSWORD=S3cr3t!\n" in content
    os.environ.pop("PROFITABILITY_DB_PASSWORD", None)
