"""Tests pour app.ui.widgets.table_flex — tableaux plus flexibles (demande
utilisateur) : colonnes redimensionnables, tri correct par clic sur
l'en-tête (y compris sur une cellule déjà formatée pour l'affichage), et
choix des colonnes visibles.

Reproduit aussi un scénario concret : dans le tableau "Top 15 contrats par
montant de sinistres" (Claims) comme dans le "Top 10" du Dashboard, les
montants sont affichés déjà formatés (ex. "9,00 €" / "10,00 €") — un tri par
texte classerait "10,00 €" avant "9,00 €" ; le tri doit rester correct
(9 avant 10) car il se base sur le Decimal brut, pas sur le texte affiché.
"""
from __future__ import annotations

import os
import sys
from datetime import date
from decimal import Decimal

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pyside6 = pytest.importorskip("PySide6")

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QHeaderView, QTableWidget, QTableWidgetItem

from app.ui.widgets.table_flex import (
    ColumnVisibilityButton, FrozenColumnTableView, date_sort_key,
    enable_flexible_header, sortable_item,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication(sys.argv)
    return app


def test_sortable_item_sorts_by_raw_decimal_not_formatted_text(qapp):
    """"9,00 €" doit se trier avant "10,00 €" (9 < 10), alors qu'un tri texte
    classerait "10,00 €" en premier ("1" < "9" lexicalement)."""
    table = QTableWidget(2, 1)
    table.setItem(0, 0, sortable_item("10,00 €", Decimal("10")))
    table.setItem(1, 0, sortable_item("9,00 €", Decimal("9")))
    table.setSortingEnabled(True)

    table.sortItems(0, Qt.SortOrder.AscendingOrder)

    assert table.item(0, 0).text() == "9,00 €"
    assert table.item(1, 0).text() == "10,00 €"


def test_sortable_item_without_raw_value_falls_back_to_text():
    item = sortable_item("Abc")
    other = sortable_item("Abd")
    assert item < other


def test_date_sort_key_orders_business_dates_chronologically():
    early = date_sort_key("01/02/2024")
    late = date_sort_key("15/01/2026")
    assert early < late


def test_date_sort_key_handles_missing_or_invalid_dates_without_crashing():
    assert date_sort_key(None) == date.min
    assert date_sort_key("") == date.min
    assert date_sort_key("pas une date") == date.min


def test_enable_flexible_header_sets_interactive_resize_mode(qapp):
    table = QTableWidget(1, 3)
    table.setHorizontalHeaderLabels(["A", "B", "C"])

    enable_flexible_header(table)

    header = table.horizontalHeader()
    assert header.sectionResizeMode(0) == QHeaderView.ResizeMode.Interactive
    assert header.stretchLastSection() is True


def test_enable_flexible_header_enables_per_pixel_scroll_and_mouse_tracking(qapp):
    """v1.9.0 : défilement au pixel près (plus doux) et suivi de la souris
    (nécessaire pour la surbrillance au survol, voir app/ui/theme.py)."""
    from PySide6.QtWidgets import QAbstractItemView

    table = QTableWidget(1, 3)
    enable_flexible_header(table)

    assert table.horizontalScrollMode() == QAbstractItemView.ScrollMode.ScrollPerPixel
    assert table.verticalScrollMode() == QAbstractItemView.ScrollMode.ScrollPerPixel
    assert table.hasMouseTracking() is True


# --- FrozenColumnTableView (v1.9.0) : première colonne figée pendant le
# défilement horizontal, pour ne jamais perdre le repère (contrat/période)
# sur un tableau à beaucoup de colonnes (demande utilisateur). -------------

def _model_with_columns(n: int):
    from app.ui.widgets.table_model import ProfitabilityTableModel

    return ProfitabilityTableModel(rows=[], columns=[f"col{i}" for i in range(n)])


def test_frozen_column_table_view_shows_only_first_column_in_overlay(qapp):
    table = FrozenColumnTableView()
    table.setModel(_model_with_columns(5))

    assert table._frozen.isColumnHidden(0) is False
    for col in range(1, 5):
        assert table._frozen.isColumnHidden(col) is True


def test_frozen_column_table_view_resyncs_hidden_columns_on_model_reset(qapp):
    """Quand les colonnes affichées changent (ex. bouton « Colonnes » de
    Profitability Explorer, qui reconstruit entièrement le modèle), le
    tableau figé ne doit continuer à montrer que la (nouvelle) colonne 0."""
    table = FrozenColumnTableView()
    model = _model_with_columns(4)
    table.setModel(model)

    model.set_columns(["only_one_left"])

    assert table._frozen.isColumnHidden(0) is False
    assert table.model().columnCount() == 1


def test_frozen_column_table_view_syncs_vertical_scroll_both_ways(qapp):
    table = FrozenColumnTableView()
    table.resize(400, 300)
    model = _model_with_columns(6)
    model.set_rows([])  # garde un modèle vide valide ; le test porte sur la synchro des barres
    table.setModel(model)

    table.verticalScrollBar().setValue(table.verticalScrollBar().maximum())
    assert table._frozen.verticalScrollBar().value() == table.verticalScrollBar().value()


def test_frozen_column_table_view_handles_resize_without_crashing(qapp):
    table = FrozenColumnTableView()
    table.setModel(_model_with_columns(3))
    table.resize(900, 600)
    table.show()
    table.resize(500, 400)
    # Pas d'assertion de rendu (offscreen) : on vérifie seulement l'absence
    # d'exception lors du redimensionnement, qui recalcule la géométrie de
    # la vue figée superposée.


def test_column_visibility_button_toggles_section_hidden(qapp):
    table = QTableWidget(1, 3)
    table.setHorizontalHeaderLabels(["Contrat", "Compagnie", "Montant"])
    table.setItem(0, 0, QTableWidgetItem("C1"))
    table.setItem(0, 1, QTableWidgetItem("Co1"))
    table.setItem(0, 2, QTableWidgetItem("100"))

    button = ColumnVisibilityButton(table)
    header = table.horizontalHeader()
    assert not header.isSectionHidden(2)

    # Simule le décochage de la colonne "Montant" dans le menu.
    item = button._list.item(2)
    assert item.text() == "Montant"
    item.setCheckState(Qt.CheckState.Unchecked)

    assert header.isSectionHidden(2)


def test_column_visibility_button_never_hides_last_visible_column(qapp):
    """Sécurité : décocher les 2 premières colonnes ne doit jamais permettre
    de masquer la 3e restante (le tableau resterait vide de toute colonne)."""
    table = QTableWidget(1, 3)
    table.setHorizontalHeaderLabels(["A", "B", "C"])
    button = ColumnVisibilityButton(table)
    header = table.horizontalHeader()

    button._list.item(0).setCheckState(Qt.CheckState.Unchecked)
    button._list.item(1).setCheckState(Qt.CheckState.Unchecked)
    button._list.item(2).setCheckState(Qt.CheckState.Unchecked)

    assert header.isSectionHidden(0)
    assert header.isSectionHidden(1)
    assert not header.isSectionHidden(2)
    # Le menu reflète le refus : la case de la colonne C reste cochée.
    assert button._list.item(2).checkState() == Qt.CheckState.Checked


# --- Tests d'intégration : les pages réelles s'affichent toujours sans
# erreur avec ces tableaux rendus plus flexibles (tri, redimensionnement,
# colonnes visibles), sur des données DEMO réalistes. ------------------------

def test_dashboard_page_renders_with_sortable_flexible_tables(qapp):
    from tests.support.demo_data_provider import DemoDataProvider
    from app.ui.pages.dashboard_page import DashboardPage
    from app.ui.state import AppState

    page = DashboardPage(AppState(DemoDataProvider()))
    tables = page.findChildren(QTableWidget)
    assert len(tables) >= 2
    for table in tables:
        assert table.isSortingEnabled()
        assert table.horizontalHeader().sectionResizeMode(0) == QHeaderView.ResizeMode.Interactive


def test_claims_page_renders_with_sortable_flexible_table(qapp):
    from tests.support.demo_data_provider import DemoDataProvider
    from app.ui.pages.claims_page import ClaimsPage
    from app.ui.state import AppState

    page = ClaimsPage(AppState(DemoDataProvider()))
    tables = page.findChildren(FrozenColumnTableView)
    assert tables
    assert tables[0].isSortingEnabled()


def test_explorer_page_table_is_frozen_column_and_anchors_contract_first(qapp):
    """v1.9.0 : Profitability Explorer utilise une colonne figée, et quel que
    soit l'ordre dans lequel l'utilisateur coche les colonnes via le bouton
    « Colonnes », la colonne Contrat reste toujours en première position
    (c'est elle qui sert de repère pendant le défilement)."""
    from app.core.models import COLUMN_LABELS
    from app.ui.pages.explorer_page import ExplorerPage, _anchor_first
    from app.ui.state import AppState
    from tests.support.demo_data_provider import DemoDataProvider

    page = ExplorerPage(AppState(DemoDataProvider()))
    assert isinstance(page._table, FrozenColumnTableView)

    # Simule une sélection de colonnes dans l'ordre du menu (pas celui du
    # dépliant « Colonnes ») — reproduit le scénario signalé par
    # l'utilisateur où « Contrat » n'était pas la première colonne affichée.
    columns_in_menu_order = list(COLUMN_LABELS.keys())
    assert columns_in_menu_order[0] != "identifiant_contrat_tdb"

    page._on_columns_changed(columns_in_menu_order)

    assert page._columns[0] == "identifiant_contrat_tdb"
    assert page._model.columns()[0] == "identifiant_contrat_tdb"
    assert set(page._columns) == set(columns_in_menu_order)


def test_anchor_first_leaves_columns_unchanged_when_contract_absent():
    from app.ui.pages.explorer_page import _anchor_first

    columns = ["compagny", "distributor"]
    assert _anchor_first(columns) == columns


def test_data_quality_page_renders_with_sortable_flexible_tables(qapp):
    from tests.support.demo_data_provider import DemoDataProvider
    from app.ui.pages.data_quality_page import DataQualityPage
    from app.ui.state import AppState

    page = DataQualityPage(AppState(DemoDataProvider()))
    tables = page.findChildren(QTableWidget)
    assert len(tables) >= 5
    for table in tables:
        assert table.isSortingEnabled()
