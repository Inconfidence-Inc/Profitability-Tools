"""Tests pour le contrôle Data Quality "contrat sans référentiel" (v1.7.0) —
jointure par plage de dates (prog.date_debut <= période <= prog.date_fin),
confirmée par l'utilisateur à partir de la vraie requête de génération de
TDB Part1 (remplace l'ancienne logique "dernière version par UPDATE DATE")."""
from app.core.referentiel import build_referentiel_periods_index, has_referentiel_covering_period


def test_matches_when_period_fully_covered_by_a_referentiel_version():
    rows = [{"contrat": "C1", "date_debut": "01/01/2024", "date_fin": "31/12/2026"}]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "01/06/2025", "28/06/2025") is True


def test_no_match_when_period_falls_outside_every_version():
    rows = [{"contrat": "C1", "date_debut": "01/01/2020", "date_fin": "31/12/2021"}]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "01/06/2025", "28/06/2025") is False


def test_no_match_when_contract_has_no_referentiel_row_at_all():
    rows = [{"contrat": "C1", "date_debut": "01/01/2024", "date_fin": "31/12/2026"}]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C2", "01/06/2025", "28/06/2025") is False


def test_rows_without_contrat_are_ignored():
    rows = [
        {"contrat": None, "date_debut": "01/01/2024", "date_fin": "31/12/2026"},
        {"contrat": "", "date_debut": "01/01/2024", "date_fin": "31/12/2026"},
    ]
    index = build_referentiel_periods_index(rows)
    assert index == {}


def test_rows_with_unparseable_dates_are_ignored():
    rows = [{"contrat": "C1", "date_debut": "n/a", "date_fin": "31/12/2026"}]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "01/06/2025", "28/06/2025") is False


def test_multiple_contracts_independent():
    rows = [
        {"contrat": "C1", "date_debut": "01/01/2024", "date_fin": "31/12/2026"},
        {"contrat": "C2", "date_debut": "01/01/2020", "date_fin": "31/12/2021"},
    ]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "01/06/2025", "28/06/2025") is True
    assert has_referentiel_covering_period(index, "C2", "01/06/2025", "28/06/2025") is False


def test_multiple_versions_one_covering_is_enough():
    rows = [
        {"contrat": "C1", "date_debut": "01/01/2020", "date_fin": "31/12/2021"},
        {"contrat": "C1", "date_debut": "01/01/2024", "date_fin": "31/12/2026"},
    ]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "01/06/2025", "28/06/2025") is True


def test_period_partially_outside_version_window_does_not_match():
    """La version doit couvrir ENTIEREMENT la période (date_debut <= début
    ET date_fin >= fin) — pas seulement en chevaucher une partie."""
    rows = [{"contrat": "C1", "date_debut": "01/01/2025", "date_fin": "15/06/2025"}]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "01/06/2025", "28/06/2025") is False


def test_no_match_when_period_dates_are_unparseable():
    rows = [{"contrat": "C1", "date_debut": "01/01/2024", "date_fin": "31/12/2026"}]
    index = build_referentiel_periods_index(rows)
    assert has_referentiel_covering_period(index, "C1", "pas une date", "28/06/2025") is False
