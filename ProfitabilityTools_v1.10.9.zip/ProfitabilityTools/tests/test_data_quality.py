from decimal import Decimal

from app.core.data_quality import build_data_quality_report
from app.core.models import ProfitabilityRow


def test_contrats_sans_referentiel():
    rows = [ProfitabilityRow(identifiant_contrat_tdb="C1", has_referentiel_match=False)]
    report = build_data_quality_report(rows)
    assert len(report.contrats_sans_referentiel) == 1


def test_price_range_non_interpretable():
    rows = [ProfitabilityRow(identifiant_contrat_tdb="C1", price_range="???", borne_min=None, borne_max=None)]
    report = build_data_quality_report(rows)
    assert len(report.price_ranges_non_interpretables) == 1


def test_price_range_suspect_min_greater_than_max():
    rows = [ProfitabilityRow(identifiant_contrat_tdb="C1", borne_min=Decimal("500"), borne_max=Decimal("100"))]
    report = build_data_quality_report(rows)
    assert len(report.price_ranges_suspects) == 1


def test_duplicate_keys_with_differing_amounts_flagged():
    rows = [
        ProfitabilityRow(identifiant_contrat_tdb="C1", key_contrat_date="K1", volumes_primes_ttc=Decimal("100")),
        ProfitabilityRow(identifiant_contrat_tdb="C1", key_contrat_date="K1", volumes_primes_ttc=Decimal("200")),
    ]
    report = build_data_quality_report(rows)
    assert "K1" in report.cles_dupliquees


def test_duplicate_keys_with_identical_amounts_not_flagged():
    rows = [
        ProfitabilityRow(identifiant_contrat_tdb="C1", key_contrat_date="K1", volumes_primes_ttc=Decimal("100")),
        ProfitabilityRow(identifiant_contrat_tdb="C1", key_contrat_date="K1", volumes_primes_ttc=Decimal("100")),
    ]
    report = build_data_quality_report(rows)
    assert "K1" not in report.cles_dupliquees


def test_orphan_claims_detected():
    """v1.8.0 : rattachement par (Numero_Police, année, mois) dérivés de
    Date_Souscription_Adhesion — pas une égalité de date, l'année+mois
    suffit (cf. app/core/aggregation.py)."""
    rows = [ProfitabilityRow(identifiant_contrat_tdb="C1", annee=2026, mois=1)]
    sinistres = [
        {"Numero_Police": "C1", "Date_Souscription_Adhesion": "15/01/2026"},  # même contrat+mois -> pas orphelin
        {"Numero_Police": "C_INCONNU", "Date_Souscription_Adhesion": "15/01/2026"},  # police inconnue -> orphelin
        {"Numero_Police": "C1", "Date_Souscription_Adhesion": "15/06/2026"},  # bon contrat, mauvais mois -> orphelin
    ]
    report = build_data_quality_report(rows, sinistres)
    assert len(report.sinistres_orphelins) == 2


def test_claim_matching_contract_and_month_is_not_orphan():
    rows = [ProfitabilityRow(identifiant_contrat_tdb="C1", annee=2026, mois=1)]
    sinistres = [{"Numero_Police": "C1", "Date_Souscription_Adhesion": "01/01/2026"}]
    report = build_data_quality_report(rows, sinistres)
    assert len(report.sinistres_orphelins) == 0
