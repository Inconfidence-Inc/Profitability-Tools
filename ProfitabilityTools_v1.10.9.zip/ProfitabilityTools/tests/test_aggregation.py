"""
Dataset de test de bout en bout avec résultats attendus connus (§22),
couvrant : jointure référentiel (plage de dates, v1.7.0), rattachement
sinistres via Key_Contrat_Date, NULL -> 0, Total_Com, price range.

Noms de colonnes : ceux réels de [TECH_BI].[dbo].[SRC_TDBPART1]/[SRC_TDBPART2]
confirmés par l'utilisateur (v1.7.0) — voir app/data/sqlserver_provider.py.
"""
from decimal import Decimal

from app.core.aggregation import build_profitability_dataset


def _part1_rows():
    return [
        {
            "date_debut_periode_souscription": "01/01/2026",
            "date_fin_periode_souscription": "31/01/2026",
            "regularisation": "Normal",
            "pays": "France",
            "compagnie": "Compagnie A",
            "libelle_distributeur": "Distrib A",
            "libelle_produit": "Produit récent",
            "gestionnaire_1": "TPA A",
            "courtier_1": "Courtier A",
            "identifiant_contrat": "CONTRACT123",
            "code_devise_quittance": "EUR",
            "nombre_total_adhesions": 10,
            "montant_total_ttc": "1000.00",
            "montant_total_ht": "900.00",
            "montant_total_prime_assureur": "800.00",
            "montant_total_commission_ici": "50.00",
            "montant_total_commission_distributeur": "20.00",
            "montant_total_frais_gestion": "10.00",
            "montant_total_autres_commissions_1": "5.00",
            "montant_total_autres_commissions_2": None,
            "montant_total_autres_commissions_3": None,
        },
        {
            # Contrat sans référentiel ni sinistres, montants NULL -> doivent devenir 0
            "date_debut_periode_souscription": "01/02/2026",
            "date_fin_periode_souscription": "28/02/2026",
            "regularisation": "Normal",
            "pays": "France",
            "compagnie": "Compagnie B",
            "libelle_distributeur": "Distrib B",
            "libelle_produit": "Produit B",
            "gestionnaire_1": "TPA B",
            "courtier_1": "",
            "identifiant_contrat": "CONTRACT999",
            "code_devise_quittance": "EUR",
            "nombre_total_adhesions": None,
            "montant_total_ttc": None,
            "montant_total_ht": None,
            "montant_total_prime_assureur": None,
            "montant_total_commission_ici": None,
            "montant_total_commission_distributeur": None,
            "montant_total_frais_gestion": None,
            "montant_total_autres_commissions_1": None,
            "montant_total_autres_commissions_2": None,
            "montant_total_autres_commissions_3": None,
        },
    ]


def _referentiel_rows():
    # Jointure par plage de dates (v1.7.0) : une version couvrant la période
    # du contrat suffit à produire has_referentiel_match=True. CONTRACT999
    # n'a volontairement aucune ligne référentiel.
    return [
        {"contrat": "CONTRACT123", "date_debut": "01/01/2025", "date_fin": "31/12/2026"},
    ]


def _part2_rows():
    return [
        {
            "identifiant_contrat": "CONTRACT123",
            "date_debut_periode_souscription": "01/01/2026",
            "nombre_resiliations": 2,
            "reference": "REF-B",
            "code_critere_tarifaire_1": "Plus de 500",
        },
        {
            "identifiant_contrat": "CONTRACT123",
            "date_debut_periode_souscription": "01/01/2026",
            "nombre_resiliations": 3,
            "reference": "REF-A",  # alphabétiquement avant REF-B -> doit être retenue (rn=1)
            "code_critere_tarifaire_1": "100 à 500",
        },
    ]


def _sinistres_rows():
    # v1.8.0 : lignes BRUTES (un sinistre par ligne, comme la vraie source
    # SRC_Sinistre_Transformer_Contenu). Rattachées à CONTRACT123/janvier 2026
    # via Numero_Police + année/mois de Date_Souscription_Adhesion (pas une
    # date exacte, cf. app/core/aggregation.py) -> 4 sinistres pour 1200.00
    # au total : 1 en cours (200), 1 refusé (100), 2 acceptés (500+400=900).
    return [
        {
            "Numero_Police": "CONTRACT123",
            "Date_Souscription_Adhesion": "05/01/2026",
            "Statut_Technique_Sinistre": "En cours",
            "Montant_Total_Reglement": "200.00",
        },
        {
            "Numero_Police": "CONTRACT123",
            "Date_Souscription_Adhesion": "12/01/2026",
            "Statut_Technique_Sinistre": "Refusé",
            "Montant_Total_Reglement": "100.00",
        },
        {
            "Numero_Police": "CONTRACT123",
            "Date_Souscription_Adhesion": "20/01/2026",
            "Statut_Technique_Sinistre": "Terminé - accepté",
            "Montant_Total_Reglement": "500.00",
        },
        {
            "Numero_Police": "CONTRACT123",
            "Date_Souscription_Adhesion": "27/01/2026",
            "Statut_Technique_Sinistre": "Terminé accepte",
            "Montant_Total_Reglement": "400.00",
        },
    ]


def test_build_profitability_dataset_end_to_end():
    result = build_profitability_dataset(
        _part1_rows(), _referentiel_rows(), _part2_rows(), _sinistres_rows()
    )
    assert len(result) == 2

    contract123 = next(r for r in result if r.identifiant_contrat_tdb == "CONTRACT123")
    contract999 = next(r for r in result if r.identifiant_contrat_tdb == "CONTRACT999")

    # Key_Contrat_Date
    assert contract123.key_contrat_date == "CONTRACT123_01012026"

    # Produit éligible / Régularisation viennent directement de Part1 (v1.7.0)
    assert contract123.eligible_product == "Produit récent"
    assert contract123.regularisation == "Normal"
    assert contract123.pays == "France"
    assert contract123.tpa == "TPA A"
    assert contract123.courtier == "Courtier A"

    # Référentiel : version couvrant la période -> has_referentiel_match
    assert contract123.has_referentiel_match is True

    # NOMBRE RESILIATIONS vient de la somme Part2 (2+3=5)
    assert contract123.nbre_resiliation == Decimal("5")

    # Choix tarifaire rn=1 par REFERENCE ASC -> REF-A / "100 à 500"
    assert contract123.reference == "REF-A"
    assert contract123.price_range == "100 à 500"
    assert contract123.borne_min == Decimal("100.00")
    assert contract123.borne_max == Decimal("500.00")

    # Total_Com = 50 + 20 + 10 + (5+0+0) = 85
    assert contract123.sum_other_commission == Decimal("5")
    assert contract123.total_com == Decimal("85")

    # Rattachement sinistres via (Numero_Police, année, mois) — v1.8.0
    assert contract123.has_claims_match is True
    assert contract123.nombre_sinistres_total == Decimal("4")
    assert contract123.montant_total_reglement == Decimal("1200.00")

    # Contrat sans référentiel / sans sinistres / montants NULL -> 0
    assert contract999.has_referentiel_match is False
    assert contract999.has_claims_match is False
    assert contract999.nombre_sinistres_total == Decimal("0")
    assert contract999.volumes_primes_ttc == Decimal("0")
    assert contract999.total_com == Decimal("0")


def test_exact_duplicate_part1_rows_are_collapsed():
    row = _part1_rows()[0]
    result = build_profitability_dataset([row, dict(row)], [], [], [])
    assert len(result) == 1  # GROUP BY SQL collapse des lignes strictement identiques


def test_distinct_part1_rows_same_key_are_not_summed():
    """Réplique le comportement du GROUP BY SQL (pas de SUM réelle) : deux
    lignes Part1 différentes pour la même clé restent deux lignes."""
    row_a = _part1_rows()[0]
    row_b = dict(row_a)
    row_b["montant_total_ttc"] = "2000.00"  # même clé, montant différent

    result = build_profitability_dataset([row_a, row_b], [], [], [])
    assert len(result) == 2
    keys = {r.key_contrat_date for r in result}
    assert keys == {"CONTRACT123_01012026"}
    totals = sorted(r.volumes_primes_ttc for r in result)
    assert totals == [Decimal("1000.00"), Decimal("2000.00")]


def test_sinistres_month_level_matching_ignores_exact_day():
    """v1.8.0 : le rattachement sinistres compare année+mois, pas le jour
    exact (Date_Souscription_Adhesion est une date d'adhésion réelle, jamais
    égale au 1er du mois de date_debut_periode_souscription)."""
    row = _part1_rows()[0]  # CONTRACT123, période 01/01/2026 - 31/01/2026
    sinistres = [
        {
            "Numero_Police": "CONTRACT123",
            "Date_Souscription_Adhesion": "31/01/2026",  # dernier jour du mois, pas le 1er
            "Statut_Technique_Sinistre": "Terminé - accepté",
            "Montant_Total_Reglement": "75.00",
        }
    ]
    result = build_profitability_dataset([row], [], [], sinistres)
    assert len(result) == 1
    assert result[0].has_claims_match is True
    assert result[0].nombre_sinistres_total == Decimal("1")
    assert result[0].nb_sinistres_acceptes == Decimal("1")
    assert result[0].montant_acceptes == Decimal("75.00")


def test_sinistres_wrong_month_is_not_matched():
    row = _part1_rows()[0]  # CONTRACT123, janvier 2026
    sinistres = [
        {
            "Numero_Police": "CONTRACT123",
            "Date_Souscription_Adhesion": "15/02/2026",  # février, pas janvier
            "Statut_Technique_Sinistre": "Terminé - accepté",
            "Montant_Total_Reglement": "75.00",
        }
    ]
    result = build_profitability_dataset([row], [], [], sinistres)
    assert result[0].has_claims_match is False
    assert result[0].nombre_sinistres_total == Decimal("0")


def test_sinistres_status_breakdown_across_all_four_categories():
    row = _part1_rows()[0]  # CONTRACT123, janvier 2026
    sinistres = [
        {"Numero_Police": "CONTRACT123", "Date_Souscription_Adhesion": "02/01/2026",
         "Statut_Technique_Sinistre": "Terminé - accepté", "Montant_Total_Reglement": "100.00"},
        {"Numero_Police": "CONTRACT123", "Date_Souscription_Adhesion": "05/01/2026",
         "Statut_Technique_Sinistre": "Annulé gestion", "Montant_Total_Reglement": "50.00"},
        {"Numero_Police": "CONTRACT123", "Date_Souscription_Adhesion": "09/01/2026",
         "Statut_Technique_Sinistre": "En attente de prescription", "Montant_Total_Reglement": "30.00"},
        {"Numero_Police": "CONTRACT123", "Date_Souscription_Adhesion": "11/01/2026",
         "Statut_Technique_Sinistre": "Un statut jamais vu", "Montant_Total_Reglement": "10.00"},
    ]
    result = build_profitability_dataset([row], [], [], sinistres)
    out = result[0]
    assert out.nombre_sinistres_total == Decimal("4")
    assert out.montant_total_reglement == Decimal("190.00")
    assert out.nb_sinistres_acceptes == Decimal("1") and out.montant_acceptes == Decimal("100.00")
    assert out.nb_sinistres_refuses == Decimal("1") and out.montant_refuses == Decimal("50.00")  # Annulé gestion -> REFUS
    assert out.nb_sinistres_en_cours == Decimal("1") and out.montant_en_cours == Decimal("30.00")  # En attente -> EN_COURS
    assert out.nb_sinistres_inconnus == Decimal("1") and out.montant_inconnus == Decimal("10.00")


def test_sinistres_unknown_police_never_matches():
    row = _part1_rows()[0]
    sinistres = [
        {"Numero_Police": "AUTRE_CONTRAT", "Date_Souscription_Adhesion": "15/01/2026",
         "Statut_Technique_Sinistre": "Terminé - accepté", "Montant_Total_Reglement": "75.00"},
    ]
    result = build_profitability_dataset([row], [], [], sinistres)
    assert result[0].has_claims_match is False
