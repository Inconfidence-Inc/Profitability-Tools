"""Non-régression (v1.10.5) sur build_exe.bat : l'exécutable construit par
PyInstaller se fermait instantanément, sans aucun message (mode --windowed =
aucune console), dès la première tentative de connexion à la base
d'authentification (locale SQLite au premier lancement, ou OUTILS en SQL
Server, voir app/auth/ et auth_partage/). Cause réelle : SQLAlchemy résout
son "dialecte" (sqlite, mssql+pyodbc, ...) par un import dynamique basé sur
le préfixe de l'URL de connexion (create_engine("sqlite:///...") importe
sqlalchemy.dialects.sqlite.pysqlite au moment de l'appel) — l'analyse
statique de PyInstaller ne suit jamais ce genre d'import, donc sans
--collect-all explicite, l'exécutable ne contenait tout simplement pas ces
modules, et le premier create_engine() levait un ModuleNotFoundError fatal,
invisible sans console.

Ce test n'exécute pas PyInstaller (trop long/lourd pour la suite pytest et
inutile sous Linux, sans l'environnement Windows cible) : il vérifie
seulement que build_exe.bat contient bien les options --collect-all
nécessaires, pour qu'une future modification de ce fichier ne fasse pas
involontairement disparaître ce correctif."""
from __future__ import annotations

from pathlib import Path

BUILD_SCRIPT = Path(__file__).resolve().parents[1] / "build_exe.bat"
LAUNCH_SCRIPT = Path(__file__).resolve().parents[1] / "lancer.bat"


def _pyinstaller_line() -> str:
    for line in BUILD_SCRIPT.read_text(encoding="utf-8").splitlines():
        if "PyInstaller" in line and "--windowed" in line:
            return line
    raise AssertionError("Ligne de commande PyInstaller introuvable dans build_exe.bat")


def test_build_script_exists():
    assert BUILD_SCRIPT.is_file()


def test_pyinstaller_command_collects_sqlalchemy_dialects():
    """Cœur du correctif : sans ceci, les dialectes sqlite/mssql+pyodbc de
    SQLAlchemy (chargés dynamiquement par create_engine) sont absents de
    l'exécutable, qui plante dès la première connexion à la base
    d'authentification."""
    assert "--collect-all sqlalchemy" in _pyinstaller_line()


def test_pyinstaller_command_collects_auth_dependencies():
    """bcrypt (hachage des mots de passe) et cryptography (chiffrement du
    profil de connexion OUTILS) ont aussi des composants compilés/liés
    dynamiquement — embarqués en intégralité par prudence, pour la même
    raison que SQLAlchemy."""
    line = _pyinstaller_line()
    for pkg in ("bcrypt", "cryptography"):
        assert f"--collect-all {pkg}" in line


def test_pyinstaller_command_collects_auth_partage_package():
    """auth_partage/ est le module d'authentification partagé avec le reste
    du parc (v1.10.0) : embarqué en intégralité pour ne jamais dépendre de
    la détection automatique des imports de PyInstaller sur ce paquet."""
    assert "--collect-all auth_partage" in _pyinstaller_line()


def test_pyinstaller_command_still_collects_pyside6_and_assets():
    """Non-régression : le correctif v1.10.5 ajoute des options, il ne doit
    jamais retirer celles déjà nécessaires (plugins Qt, logo/icône)."""
    line = _pyinstaller_line()
    assert "--collect-all PySide6" in line
    assert "--icon app\\assets\\logo.ico" in line
    assert '--add-data "app\\assets;app\\assets"' in line


def test_every_rem_line_is_a_valid_comment():
    """Non-régression concrète : la toute première version du correctif
    v1.10.5 contenait elle-même un bug (« rem/sqlalchemy... » au lieu de
    « rem sqlalchemy... ») — sans espace après "rem", Windows cmd.exe ne
    reconnaît PAS le mot-clé REM (il doit être suivi d'un espace ou d'une
    fin de ligne) et tente d'exécuter le reste de la ligne comme une
    commande, provoquant une erreur « n'est pas reconnu » et empêchant la
    construction de l'exécutable. Ce test vérifie que toute ligne commençant
    par "rem" (insensible à la casse) est bien suivie d'un espace ou de rien
    d'autre — jamais d'un autre caractère collé directement."""
    for i, raw_line in enumerate(BUILD_SCRIPT.read_text(encoding="utf-8").splitlines(), start=1):
        stripped = raw_line.strip()
        lower = stripped.lower()
        if lower == "rem" or lower.startswith("rem "):
            continue
        assert not lower.startswith("rem"), (
            f"Ligne {i} de build_exe.bat commence par 'rem' sans espace "
            f"derrière (donc ce n'est PAS un commentaire pour cmd.exe) : "
            f"{raw_line!r}"
        )


def test_build_script_is_pure_ascii():
    """Le script évite volontairement les caractères accentués (voir ses
    propres commentaires : "Interpreteur", "dependances", "executable" sans
    accent) pour ne jamais dépendre de l'encodage/page de code du poste
    Windows cible au moment de l'exécution. Non-régression : un ajout futur
    (commentaire, message) ne doit pas réintroduire de caractère non-ASCII."""
    content = BUILD_SCRIPT.read_text(encoding="utf-8")
    non_ascii = [c for c in content if ord(c) > 127]
    assert not non_ascii, f"Caractères non-ASCII trouvés dans build_exe.bat : {non_ascii!r}"


def test_build_and_launch_scripts_use_crlf_line_endings():
    """Non-régression (v1.10.7) : l'utilisateur a remonté une nouvelle
    erreur, cette fois sur la construction d'un simple cmd.exe ouvert
    manuellement (pour garder la fenêtre affichée) — un message de syntaxe
    cmd.exe (« ... était inattendu. ») juste après l'affichage du dossier
    courant, avant même la détection de Python. Ces deux fichiers .bat
    avaient toujours été écrits avec des fins de ligne Unix (LF seul) par
    les outils d'édition utilisés ici (Linux), jamais corrigé jusqu'ici —
    hors un fichier .bat Windows doit utiliser des fins de ligne CRLF ; un
    fichier LF-seul peut faire dérailler l'analyse par cmd.exe d'un bloc
    IF/ELSE multi-lignes (exactement le genre de bloc qui suit
    immédiatement l'endroit où l'erreur apparaissait). Corrigé en
    convertissant les deux scripts en CRLF explicite — format canonique et
    sans ambiguïté pour un script Windows, qui élimine ce risque plutôt que
    de compter sur une tolérance non garantie de cmd.exe."""
    for script in (BUILD_SCRIPT, LAUNCH_SCRIPT):
        raw = script.read_bytes()
        assert b"\r\n" in raw, f"{script.name} ne contient aucune fin de ligne CRLF"
        # Toute fin de ligne doit être CRLF : un \n non précédé de \r trahit
        # une ligne restée en LF seul (fin de ligne Unix).
        bare_lf = raw.replace(b"\r\n", b"").count(b"\n")
        assert bare_lf == 0, (
            f"{script.name} contient {bare_lf} fin(s) de ligne LF-seul "
            f"(non CRLF) — un fichier .bat Windows doit être 100% CRLF"
        )


def test_no_literal_parentheses_in_echo_lines():
    """Non-régression (v1.10.8) : après le correctif CRLF de la v1.10.7,
    l'utilisateur a remonté le même symptôme (fenêtre qui se ferme
    aussitôt, build_log.txt quasiment vide) — cause réelle, distincte de
    la v1.10.7 : une ligne « echo ERREUR : aucun interpreteur Python
    trouve (ni "py" ni "python"). » contenait des PARENTHÈSES LITTÉRALES,
    à l'intérieur même du bloc IF/ELSE de détection de Python (lignes
    indentées entre un « (ni-else ( » et son « ) » correspondant). Or
    cmd.exe repère la fin d'un bloc IF/ELSE ou FOR en comptant les
    parenthèses de façon purement textuelle sur TOUTE la ligne — y compris
    celles qui ne sont que du texte affiché par un echo, sans aucun rapport
    avec la structure du bloc. Cela peut faire dérailler l'analyse de blocs
    imbriqués (symptôme typique : erreur cryptique « ... était inattendu. »,
    ou arrêt total du script avant tout affichage, y compris avant le
    `pause` final). Corrigé en reformulant les messages sans aucune
    parenthèse littérale. Ce test interdit toute parenthèse non échappée
    (^( / ^)) sur une ligne "echo", quelle que soit sa position — y compris
    hors d'un bloc actuellement, par prudence : un echo aujourd'hui sans
    bloc autour peut se retrouver déplacé dans un bloc plus tard."""
    for script in (BUILD_SCRIPT, LAUNCH_SCRIPT):
        for i, raw_line in enumerate(script.read_text(encoding="utf-8").splitlines(), start=1):
            stripped = raw_line.strip()
            if not stripped.lower().startswith("echo"):
                continue
            unescaped = stripped.replace("^(", "").replace("^)", "")
            assert "(" not in unescaped and ")" not in unescaped, (
                f"{script.name} ligne {i} : parenthese litterale dans une "
                f"ligne echo — dangereux si cette ligne se trouve (ou se "
                f"retrouve un jour) a l'interieur d'un bloc IF/ELSE ou FOR : "
                f"{raw_line!r}"
            )


def test_pyinstaller_command_builds_a_single_file_exe():
    """Non-régression (v1.10.9) : demande explicite de l'utilisateur après un
    échec au lancement de l'exécutable construit en mode --onedir (par
    défaut) — « Failed to start embedded python interpreter: Failed to
    import encodings module ». Ce mode produit dist/ProfitabilityTools/ avec
    l'exe ET un dossier _internal séparé de plusieurs centaines de Mo
    (dépendances PySide6/SQLAlchemy/cryptography/...), sensible à une copie
    partielle, un antivirus qui met en quarantaine un fichier interne, ou une
    synchronisation OneDrive qui laisse des fichiers à l'état de simples
    références non téléchargées — l'utilisateur a confirmé que le dossier
    _internal était bien présent et de taille plausible (530 Mo), rendant ces
    causes probables sans pouvoir être vérifiées à distance. Corrigé en
    ajoutant --onefile : un unique fichier .exe autonome, qui s'auto-extrait
    dans un dossier temporaire à chaque lancement plutôt que de dépendre d'un
    dossier externe copié/partagé à côté de lui. Ce test vérifie que l'option
    reste présente dans la commande PyInstaller."""
    assert "--onefile" in _pyinstaller_line()
