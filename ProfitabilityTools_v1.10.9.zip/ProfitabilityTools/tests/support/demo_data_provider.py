"""
Générateur de données synthétiques (RÉSERVÉ AUX TESTS ET AUX CAPTURES DE LA
DOCUMENTATION — v1.7.0) : données fictives réalistes générées en mémoire,
couvrant plusieurs compagnies, distributeurs, TPA/gestionnaires, courtiers,
pays, produits, contrats, années/mois, devises, tranches tarifaires et
statuts de sinistres.

Historique : jusqu'à la v1.5.0, ce provider alimentait un véritable "mode
DEMO" sélectionnable dans l'application (écran Settings). Depuis la v1.6.0,
sur demande explicite de l'utilisateur, ce mode a été retiré de
l'application — ProfitabilityTools fonctionne désormais exclusivement avec
une connexion SQL Server réelle (Recette ou Production, voir
app/config/settings.py). Ce générateur reste néanmoins précieux pour les
tests automatisés (pytest) et pour produire les captures d'écran de la
documentation sans dépendre d'une vraie base de données — d'où son
déplacement hors du package `app/` (il n'est plus livré avec l'exécutable).

Depuis la v1.7.0, le schéma généré reproduit les vraies colonnes de
[TECH_BI].[dbo].[SRC_TDBPART1]/[SRC_TDBPART2] (confirmées par l'utilisateur
à partir de la requête SQL de génération réelle) plutôt que les anciens noms
supposés de TDB_Part1/TDB_Part2 — voir app/data/sqlserver_provider.py et
app/core/aggregation.py.

Depuis la v1.8.0, les sinistres générés reproduisent eux aussi le vrai
schéma BRUT de [TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu] (un
sinistre par ligne, Numero_Police/Date_Souscription_Adhesion/
Statut_Technique_Sinistre/Montant_Total_Reglement — avec de vrais libellés
de statut confirmés par l'utilisateur) plutôt que l'ancienne table
pré-agrégée TDB_Sinistres_Agrégés.

AUCUNE de ces données n'est une donnée de production réelle (is_demo_data=True,
via DataProvider.is_demo).

Le jeu est généré avec une graine aléatoire fixe (reproductible d'une
exécution à l'autre) et injecte volontairement quelques anomalies
(contrat sans référentiel, tranche tarifaire illisible, sinistre orphelin,
clé dupliquée avec montants différents) afin que l'écran Data Quality ait
toujours quelque chose à montrer.
"""
from __future__ import annotations

import random
from datetime import date
from decimal import Decimal
from typing import Any

from app.data.provider import DataProvider

_SEED = 20260914  # date du jour du projet — reproductible

_COMPAGNIES = ["AssurCo Europe", "NovaSanté", "Bouclier Mutuel", "GlobalCover", "Alpha Assurance"]
_DISTRIBUTEURS = ["Distrib Nord", "Distrib Sud", "PartnerConnect", "RetailPlus", "VoyageDirect", "ShopSecure"]
_GESTIONNAIRES = ["SPB France", "SPB Italie", "SPB Espagne", "SPB Pologne", "Evy", "Estaly", "NEAT", "LAPI", "Garantie Privée"]
_COURTIERS = ["Courtier Nord", "Courtier Sud", "Courtage Europe", ""]
_PRODUITS = ["Extension Garantie", "Assurance Voyage", "Protection Achats", "Assurance Mobile", "Garantie Panne"]
_REGULARISATIONS = ["Normal", "Régularisation"]
_PAYS = ["France", "Italie", "Espagne", "Pologne", "Allemagne"]
_DEVISES = ["EUR", "PLN", "ALL", "EUR", "EUR"]  # EUR pondéré plus fréquent
_PRICE_RANGES = [
    "Moins de 500",
    "500 à 1000",
    "1000 a 1500",
    "1500 / 2000",
    "PVMC de 300",
    "2000 et plus",
    "300 EUR TTC",
    ">2500",
    "",
]

# Vrais libellés de Statut_Technique_Sinistre (TECH_BI.dbo.SRC_Sinistre_Transformer_Contenu,
# v1.8.0), couvrant les 3 catégories Accepté/Refusé/En cours mappées par
# app/config/status_mapping.py (le cas Inconnu correspond à NULL, non simulé
# ici — il est couvert par les tests unitaires de status_mapping.py).
_STATUTS_SINISTRE_ACCEPT = ["Terminé - accepté", "Terminé accepte", "Réglé"]
_STATUTS_SINISTRE_REFUS = [
    "Terminé - Refusé après instruction", "Terminé sans suite", "Terminé - prescrit",
    "Annulé gestion", "Refusé",
]
_STATUTS_SINISTRE_EN_COURS = ["En cours - accepté", "En cours", "En attente de prescription", "En cours d'instruction"]
_STATUTS_SINISTRE = _STATUTS_SINISTRE_ACCEPT + _STATUTS_SINISTRE_REFUS + _STATUTS_SINISTRE_EN_COURS


def _fmt(d: date) -> str:
    return d.strftime("%d/%m/%Y")


def _month_range(start_year: int, n_months: int):
    y, m = start_year, 1
    out = []
    for _ in range(n_months):
        out.append((y, m))
        m += 1
        if m > 12:
            m = 1
            y += 1
    return out


class DemoDataProvider(DataProvider):
    mode_name = "DEMO"
    is_demo = True

    def __init__(self, n_contracts: int = 60, seed: int = _SEED):
        self._rng = random.Random(seed)
        self._n_contracts = n_contracts
        self._part1: list[dict[str, Any]] | None = None
        self._referentiel: list[dict[str, Any]] | None = None
        self._part2: list[dict[str, Any]] | None = None
        self._sinistres: list[dict[str, Any]] | None = None

    # ------------------------------------------------------------------ #
    # Génération (mémorisée pour rester stable pendant la session)
    # ------------------------------------------------------------------ #
    def _ensure_generated(self) -> None:
        if self._part1 is not None:
            return
        rng = self._rng

        part1: list[dict[str, Any]] = []
        referentiel: list[dict[str, Any]] = []
        part2: list[dict[str, Any]] = []
        sinistres: list[dict[str, Any]] = []

        months = _month_range(2024, 24)  # 2 ans de profondeur

        for i in range(1, self._n_contracts + 1):
            contrat = f"CTR{i:05d}"
            compagnie = rng.choice(_COMPAGNIES)
            distributeur = rng.choice(_DISTRIBUTEURS)
            gestionnaire = rng.choice(_GESTIONNAIRES)
            courtier = rng.choice(_COURTIERS)
            produit = rng.choice(_PRODUITS)
            pays = rng.choice(_PAYS)
            devise = rng.choice(_DEVISES)

            # Référentiel : une version couvrant toute la période observée
            # (jointure par plage de dates, v1.7.0 — voir app/core/referentiel.py).
            referentiel.append(
                {
                    "contrat": contrat,
                    "date_debut": "01/01/2023",
                    "date_fin": "31/12/2026",
                }
            )

            # Anomalie volontaire : ~1 contrat sur 15 sans référentiel du tout.
            has_referentiel = (i % 15 != 0)
            if not has_referentiel:
                referentiel = [r for r in referentiel if r["contrat"] != contrat]

            active_months = rng.sample(months, k=rng.randint(3, 10))
            reference_seq = 1

            for (y, m) in active_months:
                date_debut = date(y, m, 1)
                date_fin = date(y, m, 28)
                regularisation = rng.choice(_REGULARISATIONS)

                adhesions = rng.randint(1, 40)
                prime_ht_unitaire = Decimal(rng.choice([12, 15, 18, 22, 25, 30]))
                primes_ht = (prime_ht_unitaire * adhesions).quantize(Decimal("0.01"))
                taux_tva = Decimal("0.20")
                taxes = (primes_ht * taux_tva).quantize(Decimal("0.01"))
                primes_ttc = (primes_ht + taxes).quantize(Decimal("0.01"))
                part_assureur = (primes_ht * Decimal("0.55")).quantize(Decimal("0.01"))
                commission_ici = (primes_ht * Decimal("0.10")).quantize(Decimal("0.01"))
                commission_distributeur = (primes_ht * Decimal("0.15")).quantize(Decimal("0.01"))
                frais_gestion = (primes_ht * Decimal("0.08")).quantize(Decimal("0.01"))
                autre1 = (primes_ht * Decimal("0.01")).quantize(Decimal("0.01")) if rng.random() < 0.5 else None
                autre2 = None
                autre3 = None
                net_compagnie = (primes_ht - part_assureur).quantize(Decimal("0.01"))
                remboursement = (part_assureur * Decimal("0.02")).quantize(Decimal("0.01"))
                bordereau = primes_ttc

                part1.append(
                    {
                        "identifiant_contrat": contrat,
                        "date_debut_periode_souscription": _fmt(date_debut),
                        "date_fin_periode_souscription": _fmt(date_fin),
                        "regularisation": regularisation,
                        "pays": pays,
                        "libelle_distributeur": distributeur,
                        "statut": "Validé",
                        "libelle_produit": produit,
                        "gestionnaire_1": gestionnaire,
                        "gestionnaire_2": "",
                        "courtier_1": courtier,
                        "courtier_2": "",
                        "compagnie": compagnie,
                        "flux_fi": "FI1",
                        "date_creation_quittance": _fmt(date_debut),
                        "code_devise_quittance": devise,
                        "nombre_total_adhesions": adhesions,
                        "montant_total_ht": str(primes_ht),
                        "montant_total_taxes": str(taxes),
                        "montant_total_taxes_1": str(taxes),
                        "montant_total_taxes_2": "0.00",
                        "montant_total_ttc": str(primes_ttc),
                        "remboursement_total_compagnie": str(remboursement),
                        "montant_total_commission_distributeur": str(commission_distributeur),
                        "montant_total_frais_gestion": str(frais_gestion),
                        "montant_total_autres_commissions_1": str(autre1) if autre1 else None,
                        "montant_total_autres_commissions_2": str(autre2) if autre2 else None,
                        "montant_total_autres_commissions_3": str(autre3) if autre3 else None,
                        "montant_total_net_compagnie": str(net_compagnie),
                        "montant_total_commission_ici": str(commission_ici),
                        "montant_total_prime_assureur": str(part_assureur),
                        "montant_total_bordereau": str(bordereau),
                    }
                )

                part2.append(
                    {
                        "identifiant_contrat": contrat,
                        "date_debut_periode_souscription": _fmt(date_debut),
                        "reference": f"REF-{contrat}-{reference_seq:03d}",
                        "code_critere_tarifaire_1": rng.choice(_PRICE_RANGES),
                        "nombre_resiliations": rng.randint(0, 3),
                    }
                )
                reference_seq += 1

                # Sinistres (v1.8.0) : lignes BRUTES, un sinistre par ligne, comme
                # la vraie source SRC_Sinistre_Transformer_Contenu — environ 1 mois
                # sur 2 génère entre 0 et 6 sinistres individuels pour ce contrat.
                if rng.random() < 0.5:
                    total = rng.randint(0, 6)
                    for _ in range(total):
                        jour = rng.randint(1, 28)
                        date_sinistre = date(y, m, jour)
                        statut = rng.choice(_STATUTS_SINISTRE)
                        montant = Decimal(rng.choice([80, 120, 200, 350]))
                        sinistres.append(
                            {
                                "Numero_Police": contrat,
                                "Date_Souscription_Adhesion": _fmt(date_sinistre),
                                "Statut_Technique_Sinistre": statut,
                                "Montant_Total_Reglement": str(montant),
                            }
                        )

        # Anomalie volontaire : un sinistre orphelin (police qui ne correspond à aucun contrat réel).
        sinistres.append(
            {
                "Numero_Police": "CTR_INCONNU",
                "Date_Souscription_Adhesion": "31/12/2099",
                "Statut_Technique_Sinistre": "Terminé - accepté",
                "Montant_Total_Reglement": "150.00",
            }
        )

        # Anomalie volontaire : deux lignes Part1 distinctes pour la même clé
        # contrat+période, avec des montants différents (cf. hypothèse
        # documentée dans app/core/aggregation.py — non sommées automatiquement).
        if part1:
            dup_source = dict(part1[0])
            dup_source["montant_total_ttc"] = str(
                (Decimal(dup_source["montant_total_ttc"]) * 2).quantize(Decimal("0.01"))
            )
            part1.append(dup_source)

        self._part1 = part1
        self._referentiel = referentiel
        self._part2 = part2
        self._sinistres = sinistres

    def fetch_part1_rows(self) -> list[dict[str, Any]]:
        self._ensure_generated()
        return list(self._part1 or [])

    def fetch_referentiel_rows(self) -> list[dict[str, Any]]:
        self._ensure_generated()
        return list(self._referentiel or [])

    def fetch_part2_rows(self) -> list[dict[str, Any]]:
        self._ensure_generated()
        return list(self._part2 or [])

    def fetch_sinistres_rows(self) -> list[dict[str, Any]]:
        self._ensure_generated()
        return list(self._sinistres or [])
