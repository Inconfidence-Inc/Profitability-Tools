"""Tests pour SqlServerConfig — authentification SQL Server vs authentification
Windows ("connexion locale" / Trusted_Connection, ajoutée en v1.3.0), et pour
la gestion multi-environnement (Recette/Production, ajoutée en v1.6.0 ; le
profil "Local" qui existait jusqu'en v1.10.3 a été retiré en v1.10.4, à la
demande explicite de l'utilisateur, qui souhaite que toute connexion passe
directement par le serveur)."""
from __future__ import annotations

from app.config.settings import (
    AppSettings, SqlServerConfig, _get_bool, _get_int, get_sql_config,
)


def _base_kwargs(**overrides):
    kwargs = dict(
        server="20.199.102.16",
        database_ici_bi="ICI_BI",
        database_tech_bi="TECH_BI",
        username="",
        password="",
        driver="ODBC Driver 18 for SQL Server",
        encrypt=True,
        trust_server_certificate=False,
        timeout_seconds=30,
    )
    kwargs.update(overrides)
    return kwargs


def test_sql_auth_requires_username_and_password():
    cfg = SqlServerConfig(**_base_kwargs())
    assert cfg.is_configured() is False

    cfg = SqlServerConfig(**_base_kwargs(username="VerifBdx", password="secret"))
    assert cfg.is_configured() is True


def test_trusted_connection_requires_only_server():
    cfg = SqlServerConfig(**_base_kwargs(trusted_connection=True))
    assert cfg.is_configured() is True

    cfg = SqlServerConfig(**_base_kwargs(trusted_connection=True, server=""))
    assert cfg.is_configured() is False


def test_sql_auth_connection_string_includes_uid_pwd():
    cfg = SqlServerConfig(**_base_kwargs(username="VerifBdx", password="secret"))
    conn_str = cfg.odbc_connection_string()
    assert "UID=VerifBdx" in conn_str
    assert "PWD=secret" in conn_str
    assert "Trusted_Connection" not in conn_str


def test_trusted_connection_string_omits_uid_pwd():
    cfg = SqlServerConfig(**_base_kwargs(trusted_connection=True))
    conn_str = cfg.odbc_connection_string()
    assert "Trusted_Connection=yes" in conn_str
    assert "UID=" not in conn_str
    assert "PWD=" not in conn_str


def test_trusted_connection_default_is_false():
    """Rétrocompatibilité : un .env existant sans PROFITABILITY_DB_..._TRUSTED_CONNECTION
    doit continuer à se comporter comme avant (authentification SQL Server)."""
    cfg = SqlServerConfig(**_base_kwargs(username="VerifBdx", password="secret"))
    assert cfg.trusted_connection is False


def test_environment_defaults_to_recette():
    cfg = SqlServerConfig(**_base_kwargs())
    assert cfg.environment == "RECETTE"


# --- _get_bool / _get_int : parsing pur, tolérant aux valeurs absentes/invalides ---
# (bug corrigé en v1.5.0 pour _get_int : avant, SqlServerConfig.from_env()
# appelait int(...) directement sur le délai de connexion, ce qui plantait
# tout le démarrage de l'application pour une simple valeur non numérique.)

def test_get_int_returns_default_when_value_is_none():
    assert _get_int(None, 30) == 30


def test_get_int_parses_valid_value():
    assert _get_int("45", 30) == 45


def test_get_int_falls_back_to_default_on_malformed_value():
    assert _get_int("trente", 30) == 30


def test_get_int_falls_back_to_default_on_blank_value():
    assert _get_int("   ", 30) == 30


def test_get_bool_recognizes_common_truthy_strings():
    for val in ("1", "true", "TRUE", "yes", "on"):
        assert _get_bool(val, False) is True


def test_get_bool_returns_default_when_value_is_none():
    assert _get_bool(None, True) is True
    assert _get_bool(None, False) is False


# --- Multi-environnement (v1.6.0 ; réduit à deux profils en v1.10.4) --
# Deux profils de connexion indépendants (Recette/Production), chacun
# mémorisé sous ses propres clés .env préfixées, pour que basculer
# d'un environnement à l'autre ne touche jamais à l'autre.

def test_from_env_reads_environment_specific_prefixed_keys(monkeypatch):
    monkeypatch.delenv("PROFITABILITY_DB_SERVER", raising=False)
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_SERVER", "srv-recette")
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_USER", "recette_user")
    monkeypatch.setenv("PROFITABILITY_DB_PRODUCTION_SERVER", "srv-prod")

    cfg_recette = SqlServerConfig.from_env("RECETTE")
    assert cfg_recette.server == "srv-recette"
    assert cfg_recette.username == "recette_user"
    assert cfg_recette.environment == "RECETTE"

    cfg_prod = SqlServerConfig.from_env("PRODUCTION")
    assert cfg_prod.server == "srv-prod"
    assert cfg_prod.username == ""  # jamais celui de Recette


def test_switching_environment_never_leaks_values_between_profiles(monkeypatch):
    """Reproduit la demande explicite : les données enregistrées pour un
    environnement doivent rester stockées telles quelles, inchangées par ce
    qui est fait sur l'autre environnement."""
    monkeypatch.delenv("PROFITABILITY_DB_SERVER", raising=False)
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_SERVER", "recette-server")
    monkeypatch.setenv("PROFITABILITY_DB_PRODUCTION_SERVER", "prod-server")

    assert SqlServerConfig.from_env("RECETTE").server == "recette-server"
    assert SqlServerConfig.from_env("PRODUCTION").server == "prod-server"
    # Relire Recette une seconde fois (après avoir lu Production) donne
    # toujours la même valeur Recette — rien n'a été écrasé.
    assert SqlServerConfig.from_env("RECETTE").server == "recette-server"


def test_from_env_falls_back_to_legacy_unprefixed_keys_for_default_environment_only(monkeypatch):
    """Migration automatique v1.5.0 -> v1.6.0 (toujours valable après le
    retrait du profil "Local" en v1.10.4) : un .env créé avant la v1.6.0
    (un seul profil, sans préfixe d'environnement) doit continuer à
    fonctionner sans perte, chargé comme le profil par défaut
    (DEFAULT_ENVIRONMENT, "Recette" depuis la v1.10.4) — jamais comme
    Production (on ne veut jamais pré-remplir ce dernier avec d'anciens
    identifiants par erreur)."""
    monkeypatch.delenv("PROFITABILITY_DB_RECETTE_SERVER", raising=False)
    monkeypatch.setenv("PROFITABILITY_DB_SERVER", "legacy-server")
    monkeypatch.setenv("PROFITABILITY_DB_USER", "legacy_user")

    cfg = SqlServerConfig.from_env("RECETTE")
    assert cfg.server == "legacy-server"
    assert cfg.username == "legacy_user"

    cfg_prod = SqlServerConfig.from_env("PRODUCTION")
    assert cfg_prod.server == ""


def test_from_env_prefers_prefixed_key_over_legacy_key(monkeypatch):
    monkeypatch.setenv("PROFITABILITY_DB_SERVER", "legacy-server")
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_SERVER", "new-recette-server")

    assert SqlServerConfig.from_env("RECETTE").server == "new-recette-server"


def test_from_env_normalizes_unknown_environment_to_default(monkeypatch):
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_SERVER", "recette-server")
    cfg = SqlServerConfig.from_env("NOT_A_REAL_ENV")
    assert cfg.environment == "RECETTE"
    assert cfg.server == "recette-server"


def test_from_env_normalizes_removed_local_environment_to_default(monkeypatch):
    """Un ancien .env antérieur au retrait du profil "Local" (v1.10.4) qui
    contiendrait encore PROFITABILITY_ACTIVE_ENV=LOCAL ou des clés
    PROFITABILITY_DB_LOCAL_* doit continuer à démarrer normalement : "LOCAL"
    n'étant plus une valeur reconnue, on retombe sur l'environnement par
    défaut (Recette) plutôt que de planter."""
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_SERVER", "recette-server")
    cfg = SqlServerConfig.from_env("LOCAL")
    assert cfg.environment == "RECETTE"
    assert cfg.server == "recette-server"


def test_sql_config_from_env_does_not_crash_on_malformed_timeout(monkeypatch):
    """Test d'intégration : SqlServerConfig.from_env() (utilisé au démarrage
    de l'application, voir app/main.py) ne doit jamais lever d'exception à
    cause d'un fichier .env mal formé, quel que soit l'environnement."""
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_TIMEOUT", "not-a-number")
    cfg = SqlServerConfig.from_env("RECETTE")
    assert cfg.timeout_seconds == 30


def test_env_keys_are_prefixed_and_round_trip(monkeypatch):
    cfg = SqlServerConfig(**_base_kwargs(
        username="VerifBdx", password="secret", environment="PRODUCTION",
    ))
    keys = cfg.env_keys()
    assert keys["PROFITABILITY_DB_PRODUCTION_SERVER"] == "20.199.102.16"
    assert keys["PROFITABILITY_DB_PRODUCTION_USER"] == "VerifBdx"
    assert keys["PROFITABILITY_DB_PRODUCTION_TIMEOUT"] == "30"
    assert all(k.startswith("PROFITABILITY_DB_PRODUCTION_") for k in keys)

    for key, value in keys.items():
        monkeypatch.setenv(key, value)
    reloaded = SqlServerConfig.from_env("PRODUCTION")
    assert reloaded.server == cfg.server
    assert reloaded.username == cfg.username


def test_app_settings_active_environment_defaults_to_recette(monkeypatch):
    monkeypatch.delenv("PROFITABILITY_ACTIVE_ENV", raising=False)
    assert AppSettings.from_env().active_environment == "RECETTE"


def test_app_settings_active_environment_reads_valid_value(monkeypatch):
    monkeypatch.setenv("PROFITABILITY_ACTIVE_ENV", "PRODUCTION")
    assert AppSettings.from_env().active_environment == "PRODUCTION"


def test_app_settings_active_environment_rejects_unknown_value(monkeypatch):
    monkeypatch.setenv("PROFITABILITY_ACTIVE_ENV", "STAGING")
    assert AppSettings.from_env().active_environment == "RECETTE"


def test_app_settings_active_environment_normalizes_removed_local_value(monkeypatch):
    """Non-régression v1.10.4 : un ancien .env avec
    PROFITABILITY_ACTIVE_ENV=LOCAL (valeur retirée) doit démarrer
    normalement sur l'environnement par défaut plutôt que de planter."""
    monkeypatch.setenv("PROFITABILITY_ACTIVE_ENV", "LOCAL")
    assert AppSettings.from_env().active_environment == "RECETTE"


def test_get_sql_config_uses_active_environment_when_omitted(monkeypatch):
    monkeypatch.setenv("PROFITABILITY_ACTIVE_ENV", "RECETTE")
    monkeypatch.setenv("PROFITABILITY_DB_RECETTE_SERVER", "srv-recette")

    cfg = get_sql_config()
    assert cfg.environment == "RECETTE"
    assert cfg.server == "srv-recette"
