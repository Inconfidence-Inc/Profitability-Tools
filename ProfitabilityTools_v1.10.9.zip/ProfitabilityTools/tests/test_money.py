from decimal import Decimal

from app.core.money import safe_div, to_decimal


def test_to_decimal_none_is_zero():
    assert to_decimal(None) == Decimal("0")


def test_to_decimal_empty_string_is_zero():
    assert to_decimal("") == Decimal("0")
    assert to_decimal("   ") == Decimal("0")


def test_to_decimal_comma_decimal():
    assert to_decimal("1234,56") == Decimal("1234.56")


def test_to_decimal_preserves_decimal():
    assert to_decimal(Decimal("10.5")) == Decimal("10.5")


def test_safe_div_zero_denominator():
    assert safe_div(Decimal("100"), Decimal("0")) == Decimal("0")


def test_safe_div_none_denominator():
    assert safe_div(Decimal("100"), None) == Decimal("0")


def test_safe_div_normal():
    assert safe_div(Decimal("10"), Decimal("4")) == Decimal("2.5")


def test_safe_div_custom_default():
    assert safe_div(Decimal("10"), Decimal("0"), default=Decimal("-1")) == Decimal("-1")
