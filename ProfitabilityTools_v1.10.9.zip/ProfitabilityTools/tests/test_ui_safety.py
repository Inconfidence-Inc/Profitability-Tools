"""Tests pour app.ui.safety (v1.8.2) : filet de sécurité LOCAL à chaque
page, qui empêche une exception de rendu de remonter jusqu'à la boîte de
dialogue globale (bloquante, répétée à chaque signal si le problème est
déterministe — voir app/main.py::_install_global_excepthook).

Couvre à la fois les fonctions pures (guarded_call/guarded_refresh) et,
pour chaque page réelle, qu'une exception injectée dans son rendu ne se
propage jamais hors de son point d'entrée (refresh()/_refresh()/...)."""
from __future__ import annotations

import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pyside6 = pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget

from app.ui.safety import guarded_call, guarded_refresh


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication(sys.argv)
    return app


# --- fonctions pures --------------------------------------------------------

def test_guarded_refresh_success_runs_body_only(qapp):
    container = QWidget()
    layout = QVBoxLayout(container)
    calls = {"body": 0, "clear": 0}

    guarded_refresh(layout, lambda: calls.__setitem__("clear", calls["clear"] + 1),
                     lambda: calls.__setitem__("body", calls["body"] + 1), "Test")

    assert calls == {"body": 1, "clear": 0}
    assert layout.count() == 0  # rien ajouté par le filet puisqu'aucune exception


def test_guarded_refresh_catches_exception_and_shows_message(qapp):
    container = QWidget()
    layout = QVBoxLayout(container)
    cleared = {"n": 0}

    def _clear():
        cleared["n"] += 1

    def _body():
        raise ValueError("boom")

    guarded_refresh(layout, _clear, _body, "Écran Test")

    assert cleared["n"] == 1
    assert layout.count() == 1
    label = layout.itemAt(0).widget()
    assert isinstance(label, QLabel)
    assert "Écran Test" in label.text()
    assert "boom" in label.text()


def test_guarded_refresh_never_raises_even_if_clear_itself_raises(qapp):
    container = QWidget()
    layout = QVBoxLayout(container)

    def _broken_clear():
        raise RuntimeError("clear is broken too")

    def _body():
        raise ValueError("boom")

    guarded_refresh(layout, _broken_clear, _body, "Test")  # ne doit lever aucune exception


def test_guarded_call_success_runs_body_only():
    calls = {"body": 0, "on_error": 0}
    guarded_call(lambda: calls.__setitem__("body", 1), "Test")
    assert calls["body"] == 1


def test_guarded_call_catches_exception_and_invokes_on_error():
    received = {}

    def _body():
        raise KeyError("missing")

    def _on_error(exc):
        received["exc"] = exc

    guarded_call(_body, "Test", _on_error)
    assert isinstance(received["exc"], KeyError)


def test_guarded_call_without_on_error_does_not_raise():
    guarded_call(lambda: (_ for _ in ()).throw(ValueError("boom")), "Test")  # juste : ne lève pas


# --- intégration par page réelle --------------------------------------------

def test_dashboard_page_survives_broken_render(qapp, monkeypatch):
    from app.ui.state import AppState
    from app.ui.pages.dashboard_page import DashboardPage
    from tests.support.demo_data_provider import DemoDataProvider

    page = DashboardPage(AppState(DemoDataProvider()))
    monkeypatch.setattr(page, "_do_refresh", lambda: (_ for _ in ()).throw(RuntimeError("kaboom")))
    page.refresh()  # ne doit pas lever
    assert page.findChildren(QLabel)  # le message d'erreur a bien été affiché


def test_claims_page_survives_broken_render(qapp, monkeypatch):
    from app.ui.state import AppState
    from app.ui.pages.claims_page import ClaimsPage
    from tests.support.demo_data_provider import DemoDataProvider

    page = ClaimsPage(AppState(DemoDataProvider()))
    monkeypatch.setattr(page, "_do_refresh", lambda: (_ for _ in ()).throw(RuntimeError("kaboom")))
    page.refresh()
    assert page.findChildren(QLabel)


def test_data_quality_page_survives_broken_render(qapp, monkeypatch):
    from app.ui.state import AppState
    from app.ui.pages.data_quality_page import DataQualityPage
    from tests.support.demo_data_provider import DemoDataProvider

    page = DataQualityPage(AppState(DemoDataProvider()))
    monkeypatch.setattr(page, "_do_refresh", lambda: (_ for _ in ()).throw(RuntimeError("kaboom")))
    page.refresh()
    assert page.findChildren(QLabel)


def test_explorer_page_survives_broken_render(qapp, monkeypatch):
    from app.ui.state import AppState
    from app.ui.pages.explorer_page import ExplorerPage
    from tests.support.demo_data_provider import DemoDataProvider

    page = ExplorerPage(AppState(DemoDataProvider()))
    monkeypatch.setattr(page, "_render_body", lambda: (_ for _ in ()).throw(RuntimeError("kaboom")))
    page._render()  # ne doit pas lever
    assert "profitabilitytools_error.log" in page._page_label.text()


def test_contracts_page_survives_broken_detail_render(qapp, monkeypatch):
    from app.ui.state import AppState
    from app.ui.pages.contracts_page import ContractsPage
    from tests.support.demo_data_provider import DemoDataProvider

    page = ContractsPage(AppState(DemoDataProvider()))
    monkeypatch.setattr(page, "_render_detail_body", lambda: (_ for _ in ()).throw(RuntimeError("kaboom")))
    page._selected_contract = "CTR00001"
    page._render_detail()  # ne doit pas lever
    assert page.findChildren(QLabel)


def test_contracts_page_survives_broken_list_render(qapp, monkeypatch):
    from app.ui.state import AppState
    from app.ui.pages.contracts_page import ContractsPage
    from tests.support.demo_data_provider import DemoDataProvider

    page = ContractsPage(AppState(DemoDataProvider()))
    monkeypatch.setattr(page, "_refresh_list_body", lambda: (_ for _ in ()).throw(RuntimeError("kaboom")))
    page._refresh_list()  # ne doit pas lever
