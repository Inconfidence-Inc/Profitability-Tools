"""Tests pour app.ui.icons — logo de l'application (demande utilisateur,
v1.5.0) : icône fenêtre/barre des tâches + petit logo dans l'en-tête."""
from __future__ import annotations

import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pyside6 = pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication

from app.ui.icons import _assets_dir, app_icon, logo_pixmap


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication(sys.argv)
    return app


def test_assets_dir_contains_logo_files():
    assets = _assets_dir()
    assert (assets / "logo.ico").exists()
    assert (assets / "logo.png").exists()


def test_app_icon_is_not_null(qapp):
    assert not app_icon().isNull()


def test_logo_pixmap_is_not_null_and_respects_requested_size(qapp):
    pix = logo_pixmap(28)
    assert not pix.isNull()
    assert pix.width() <= 28 and pix.height() <= 28


def test_logo_pixmap_missing_file_returns_null_pixmap_without_crashing(qapp, monkeypatch):
    """Un logo manquant (ex. build incomplet) ne doit jamais faire planter
    l'application — juste un pixmap vide, silencieusement."""
    import app.ui.icons as icons_module
    from pathlib import Path

    monkeypatch.setattr(icons_module, "_assets_dir", lambda: Path("/nonexistent-assets-dir"))
    assert icons_module.logo_pixmap(28).isNull()
    assert icons_module.app_icon().isNull()
