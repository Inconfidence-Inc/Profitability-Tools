"""Tests pour l'écran Settings (onglet Source de données).

Historique du correctif v1.1.3 (toujours vérifié ci-dessous, adapté au
multi-environnement) : « Tester la connexion » utilise les valeurs du
formulaire (via _current_form_config()), et « Appliquer et recharger les
données » doit faire de même plutôt que ne relire que le fichier .env —
sinon un utilisateur qui remplit le formulaire, teste avec succès, puis
clique directement sur « Appliquer » sans passer par « Enregistrer la
configuration » se verrait refuser l'application avec un message
« non configurée » trompeur.

v1.6.0 (demande explicite de l'utilisateur) : le sélecteur DEMO/SQL_SERVER
est remplacé par un sélecteur d'environnement (Recette/Production — le
profil "Local" qui existait jusqu'en v1.10.3 a été retiré en v1.10.4,
toujours à la demande explicite de l'utilisateur, qui souhaite que toute
connexion passe directement par le serveur).
Chaque environnement a sa propre configuration, enregistrée séparément dans
.env sous des clés préfixées (SqlServerConfig.env_keys()) — basculer d'un
environnement à l'autre ne doit jamais écraser les réglages de l'autre,
et doit recharger dans le formulaire les valeurs déjà enregistrées
pour l'environnement nouvellement sélectionné.
"""
from __future__ import annotations

import os
import sys
import types

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pyside6 = pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication

from tests.support.demo_data_provider import DemoDataProvider
from app.ui.state import AppState


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication(sys.argv)
    return app


@pytest.fixture(autouse=True)
def no_blocking_dialogs(monkeypatch):
    """QMessageBox.warning()/critical() sont des appels bloquants (boîte de
    dialogue modale) — corrects en usage réel, mais ils figeraient les tests
    en environnement headless. On les neutralise ici (comportement déjà
    vérifié manuellement en amont : voir app/main.py)."""
    from PySide6.QtWidgets import QMessageBox

    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "critical", lambda *a, **k: None)


@pytest.fixture
def fake_pyodbc(monkeypatch):
    """pyodbc factice : la connexion réussit toujours instantanément, sans
    aucun accès réseau réel — reproduit le cas « Connexion réussie » des
    captures d'écran fournies par l'utilisateur."""

    class _FakeConn:
        def close(self):
            pass

    fake_module = types.ModuleType("pyodbc")
    fake_module.connect = lambda *a, **k: _FakeConn()
    monkeypatch.setitem(sys.modules, "pyodbc", fake_module)
    return fake_module


@pytest.fixture
def isolated_env_save(monkeypatch, tmp_path):
    """Redirige apply_env_updates() (appelé par _save_db_config()/
    _apply_environment()) vers un fichier .env temporaire, pour ne jamais
    toucher le vrai fichier .env du projet pendant les tests.

    Les valeurs sont tout de même répercutées dans os.environ (nécessaire :
    get_sql_config()/SqlServerConfig.from_env() les lisent depuis là, et
    c'est ce qui permet à _on_environment_selected() de recharger le bon
    profil dans le formulaire) — mais via monkeypatch.setenv() plutôt que
    l'affectation directe faite par le vrai apply_env_updates(), pour que
    pytest annule automatiquement ces variables en fin de test et ne
    pollue jamais les tests suivants (ex. tests/test_sql_config.py)."""
    from app.config import env_writer as env_writer_module
    from app.ui.pages import settings_page as settings_page_module

    tmp_env_path = tmp_path / ".env"

    def _fake_apply(updates):
        env_writer_module.write_env_values(updates, env_path=tmp_env_path)
        for key, value in updates.items():
            monkeypatch.setenv(key, value)

    monkeypatch.setattr(settings_page_module, "apply_env_updates", _fake_apply)
    return tmp_env_path


def _select_environment(page, label: str) -> None:
    page._env_combo.setCurrentIndex(page._env_combo.findText(label))


def test_apply_environment_uses_form_values_without_requiring_save_first(
    qapp, fake_pyodbc, isolated_env_save
):
    """Reproduit exactement le scénario historique (v1.1.3) : remplir le
    formulaire, tester la connexion (succès), puis cliquer directement sur
    « Appliquer et recharger les données » sans avoir cliqué sur
    « Enregistrer la configuration » — ceci ne doit jamais échouer avec un
    message « non configurée » malgré le test réussi juste avant."""
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    page._db_server.setText("20.199.102.16")
    page._db_user.setText("VerifBdx")
    page._db_password.setText("secretpwd")

    page._test_connection()
    assert "réussie" in page._db_status.text().lower()

    page._apply_environment()

    assert state.provider.mode_name == "SQL_SERVER"
    assert isolated_env_save.exists()
    saved = isolated_env_save.read_text(encoding="utf-8")
    assert "PROFITABILITY_DB_RECETTE_SERVER=20.199.102.16" in saved
    assert "PROFITABILITY_DB_RECETTE_USER=VerifBdx" in saved
    assert "PROFITABILITY_ACTIVE_ENV=RECETTE" in saved


def test_apply_environment_still_warns_when_form_is_empty(qapp, isolated_env_save):
    """Le message « non configurée » doit rester déclenché quand le
    formulaire est réellement vide (pas seulement quand .env est vide)."""
    from app.ui.pages.settings_page import SettingsPage

    provider = DemoDataProvider()
    state = AppState(provider)
    page = SettingsPage(state)

    page._db_server.setText("")
    page._db_user.setText("")
    page._db_password.setText("")

    page._apply_environment()

    # Aucun crash, et le provider précédent reste actif (l'application ne
    # doit jamais basculer sur un provider mal configuré).
    assert state.provider is provider


def test_trusted_connection_checkbox_disables_user_and_password_fields(qapp):
    """v1.3.0 : cocher « Authentification Windows » grise (mais ne vide pas)
    les champs Utilisateur/Mot de passe, puisqu'ils ne sont alors ni requis
    ni utilisés — voir SqlServerConfig.trusted_connection."""
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    page._db_trusted.setChecked(False)
    assert page._db_user.isEnabled() is True
    assert page._db_password.isEnabled() is True

    page._db_trusted.setChecked(True)
    assert page._db_user.isEnabled() is False
    assert page._db_password.isEnabled() is False

    page._db_trusted.setChecked(False)
    assert page._db_user.isEnabled() is True
    assert page._db_password.isEnabled() is True


def test_apply_environment_with_trusted_connection_and_no_credentials(
    qapp, fake_pyodbc, isolated_env_save
):
    """Scénario demandé par l'utilisateur : authentification Windows
    ("connexion locale"), serveur seul renseigné, aucun utilisateur/mot de
    passe — l'application doit pouvoir basculer sur SQL Server."""
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    page._db_server.setText("20.199.102.16")
    page._db_trusted.setChecked(True)

    page._apply_environment()

    assert state.provider.mode_name == "SQL_SERVER"
    saved = isolated_env_save.read_text(encoding="utf-8")
    assert "PROFITABILITY_DB_RECETTE_TRUSTED_CONNECTION=true" in saved


# --- Multi-environnement (v1.6.0 ; réduit à deux profils en v1.10.4) --

def test_environment_combo_has_two_options_recette_production(qapp):
    """Depuis la v1.10.4 (demande explicite de l'utilisateur), le profil
    "Local" a été retiré : seuls Recette et Production restent
    sélectionnables, pour que toute connexion passe directement par le
    serveur."""
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    labels = [page._env_combo.itemText(i) for i in range(page._env_combo.count())]
    assert labels == ["Recette", "Production"]


def test_switching_environment_reloads_form_with_that_environments_saved_values(
    qapp, fake_pyodbc, isolated_env_save
):
    """Cœur de la demande : enregistrer une configuration pour Recette,
    basculer sur Production, puis re-sélectionner Recette doit réafficher
    exactement ce qui a été enregistré pour Recette — jamais les valeurs
    laissées dans le formulaire par l'autre environnement entre-temps."""
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    _select_environment(page, "Recette")
    page._db_server.setText("srv-recette.ici-assurance.local")
    page._db_user.setText("recette_user")
    page._db_password.setText("recette_pwd")
    page._save_db_config()

    _select_environment(page, "Production")
    page._db_server.setText("srv-production.ici-assurance.local")
    page._db_trusted.setChecked(True)
    page._save_db_config()

    # Le formulaire reflète maintenant Production, pas Recette.
    assert page._db_server.text() == "srv-production.ici-assurance.local"

    _select_environment(page, "Recette")
    assert page._db_server.text() == "srv-recette.ici-assurance.local"
    assert page._db_user.text() == "recette_user"
    assert page._db_password.text() == "recette_pwd"


def test_saving_one_environment_never_overwrites_another(qapp, isolated_env_save):
    from app.config.settings import SqlServerConfig
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    _select_environment(page, "Recette")
    page._db_server.setText("recette-server")
    page._save_db_config()

    _select_environment(page, "Production")
    page._db_server.setText("prod-server")
    page._db_user.setText("prod_user")
    page._db_password.setText("prod_pwd")
    page._save_db_config()

    assert SqlServerConfig.from_env("RECETTE").server == "recette-server"
    assert SqlServerConfig.from_env("PRODUCTION").server == "prod-server"


def test_apply_environment_persists_active_environment_choice(
    qapp, fake_pyodbc, isolated_env_save
):
    from app.ui.pages.settings_page import SettingsPage

    state = AppState(DemoDataProvider())
    page = SettingsPage(state)

    _select_environment(page, "Production")
    page._db_server.setText("prod-server")
    page._db_user.setText("prod_user")
    page._db_password.setText("prod_pwd")

    page._apply_environment()

    saved = isolated_env_save.read_text(encoding="utf-8")
    assert "PROFITABILITY_ACTIVE_ENV=PRODUCTION" in saved
    assert state.provider.environment == "PRODUCTION"
