"""Tests pour le rafraîchissement paresseux de DataQualityPage (v1.8.0).

Contexte : cette page est la seule à parcourir la liste BRUTE des
sinistres (state.sinistres_rows), potentiellement ~1,3M lignes depuis la
vraie table SRC_Sinistre_Transformer_Contenu (voir
app/core/data_quality.py). Comme toutes les pages sont construites
d'avance dans le QStackedWidget et réagissent toutes aux mêmes signaux
(datasetChanged/filtersChanged), ce calcul coûteux se relançait
auparavant à chaque rechargement ou changement de filtre, même quand
l'utilisateur regardait une autre page — un facteur aggravant du
plantage observé par l'utilisateur juste après « Appliquer et recharger
les données » sur un vrai jeu de sinistres volumineux.

Ces tests vérifient que le recalcul (build_data_quality_report, via
refresh()) est bien différé tant que la page n'est pas visible, et se
déclenche dès qu'elle le redevient — sans changer le résultat produit
(mêmes données, même affichage, uniquement le MOMENT du calcul change)."""
from __future__ import annotations

import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pyside6 = pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication

from app.ui.state import AppState
from tests.support.demo_data_provider import DemoDataProvider


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication(sys.argv)
    return app


def _make_page(qapp, monkeypatch):
    import app.ui.pages.data_quality_page as dqp_module

    calls = {"n": 0}
    real_build = dqp_module.build_data_quality_report

    def _counting_build(*args, **kwargs):
        calls["n"] += 1
        return real_build(*args, **kwargs)

    monkeypatch.setattr(dqp_module, "build_data_quality_report", _counting_build)
    state = AppState(DemoDataProvider())
    page = dqp_module.DataQualityPage(state)
    return page, state, calls


def test_initial_construction_computes_once(qapp, monkeypatch):
    page, state, calls = _make_page(qapp, monkeypatch)
    assert calls["n"] == 1  # refresh() initial dans __init__, comportement inchangé


def test_dataset_reload_while_hidden_does_not_recompute(qapp, monkeypatch):
    page, state, calls = _make_page(qapp, monkeypatch)
    assert page.isVisible() is False  # jamais affichée dans un QStackedWidget ici
    state.reload()
    assert calls["n"] == 1  # toujours périmée (_dirty=True), mais pas recalculée
    assert page._dirty is True


def test_becoming_visible_triggers_deferred_recompute(qapp, monkeypatch):
    page, state, calls = _make_page(qapp, monkeypatch)
    state.reload()
    assert calls["n"] == 1

    page.show()
    qapp.processEvents()

    assert page.isVisible() is True
    assert calls["n"] == 2  # le recalcul différé a bien eu lieu à l'affichage
    assert page._dirty is False
    page.hide()


def test_reload_while_already_visible_recomputes_immediately(qapp, monkeypatch):
    page, state, calls = _make_page(qapp, monkeypatch)
    page.show()
    qapp.processEvents()
    assert calls["n"] == 1  # construction seule : rien n'a changé depuis, pas de recalcul au show()

    state.reload()
    assert calls["n"] == 2  # page déjà visible -> recalcul immédiat, pas différé
    assert page._dirty is False
    page.hide()
