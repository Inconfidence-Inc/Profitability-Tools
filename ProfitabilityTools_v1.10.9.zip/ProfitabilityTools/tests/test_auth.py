"""Tests pour l'authentification ProfitabilityTools (v1.10.0) : écran de
connexion, gestion des utilisateurs, et repli local SQLite tant que la base
centrale OUTILS n'est pas configurée sur le poste (voir app/auth/).

Chaque test isole son propre dossier de données (XDG_CONFIG_HOME pointé sur
tmp_path) : auth_partage retient la connexion active en mémoire du
processus (voir auth_partage/database.py), et un test qui réutiliserait le
dossier d'un autre verrait ses comptes."""
from __future__ import annotations

import sys

import pytest

pyside6 = pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QDialog, QMessageBox  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication(sys.argv)
    return app


@pytest.fixture(autouse=True)
def no_blocking_dialogs(monkeypatch):
    """Comme pour les autres pages (voir test_settings_page.py) : les
    boîtes de dialogue modales de confirmation/erreur bloqueraient les
    tests en environnement headless."""
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "critical", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(
        QMessageBox, "question",
        lambda *a, **k: QMessageBox.StandardButton.Yes,
    )


@pytest.fixture(autouse=True)
def isolated_auth_data_dir(tmp_path, monkeypatch):
    """Dossier de données local propre à ce test (clé de chiffrement,
    profil de connexion, base SQLite de repli) — voir
    auth_partage/chemins.py::get_app_data_dir()."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    yield tmp_path


@pytest.fixture
def auth_service(qapp):
    from app.auth.setup import (
        BOOTSTRAP_LOGIN, BOOTSTRAP_PASSWORD, ensure_auth_backend_ready,
    )

    ok, message = ensure_auth_backend_ready()
    assert ok, message
    from auth_partage.service import AuthService

    return AuthService()


# --------------------------------------------------------------------- #
# Amorçage du repli local
# --------------------------------------------------------------------- #
def test_bootstrap_creates_local_sqlite_and_default_admin(qapp, tmp_path):
    from app.auth.setup import (
        BOOTSTRAP_LOGIN, BOOTSTRAP_PASSWORD, ensure_auth_backend_ready,
        local_database_path,
    )

    ok, message = ensure_auth_backend_ready()
    assert ok
    assert "repli local a été créé" in message
    import os
    assert os.path.exists(local_database_path())

    from auth_partage.service import AuthService

    user = AuthService().authenticate(BOOTSTRAP_LOGIN, BOOTSTRAP_PASSWORD)
    assert user is not None
    assert user.role == "Administrateur"
    # Le changement de mot de passe est imposé dès la création du compte
    # amorcé automatiquement (voir service.create_user, non modifiable par
    # l'appelant) : la fenêtre d'exposition du mot de passe documenté est
    # limitée à la toute première connexion.
    assert user.doit_changer_mdp is True


def test_bootstrap_is_idempotent(qapp):
    from app.auth.setup import ensure_auth_backend_ready
    from auth_partage.service import AuthService

    ok1, _ = ensure_auth_backend_ready()
    assert ok1
    nb_comptes_avant = len(AuthService().list_users("PROFITABILITYTOOLS"))

    ok2, message2 = ensure_auth_backend_ready()
    assert ok2
    assert "déjà configuré" in message2
    assert len(AuthService().list_users("PROFITABILITYTOOLS")) == nb_comptes_avant


# --------------------------------------------------------------------- #
# AuthService.authenticate — les trois motifs de refus
# --------------------------------------------------------------------- #
def test_authenticate_wrong_password(auth_service):
    from app.auth.setup import BOOTSTRAP_LOGIN
    from auth_partage.service import REFUS_IDENTIFIANTS

    user = auth_service.authenticate(BOOTSTRAP_LOGIN, "mauvais-mot-de-passe")
    assert user is None
    assert auth_service.dernier_motif_refus == REFUS_IDENTIFIANTS


def test_authenticate_disabled_account(auth_service):
    from app.auth.setup import ROLE_UTILISATEUR
    from auth_partage.service import REFUS_DESACTIVE

    created, message = auth_service.create_user(
        "inactif1", "Martin", "Alice", "", ROLE_UTILISATEUR, "Passw0rd1",
        cree_par="test",
    )
    assert created, message
    comptes = {c.login: c for c in auth_service.list_users("PROFITABILITYTOOLS")}
    ok, _ = auth_service.set_active(comptes["inactif1"].id, False)
    assert ok

    user = auth_service.authenticate("inactif1", "Passw0rd1")
    assert user is None
    assert auth_service.dernier_motif_refus == REFUS_DESACTIVE


def test_authenticate_wrong_application(auth_service):
    """Un compte valide, mais habilité sur une autre application
    uniquement, doit être distingué d'un mot de passe erroné (voir
    auth_partage/service.py::authenticate)."""
    from auth_partage.service import REFUS_NON_HABILITE

    created, message = auth_service.create_user(
        "autre_appli", "Durand", "Paul", "", "Lecteur", "Passw0rd1",
        applications={"UNE_AUTRE_APPLICATION": "Lecteur"},
        cree_par="test",
    )
    assert created, message

    user = auth_service.authenticate("autre_appli", "Passw0rd1")
    assert user is None
    assert auth_service.dernier_motif_refus == REFUS_NON_HABILITE
    assert "UNE_AUTRE_APPLICATION" in auth_service.applications_du_compte


# --------------------------------------------------------------------- #
# LoginDialog — connexion réussie, changement de mot de passe imposé
# --------------------------------------------------------------------- #
def test_login_dialog_success(qapp, auth_service):
    from app.auth.setup import BOOTSTRAP_LOGIN, BOOTSTRAP_PASSWORD, ROLE_UTILISATEUR

    # Un compte sans mot de passe à changer, pour isoler ce test du
    # changement de mot de passe imposé (couvert séparément ci-dessous).
    created, _ = auth_service.create_user(
        "sansimpose", "Petit", "Eva", "", ROLE_UTILISATEUR, "Passw0rd1",
        cree_par="test",
    )
    assert created
    comptes = {c.login: c for c in auth_service.list_users("PROFITABILITYTOOLS")}
    compte = comptes["sansimpose"]
    compte.doit_changer_mdp = False
    from auth_partage.database import get_auth_session

    get_auth_session().commit()

    from auth_partage.ui.connexion import LoginDialog

    boite = LoginDialog(sous_titre="Test")
    boite.edit_login.setText("sansimpose")
    boite.edit_mdp.setText("Passw0rd1")
    boite._on_login()

    assert boite.result() == QDialog.Accepted
    assert boite.current_user is not None
    assert boite.current_user.login == "sansimpose"


def test_login_dialog_forced_password_change(qapp, auth_service, monkeypatch):
    from app.auth.setup import BOOTSTRAP_LOGIN, BOOTSTRAP_PASSWORD

    # Correctif v1.10.0 vérifié ici : auth_partage.ui.connexion importait
    # à l'origine `views.password_dialog` (module inexistant, propre à
    # Argos) — ce test échouerait avec un ModuleNotFoundError si la
    # régression revenait.
    from auth_partage.ui.mot_de_passe import ChangementMotDePasseDialog

    appels = {"construit": False}

    class _FausseBoite:
        def __init__(self, utilisateur, impose=True, parent=None):
            appels["construit"] = True
            self.utilisateur = utilisateur
            self.impose = impose

        def exec(self):
            return QDialog.Accepted

    monkeypatch.setattr(
        "auth_partage.ui.mot_de_passe.ChangementMotDePasseDialog", _FausseBoite
    )

    from auth_partage.ui.connexion import LoginDialog

    boite = LoginDialog()
    boite.edit_login.setText(BOOTSTRAP_LOGIN)
    boite.edit_mdp.setText(BOOTSTRAP_PASSWORD)
    boite._on_login()

    assert appels["construit"] is True
    assert boite.result() == QDialog.Accepted
    assert boite.current_user is not None


def test_login_dialog_wrong_password_does_not_accept(qapp, auth_service):
    from app.auth.setup import BOOTSTRAP_LOGIN
    from auth_partage.ui.connexion import LoginDialog

    boite = LoginDialog()
    boite.edit_login.setText(BOOTSTRAP_LOGIN)
    boite.edit_mdp.setText("faux-mot-de-passe")
    boite._on_login()

    assert boite.result() != QDialog.Accepted
    assert boite.current_user is None
    # Le champ mot de passe est vidé après un refus, pour ne pas laisser un
    # mot de passe erroné affiché à l'écran.
    assert boite.edit_mdp.text() == ""


# --------------------------------------------------------------------- #
# Bouton « Connexion au serveur (OUTILS)… » sur l'écran de connexion
# (v1.10.2 : avant cet ajout, un compte qui n'existait QUE dans OUTILS ne
# pouvait pas se connecter tant qu'un administrateur n'avait pas d'abord
# configuré OUTILS depuis Settings — ce qui exigeait de connaître le
# compte amorcé localement. Ce bouton permet de le faire AVANT de
# s'authentifier, symétrique de l'accès ajouté sur Settings en v1.10.1).
# --------------------------------------------------------------------- #
def test_build_login_dialog_has_server_connection_button(qapp, auth_service):
    from app.ui.dialogs.login_screen import build_login_dialog
    from PySide6.QtWidgets import QPushButton

    boite = build_login_dialog(sous_titre="Test")
    boutons = {b.text(): b for b in boite.findChildren(QPushButton)}
    assert "Connexion au serveur (OUTILS)…" in boutons
    # La connexion n'étant pas encore authentifiée à ce stade, ce bouton
    # est accessible sans compte ni rôle particulier.
    assert boutons["Connexion au serveur (OUTILS)…"].isEnabled()


def test_login_dialog_server_button_opens_connexion_outils_and_refreshes(
    qapp, auth_service, monkeypatch
):
    from app.ui.dialogs.login_screen import build_login_dialog
    from PySide6.QtWidgets import QLabel, QPushButton

    boite = build_login_dialog(sous_titre="Test")

    appels = {"construit": 0, "exec": 0}

    class _FausseBoite:
        def __init__(self, theme="light", parent=None):
            appels["construit"] += 1

        def exec(self):
            appels["exec"] += 1
            return 0

    monkeypatch.setattr(
        "app.ui.dialogs.connexion_outils_dialog.ConnexionOutilsDialog", _FausseBoite
    )

    statut_avant = next(
        w.text() for w in boite.findChildren(QLabel) if "Authentification" in w.text()
    )
    assert "Local" in statut_avant

    bouton = next(
        b for b in boite.findChildren(QPushButton)
        if b.text() == "Connexion au serveur (OUTILS)…"
    )
    bouton.click()

    assert appels["construit"] == 1
    assert appels["exec"] == 1


# --------------------------------------------------------------------- #
# UsersPage — rôle par défaut, création, bascule actif/inactif
# --------------------------------------------------------------------- #
def test_users_page_lists_bootstrap_admin(qapp, auth_service):
    from app.auth.setup import BOOTSTRAP_LOGIN
    from app.ui.pages.users_page import UsersPage

    admin = auth_service.authenticate(BOOTSTRAP_LOGIN, "ProfitAdmin1")
    page = UsersPage(current_user=admin)
    assert page._table.rowCount() == 1
    assert page._table.item(0, 0).text() == BOOTSTRAP_LOGIN


def test_users_page_new_user_default_role_is_lecteur(qapp, auth_service):
    """Non-régression du bug self-catché (v1.10.0) : UtilisateurDialog
    pré-sélectionne « Lecteur » par défaut à la création — si le nom de
    rôle non-privilégié d'app/auth/setup.py ne correspondait pas, le
    module partagé retombait silencieusement sur le rôle le PLUS
    privilégié (premier de la liste triée alphabétiquement)."""
    from app.auth.setup import BOOTSTRAP_LOGIN, ROLE_UTILISATEUR
    from auth_partage.ui.utilisateur import UtilisateurDialog

    boite = UtilisateurDialog(compte=None)
    combo_role = boite.table.cellWidget(0, 1)
    assert combo_role.currentText() == ROLE_UTILISATEUR == "Lecteur"


def test_users_page_create_and_toggle_active(qapp, auth_service):
    from app.auth.setup import BOOTSTRAP_LOGIN
    from app.ui.pages.users_page import UsersPage

    admin = auth_service.authenticate(BOOTSTRAP_LOGIN, "ProfitAdmin1")
    page = UsersPage(current_user=admin)

    created, message = auth_service.create_user(
        "nouveau1", "Leroy", "Sophie", "sophie@example.com", "Lecteur",
        "Passw0rd1", cree_par=admin.login,
    )
    assert created, message
    page.refresh()
    assert page._table.rowCount() == 2

    comptes = {c.login: c for c in auth_service.list_users("PROFITABILITYTOOLS")}
    nouveau = comptes["nouveau1"]
    assert nouveau.actif is True

    ok, _ = auth_service.set_active(nouveau.id, False)
    assert ok
    page.refresh()
    row = next(
        r for r in range(page._table.rowCount())
        if page._table.item(r, 0).text() == "nouveau1"
    )
    assert page._table.item(row, 5).text() == "Non"


# --------------------------------------------------------------------- #
# SettingsPage — section « Authentification », réservée à l'Administrateur
# (correctif v1.10.1 : ConnexionOutilsDialog était construit en v1.10.0
# mais n'était ouvert nulle part dans l'application).
# --------------------------------------------------------------------- #
def test_settings_page_auth_section_admin_only(qapp, auth_service):
    from app.auth.setup import BOOTSTRAP_LOGIN, ROLE_UTILISATEUR
    from app.ui.pages.settings_page import SettingsPage
    from app.ui.state import AppState
    from tests.support.demo_data_provider import DemoDataProvider

    created, _ = auth_service.create_user(
        "lecteur_settings", "Petit", "Eva", "", ROLE_UTILISATEUR, "Passw0rd1",
        cree_par="test",
    )
    assert created
    admin = auth_service.authenticate(BOOTSTRAP_LOGIN, "ProfitAdmin1")
    lecteur = auth_service.authenticate("lecteur_settings", "Passw0rd1")

    state = AppState(DemoDataProvider(), theme="light")

    page_admin = SettingsPage(state, current_user=admin)
    assert page_admin._is_admin_for_auth is True
    assert hasattr(page_admin, "_auth_status")
    assert "Local" in page_admin._auth_status.text()

    page_lecteur = SettingsPage(state, current_user=lecteur)
    assert page_lecteur._is_admin_for_auth is False
    assert not hasattr(page_lecteur, "_auth_status")


def test_settings_page_opens_outils_dialog_and_refreshes_status(
    qapp, auth_service, monkeypatch
):
    from app.auth.setup import BOOTSTRAP_LOGIN
    from app.ui.pages.settings_page import SettingsPage
    from app.ui.state import AppState
    from tests.support.demo_data_provider import DemoDataProvider

    admin = auth_service.authenticate(BOOTSTRAP_LOGIN, "ProfitAdmin1")
    state = AppState(DemoDataProvider(), theme="light")
    page = SettingsPage(state, current_user=admin)

    appels = {"construit": 0, "exec": 0}

    class _FausseBoite:
        def __init__(self, theme="light", parent=None):
            appels["construit"] += 1

        def exec(self):
            appels["exec"] += 1
            return 0

    monkeypatch.setattr(
        "app.ui.dialogs.connexion_outils_dialog.ConnexionOutilsDialog", _FausseBoite
    )

    page._on_open_outils_connection()

    assert appels["construit"] == 1
    assert appels["exec"] == 1
    # L'état affiché est recalculé après fermeture de la boîte, qu'elle ait
    # été annulée ou validée.
    assert page._auth_status.text() != ""


def test_last_administrator_cannot_be_deactivated(qapp, auth_service):
    """Garde-fou du module partagé (auth_partage/service.py) : on ne peut
    pas désactiver le dernier compte Administrateur actif de CETTE
    application."""
    from app.auth.setup import BOOTSTRAP_LOGIN

    comptes = {c.login: c for c in auth_service.list_users("PROFITABILITYTOOLS")}
    admin = comptes[BOOTSTRAP_LOGIN]

    ok, message = auth_service.set_active(admin.id, False)
    assert ok is False
    assert "dernier administrateur" in message.lower()
