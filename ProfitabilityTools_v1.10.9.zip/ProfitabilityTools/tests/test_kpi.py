from decimal import Decimal

from app.core.kpi import compute_kpi_summary, top_contracts_by_claims_amount, top_contracts_by_premiums
from app.core.models import ProfitabilityRow


def _row(**overrides) -> ProfitabilityRow:
    base = dict(
        identifiant_contrat_tdb="C1",
        volumes_primes_ttc=Decimal("100"),
        volumes_primes_ht=Decimal("90"),
        total_com=Decimal("9"),
        number_of_subscription=Decimal("10"),
        nombre_sinistres_total=Decimal("2"),
        montant_total_reglement=Decimal("30"),
    )
    base.update(overrides)
    return ProfitabilityRow(**base)


def test_kpi_summary_basic_totals():
    summary = compute_kpi_summary([_row(), _row(identifiant_contrat_tdb="C2")])
    assert summary.total_primes_ttc == Decimal("200")
    assert summary.nombre_adhesions == Decimal("20")
    assert summary.nombre_lignes == 2


def test_kpi_summary_division_by_zero_is_safe_on_empty_dataset():
    summary = compute_kpi_summary([])
    assert summary.claim_frequency == Decimal("0")
    assert summary.claims_over_premiums_ht == Decimal("0")
    assert summary.commission_rate == Decimal("0")
    assert summary.nombre_lignes == 0


def test_kpi_summary_division_by_zero_when_adhesions_null():
    summary = compute_kpi_summary([_row(number_of_subscription=Decimal("0"))])
    assert summary.claim_frequency == Decimal("0")  # pas de ZeroDivisionError


def test_claim_frequency_and_commission_rate_normal_case():
    summary = compute_kpi_summary([_row()])
    assert summary.claim_frequency == Decimal("2") / Decimal("10")
    assert summary.commission_rate == Decimal("9") / Decimal("90")


def test_top_contracts_by_premiums():
    rows = [_row(identifiant_contrat_tdb="A", volumes_primes_ttc=Decimal("50")),
            _row(identifiant_contrat_tdb="B", volumes_primes_ttc=Decimal("500"))]
    top = top_contracts_by_premiums(rows, limit=1)
    assert len(top) == 1
    assert top[0].identifiant_contrat_tdb == "B"


def test_top_contracts_by_claims_amount():
    rows = [_row(identifiant_contrat_tdb="A", montant_total_reglement=Decimal("10")),
            _row(identifiant_contrat_tdb="B", montant_total_reglement=Decimal("1000"))]
    top = top_contracts_by_claims_amount(rows, limit=1)
    assert top[0].identifiant_contrat_tdb == "B"
