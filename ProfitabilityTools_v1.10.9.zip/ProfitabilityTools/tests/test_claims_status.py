from app.config.status_mapping import ClaimStatusCategory, add_status_mapping, normalize_claim_status


def test_accept_variants():
    assert normalize_claim_status("Terminé accepté") == ClaimStatusCategory.ACCEPT
    assert normalize_claim_status("Terminé - accepté") == ClaimStatusCategory.ACCEPT
    assert normalize_claim_status("Réglé") == ClaimStatusCategory.ACCEPT
    assert normalize_claim_status("Reglé") == ClaimStatusCategory.ACCEPT


def test_refus_variants():
    assert normalize_claim_status("Terminé Refusé") == ClaimStatusCategory.REFUS
    assert normalize_claim_status("Terminé - refusé avant instruction") == ClaimStatusCategory.REFUS
    assert normalize_claim_status("Terminé - refusé après instruction") == ClaimStatusCategory.REFUS
    assert normalize_claim_status("Refusé") == ClaimStatusCategory.REFUS
    assert normalize_claim_status("Terminé - prescrit") == ClaimStatusCategory.REFUS
    assert normalize_claim_status("Terminé sans suite") == ClaimStatusCategory.REFUS


def test_en_cours_variants():
    assert normalize_claim_status("En cours accepté") == ClaimStatusCategory.EN_COURS
    assert normalize_claim_status("En cours") == ClaimStatusCategory.EN_COURS
    assert normalize_claim_status("En cours - accepté") == ClaimStatusCategory.EN_COURS
    assert normalize_claim_status("En cours de règlement") == ClaimStatusCategory.EN_COURS
    assert normalize_claim_status("En cours d'instruction") == ClaimStatusCategory.EN_COURS


def test_unmapped_is_inconnu():
    assert normalize_claim_status("Statut jamais vu auparavant") == ClaimStatusCategory.INCONNU


def test_empty_is_inconnu():
    assert normalize_claim_status("") == ClaimStatusCategory.INCONNU
    assert normalize_claim_status(None) == ClaimStatusCategory.INCONNU


def test_case_and_accent_insensitive():
    assert normalize_claim_status("REGLE") == ClaimStatusCategory.ACCEPT
    assert normalize_claim_status("regle") == ClaimStatusCategory.ACCEPT


def test_mapping_is_extensible_without_rewriting_app():
    add_status_mapping("Nouveau statut maison", ClaimStatusCategory.EN_COURS)
    assert normalize_claim_status("Nouveau statut maison") == ClaimStatusCategory.EN_COURS


def test_real_values_v180_src_sinistre_transformer_contenu():
    """Les 22 valeurs distinctes réelles de Statut_Technique_Sinistre sur
    TECH_BI.dbo.SRC_Sinistre_Transformer_Contenu, fournies par l'utilisateur
    (requête GROUP BY) — deux décisions ambiguës validées explicitement avec
    lui : "Annulé gestion" -> REFUS, "En attente de (prescription)" -> EN_COURS."""
    expected = {
        "Terminé - accepté": ClaimStatusCategory.ACCEPT,
        "Terminé - Refusé après instruction": ClaimStatusCategory.REFUS,
        "Terminé sans suite": ClaimStatusCategory.REFUS,
        "Terminé - prescrit": ClaimStatusCategory.REFUS,
        "Terminé - Refusé avant instruction": ClaimStatusCategory.REFUS,
        "Terminé accepte": ClaimStatusCategory.ACCEPT,
        "En cours - accepté": ClaimStatusCategory.EN_COURS,
        "Terminé - refusé": ClaimStatusCategory.REFUS,
        "Annulé gestion": ClaimStatusCategory.REFUS,
        "En attente de prescription": ClaimStatusCategory.EN_COURS,
        "Terminé – accepté": ClaimStatusCategory.ACCEPT,  # tiret cadratin (–)
        "Réglé": ClaimStatusCategory.ACCEPT,
        "En cours": ClaimStatusCategory.EN_COURS,
        "Sans suite": ClaimStatusCategory.REFUS,
        "Terminé Refuse": ClaimStatusCategory.REFUS,
        "Refusé": ClaimStatusCategory.REFUS,
        "En cours accepte": ClaimStatusCategory.EN_COURS,
        "En cours d'instruction": ClaimStatusCategory.EN_COURS,
        "En cours de règlement": ClaimStatusCategory.EN_COURS,
        "En attente prescription": ClaimStatusCategory.EN_COURS,
        "Prescrit": ClaimStatusCategory.REFUS,
    }
    for label, category in expected.items():
        assert normalize_claim_status(label) == category, label
    # NULL observé 665 fois dans la base réelle -> INCONNU automatique.
    assert normalize_claim_status(None) == ClaimStatusCategory.INCONNU
