from decimal import Decimal

from app.core.models import ProfitabilityRow
from app.core.reconciliation import reconcile


def test_reconciliation_perfect_match():
    app_rows = [
        ProfitabilityRow(
            identifiant_contrat_tdb="C1",
            key_contrat_date="C1_01012026",
            volumes_primes_ttc=Decimal("100"),
            volumes_primes_ht=Decimal("90"),
        )
    ]
    sql_rows = [{"Key_Contrat_Date": "C1_01012026", "Volumes_Primes_TTC": 100, "Volumes_Primes_HT": 90}]

    report = reconcile(app_rows, sql_rows)
    assert report.is_fully_reconciled is True


def test_reconciliation_detects_amount_diff():
    app_rows = [
        ProfitabilityRow(
            identifiant_contrat_tdb="C1",
            key_contrat_date="C1_01012026",
            volumes_primes_ttc=Decimal("100"),
        )
    ]
    sql_rows = [{"Key_Contrat_Date": "C1_01012026", "Volumes_Primes_TTC": 150}]

    report = reconcile(app_rows, sql_rows)
    assert report.is_fully_reconciled is False
    assert len(report.key_level_diffs) == 1
    assert report.key_level_diffs[0].key_contrat_date == "C1_01012026"


def test_reconciliation_detects_keys_only_in_one_side():
    app_rows = [ProfitabilityRow(identifiant_contrat_tdb="C1", key_contrat_date="ONLY_APP")]
    sql_rows = [{"Key_Contrat_Date": "ONLY_SQL", "Volumes_Primes_TTC": 10}]

    report = reconcile(app_rows, sql_rows)
    assert report.keys_only_in_app == ["ONLY_APP"]
    assert report.keys_only_in_sql == ["ONLY_SQL"]
    assert report.is_fully_reconciled is False
