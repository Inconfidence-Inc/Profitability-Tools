from decimal import Decimal

from app.core.kpi import group_sum, monthly_series
from app.core.models import ProfitabilityRow


def test_group_sum_by_compagny():
    rows = [
        ProfitabilityRow(identifiant_contrat_tdb="A", compagny="X", volumes_primes_ttc=Decimal("100")),
        ProfitabilityRow(identifiant_contrat_tdb="B", compagny="X", volumes_primes_ttc=Decimal("50")),
        ProfitabilityRow(identifiant_contrat_tdb="C", compagny="Y", volumes_primes_ttc=Decimal("500")),
    ]
    result = group_sum(rows, "compagny", ["volumes_primes_ttc"])
    assert result[0] == ("Y", {"volumes_primes_ttc": Decimal("500")})
    assert result[1] == ("X", {"volumes_primes_ttc": Decimal("150")})


def test_group_sum_limit():
    rows = [ProfitabilityRow(identifiant_contrat_tdb=str(i), compagny=f"C{i}", volumes_primes_ttc=Decimal(i)) for i in range(5)]
    result = group_sum(rows, "compagny", ["volumes_primes_ttc"], limit=2)
    assert len(result) == 2


def test_monthly_series_sorted_chronologically():
    rows = [
        ProfitabilityRow(identifiant_contrat_tdb="A", annee=2026, mois=3, volumes_primes_ttc=Decimal("10")),
        ProfitabilityRow(identifiant_contrat_tdb="A", annee=2026, mois=1, volumes_primes_ttc=Decimal("20")),
        ProfitabilityRow(identifiant_contrat_tdb="A", annee=2025, mois=12, volumes_primes_ttc=Decimal("5")),
    ]
    series = monthly_series(rows)
    labels = [label for label, _ in series]
    assert labels == ["2025-12", "2026-01", "2026-03"]


def test_monthly_series_skips_rows_without_date():
    rows = [ProfitabilityRow(identifiant_contrat_tdb="A", annee=None, mois=None)]
    assert monthly_series(rows) == []
