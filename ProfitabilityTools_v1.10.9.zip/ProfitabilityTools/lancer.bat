@echo off
setlocal
cd /d "%~dp0"
set LOGFILE=%~dp0lancer_log.txt
echo. > "%LOGFILE%"

echo ============================================
echo ProfitabilityTools - Lancement
echo ============================================
echo Dossier courant : %cd%
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=py
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set PYCMD=python
    ) else (
        echo ERREUR : aucun interpreteur Python trouve - ni "py" ni "python" installes avec PATH. >> "%LOGFILE%"
        echo ERREUR : aucun interpreteur Python trouve - ni "py" ni "python" installes avec PATH.
        echo Installez Python depuis https://www.python.org/downloads/ en cochant "Add python.exe to PATH".
        pause
        exit /b 1
    )
)

echo Interpreteur utilise : %PYCMD%
echo Interpreteur utilise : %PYCMD% >> "%LOGFILE%"
%PYCMD% --version 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOGFILE%' -Append"
echo.

echo Installation des dependances - peut prendre 1-2 minutes...
echo --- pip install --- >> "%LOGFILE%"
%PYCMD% -m pip install -r requirements.txt 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOGFILE%' -Append"
if errorlevel 1 (
    echo.
    echo ERREUR pendant l'installation des dependances. Voir le message ci-dessus et lancer_log.txt.
    pause
    exit /b 1
)

echo.
echo Lancement de l'application...
echo --- app launch --- >> "%LOGFILE%"
%PYCMD% -m app.main 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOGFILE%' -Append"
if errorlevel 1 (
    echo.
    echo ERREUR au lancement. Voir le message ci-dessus et lancer_log.txt.
)

echo.
echo Un fichier lancer_log.txt a ete cree a cote de ce script avec le detail complet.
pause
