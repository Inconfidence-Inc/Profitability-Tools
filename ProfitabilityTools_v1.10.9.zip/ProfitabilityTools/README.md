# ProfitabilityTools

Application PySide6 (desktop, ICI Assurance) d'analyse de profitabilité et de
performance des programmes/contrats d'assurance : souscriptions, primes,
commissions, sinistres, tranches tarifaires.

> **Important — définition de « Profitability »** : ProfitabilityTools n'est
> **pas** une formule (ex. `Prime - Sinistres`). C'est le **dataset
> consolidé** obtenu après rapprochement, nettoyage, agrégation et
> enrichissement des sources décrites ci-dessous. Les ratios analytiques
> (Claim Frequency, Commission Rate, ...) sont des outils construits
> au-dessus de ce dataset, jamais sa définition.

## 1. Installation

Prérequis : Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows : .venv\Scripts\activate
pip install -r requirements.txt
```

Pour une connexion SQL Server réelle, un pilote ODBC (ex. "ODBC Driver 18
for SQL Server") doit être installé sur le poste.

## 2. Configuration

```bash
cp .env.example .env
```

L'application fonctionne exclusivement avec une connexion SQL Server réelle
(le mode DEMO a été retiré en v1.6.0). Renseigner au minimum le profil
**Recette** dans `.env` (`PROFITABILITY_DB_RECETTE_SERVER`, etc.) pour
pouvoir démarrer l'application immédiatement après installation. **Aucun
identifiant n'est jamais codé en dur dans le code source.**

Depuis la v1.3.0, une authentification Windows ("connexion locale") est
disponible en alternative à l'authentification SQL Server : cocher
`PROFITABILITY_DB_<ENV>_TRUSTED_CONNECTION=true` (ou la case correspondante
dans l'écran Settings) utilise la session Windows courante — les champs
Utilisateur et Mot de passe deviennent alors inutiles. Ne fonctionne que si
ce compte Windows a des droits sur le serveur SQL visé (poste joint au
domaine, ou serveur local) — c'est l'équivalent de « Windows Authentication »
dans SQL Server Management Studio.

Depuis la v1.6.0, deux profils de connexion indépendants sont gérés —
**Recette** et **Production** — chacun avec sa propre configuration
serveur/bases/identifiants, enregistrée séparément dans `.env` sous des clés
préfixées (`PROFITABILITY_DB_RECETTE_*`, `PROFITABILITY_DB_PRODUCTION_*`). Le
sélecteur **Environnement actif** de l'écran Settings bascule d'un profil à
l'autre sans jamais modifier les réglages de l'autre : chaque configuration
reste enregistrée telle quelle jusqu'à sa prochaine modification explicite.
L'environnement actif est aussi rappelé en permanence dans un bandeau en
haut de l'application (**ENVIRONNEMENT : RECETTE / PRODUCTION**, ce dernier
mis en évidence en rouge pour éviter toute confusion avec un environnement
non-productif). Au premier démarrage après cette mise à jour, l'environnement
actif par défaut est **Recette**. Un `.env` créé avant la v1.6.0 (identifiants
non préfixés) continue de fonctionner sans perte : il est automatiquement
repris comme profil Recette.

Un troisième profil, **Local**, existait jusqu'en v1.10.3. Il a été retiré en
**v1.10.4**, à la demande explicite de l'utilisateur, qui souhaite que toute
connexion passe directement par le serveur (Recette ou Production), sans
profil local distinct. Un `.env` antérieur à ce retrait contenant encore
`PROFITABILITY_ACTIVE_ENV=LOCAL` et/ou des clés `PROFITABILITY_DB_LOCAL_*`
continue de démarrer normalement : l'environnement actif retombe
automatiquement sur Recette, et les clés `LOCAL` devenues orphelines sont
simplement ignorées (ni lues, ni supprimées).

Depuis la v1.7.0, l'application se connecte aux **vraies tables sources**
`[TECH_BI].[dbo].[SRC_TDBPART1]` et `[TECH_BI].[dbo].[SRC_TDBPART2]` (et non
plus `[ICI_BI].[dbo].[TDB_Part1]`/`TDB_Part2`, qui n'existent pas sur
l'environnement réel — voir §7 pour le détail de cette correction).

Depuis la v1.8.0, la source des sinistres est également la **vraie table**
`[TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu]` (et non plus
`[ICI_BI].[dbo].[TDB_Sinistres_Agrégés]`, qui n'existe pas non plus sur
l'environnement réel — voir §7 pour le détail de cette seconde correction).

Depuis la v1.4.0, tous les tableaux de l'application (Dashboard, Contracts,
Claims, Data Quality, Profitability Explorer) sont plus flexibles : colonnes
redimensionnables en glissant leur bordure, tri en cliquant sur un en-tête
(avec un tri correct — numérique/date — même sur une valeur déjà formatée à
l'écran, ex. un montant ou une date), et un bouton **Colonnes** pour
afficher/masquer les colonnes de chaque tableau indépendamment (voir
`app/ui/widgets/table_flex.py`).

Depuis la v1.5.0, l'application porte un petit logo (monogramme « PT » sur
fond bleu de marque, `app/assets/logo.svg`) affiché à la fois dans l'en-tête
de l'application et comme icône de fenêtre/barre des tâches (voir
`app/ui/icons.py`) ; l'exécutable construit avec `build_exe.bat` embarque
aussi ce logo comme icône du fichier `.exe`. Cette même version corrige un
bug de démarrage : un fichier `.env` contenant une valeur non numérique pour
`PROFITABILITY_DB_TIMEOUT` faisait planter tout le lancement de
l'application (`ValueError` non géré) au lieu de retomber sur la valeur par
défaut comme le font déjà les autres réglages du fichier (voir
`app/config/settings.py::_get_int`).

Depuis la v1.1.0, l'écran **Settings** propose aussi un formulaire pour
saisir/modifier ces paramètres (serveur, bases ICI_BI/TECH_BI, utilisateur,
mot de passe, pilote ODBC, chiffrement, délai de connexion) directement dans
l'application, avec un bouton **Tester la connexion**. « Enregistrer la
configuration » ne fait qu'écrire ces valeurs dans le fichier `.env` local
(`app/config/env_writer.py`) — strictement équivalent à l'éditer à la main.

## 3. Lancement

```bash
python -m app.main
```

## 4. Lancer les tests

```bash
pytest tests/ -v
```

205 tests couvrent : `Key_Contrat_Date`, `Total_Com`/`Sum_Other_Commission`,
règle NULL → 0, normalisation des tranches tarifaires, mapping des statuts
de sinistres (y compris les 21 valeurs réelles distinctes observées sur
`SRC_Sinistre_Transformer_Contenu`, v1.8.0), rattachement des sinistres à un
contrat/période par `Numero_Police` + année/mois (v1.8.0), référentiel
programmes (jointure par plage de dates, v1.7.0), agrégation de bout en bout
(dataset de test à résultats connus, colonnes réelles
`SRC_TDBPART1`/`SRC_TDBPART2`/`SRC_Sinistre_Transformer_Contenu`), KPI et
divisions par zéro, Data Quality (y compris les sinistres non rattachables à
un contrat/période), rafraîchissement différé de l'écran Data Quality tant
qu'il n'est pas visible (v1.8.1), réconciliation, export CSV/Excel,
lecture/écriture du fichier `.env` depuis l'onglet Settings, cohérence
Tester/Enregistrer/Appliquer de la connexion SQL Server sur l'écran Settings,
authentification Windows ("connexion locale" / Trusted_Connection), gestion
des deux profils d'environnement Recette/Production (lecture des
clés préfixées, bascule sans fuite entre profils, rétrocompatibilité avec un
`.env` v1.5.0 non préfixé, non-régression du retrait du profil "Local" en
v1.10.4), flexibilité des tableaux (tri correct sur valeur
brute, redimensionnement, choix des colonnes visibles), logo/icône de
l'application (`app/ui/icons.py`, y compris le cas d'un fichier de logo
manquant), la correction du bug de démarrage sur un délai de connexion
mal formé dans `.env`, le formatage d'affichage défensif sur une valeur
numérique malformée, le filet de sécurité local par écran — une
exception injectée dans le rendu de chaque écran ne doit jamais se
propager hors de son point d'entrée (v1.8.2, voir §10) —, et la colonne
figée des tableaux à beaucoup de colonnes, y compris le réalignement de la
colonne Contrat en première position quel que soit l'ordre de sélection des
colonnes (v1.9.0, voir §11), l'authentification applicative ProfitabilityTools
— amorçage du repli local, écran de connexion, écran Utilisateurs, section
Authentification de Settings et bouton de connexion OUTILS sur l'écran de
connexion lui-même (v1.10.0 à v1.10.2, voir §12) —, et l'exécution d'une
requête SQL Server réelle face à un faux curseur/connexion reproduisant
fidèlement les contraintes du vrai pyodbc (v1.10.3, voir §6).

Le générateur de données synthétiques utilisé par ces tests (ex-mode DEMO de
l'application, retiré de l'UI en v1.6.0) vit désormais dans
`tests/support/demo_data_provider.py` — non embarqué dans l'application
livrée, mais toujours disponible comme fixture de test/documentation.

## 5. Architecture

```
app/
  assets/
    logo.svg / logo.png / logo.ico  # Logo "PT" de l'application (v1.5.0) — source, raster, icône Windows
  config/
    settings.py          # Configuration via variables d'environnement (.env) — jamais de secret en dur
    env_writer.py         # Lecture/écriture de .env depuis l'onglet Settings (v1.1.0)
    status_mapping.py       # Mapping centralisé des statuts de sinistres (évolutif sans réécrire l'app)
  core/                    # Toute la logique métier ProfitabilityTools — jamais dupliquée ailleurs
    money.py               # Decimal-safe : NULL -> 0, division sécurisée, précision financière
    keys.py                 # Key_Contrat_Date, parsing des dates métier (dd/MM/yyyy)
    referentiel.py           # Référentiel programmes : couverture par plage de dates (v1.7.0)
    commissions.py            # Total_Com, Sum_Other_Commission
    price_range.py             # Normalisation des tranches tarifaires (réplique fidèle du SQL de référence)
    claims_dedup.py             # Dédoublonnage sinistres (Police+Dossier, montant max)
    aggregation.py                # Construction du dataset consolidé ProfitabilityTools (réplique du SQL)
    models.py                      # ProfitabilityRow (le dataset consolidé) + libellés/colonnes
    kpi.py                          # KPI, ratios analytiques (division sécurisée), regroupements pour graphiques
    data_quality.py                  # Détection d'anomalies (§17)
    reconciliation.py                 # Comparaison avec un export SQL de référence (§23)
    exporters.py                      # Export CSV / Excel
  data/
    provider.py             # Interface DataProvider (implémentation unique : SQL Server, depuis v1.6.0)
    sqlserver_provider.py     # Connecteur SQL Server (requêtes paramétrées, credentials via .env uniquement)
  ui/
    main_window.py           # Fenêtre principale : sidebar, header, bandeau environnement actif, filtres globaux
    icons.py                  # Icône de fenêtre/barre des tâches + logo d'en-tête (v1.5.0, app/assets/)
    state.py                   # État applicatif partagé (dataset courant, filtres, thème) + signaux Qt
    theme.py                   # QSS clair / sombre
    formatters.py                # Formatage montants/dates (affichage uniquement, jamais pour les calculs)
    widgets/                      # KPI card, sélecteur multi-valeurs avec recherche, modèle de table, graphiques,
                                   # table_flex.py (tri/redimensionnement/colonnes visibles, v1.4.0)
    pages/                          # Dashboard, Profitability Explorer, Contracts, Claims, Data Quality, Settings
  main.py                     # Point d'entrée
tests/                         # Tests métier (pytest)
```

La règle structurante : **toute la logique ProfitabilityTools vit dans
`app/core/`**, testée indépendamment de l'UI et de la source de données. Le
`DataProvider` SQL Server renvoie des lignes brutes avec les mêmes noms de
colonnes que les tables sources, et c'est
`app.core.aggregation.build_profitability_dataset` — une seule et même
fonction — qui applique toutes les règles métier. L'UI ne contient aucun
calcul métier.

## 6. Environnements de connexion (Recette / Production)

Depuis la v1.6.0, l'application se connecte exclusivement à SQL Server (le
mode DEMO a été retiré) et gère **deux profils de connexion indépendants** :
Recette et Production. Chacun a sa propre configuration serveur,
bases (`ICI_BI`/`TECH_BI`), identifiants et paramètres de connexion,
enregistrée séparément dans `.env` sous des clés préfixées
(`SqlServerConfig.env_keys()`) — sélectionner un environnement dans l'écran
**Settings** recharge son profil déjà enregistré sans jamais toucher à
l'autre.

L'environnement actif est visible en permanence dans un bandeau d'en-tête
(**ENVIRONNEMENT : RECETTE / PRODUCTION**), Production étant mis en
évidence en rouge — une manière de toujours savoir, au premier coup d'œil,
si l'on consulte un environnement de test ou l'environnement réel de
production.

L'application lit `[TECH_BI].[dbo].[SRC_TDBPART1]`, `[SRC_TDBPART2]`,
`[SRC_Sinistre_Transformer_Contenu]` et
`[ICI_BI].[dbo].[FONC_Référentiel programmes]` via des requêtes paramétrées
(pyodbc), quel que soit l'environnement sélectionné — seule la chaîne de
connexion change d'un profil à l'autre, jamais les règles métier. Les deux
profils (Recette/Production) partagent la même structure de tables
(confirmé par l'utilisateur).

### Retrait du profil "Local" (v1.10.4)

Un troisième profil, **Local**, existait jusqu'en v1.10.3 (destiné à une
base locale/`localdb`, typiquement en authentification Windows). Il a été
**retiré de l'application en v1.10.4**, à la demande explicite de
l'utilisateur ("Annule la connexion à la base LOCAL et que tout se passe
directement côté serveur") : seuls Recette et Production restent
sélectionnables, et toute connexion passe désormais obligatoirement par un
vrai serveur SQL Server.

Ce retrait ne touche en rien le système de comptes/connexion utilisateur de
ProfitabilityTools (écran de connexion, gestion des utilisateurs — voir §12),
qui conserve sa propre option distincte "Local (fichier, sans OUTILS)" :
c'est un système totalement séparé (authentification applicative, pas
connexion aux données métier), que l'utilisateur a explicitement confirmé
vouloir garder inchangé.

Pour un `.env` créé avant ce retrait : l'environnement actif
(`PROFITABILITY_ACTIVE_ENV=LOCAL`) retombe automatiquement sur Recette au
démarrage, et les clés `PROFITABILITY_DB_LOCAL_*` devenues orphelines sont
simplement ignorées — aucune perte de données, aucun plantage, mais elles
peuvent être supprimées manuellement du fichier `.env` si on le souhaite.

### Correction du schéma source (v1.7.0)

Les premiers tests de l'application contre un environnement Recette réel ont
révélé que les tables supposées jusqu'ici (`[ICI_BI].[dbo].[TDB_Part1]` /
`TDB_Part2`, avec des noms de colonnes en anglais) **n'existaient pas** —
erreur SQL `Invalid object name 'ICI_BI.dbo.TDB_Part1'`. À partir des vraies
requêtes de génération de ces tableaux de bord (partagées par l'utilisateur)
et de la structure réelle de la table chargée en base, les points suivants
ont été confirmés et corrigés :

- Tables réelles : **`[TECH_BI].[dbo].[SRC_TDBPART1]`** et
  **`[TECH_BI].[dbo].[SRC_TDBPART2]`**, avec des noms de colonnes en
  français, en minuscules (ex. `identifiant_contrat`,
  `montant_total_commission_ici`) — repris tels quels comme clés des
  dictionnaires Python, sans alias, pour que le code et le SQL réel
  correspondent exactement.
- Jointure avec `[FONC_Référentiel programmes]` : **par plage de dates**
  (`prog.DATE_DEBUT <= début période ET prog.DATE_FIN >= fin période`) et non
  plus "dernière version par date de mise à jour". Cette table ne sert
  désormais plus qu'au contrôle Data Quality « Contrats sans référentiel » —
  Pays/Produit/Régularisation viennent directement de `SRC_TDBPART1`.
- **TPA = `gestionnaire_1`** (et non `gestionnaire_2`) ; **Courtier =
  `courtier_1`** (et non `courtier_2`).
- **Commission TPA = `montant_total_frais_gestion`**.
- **Total_Com** = somme de `montant_total_commission_ici` +
  `montant_total_commission_distributeur` + `montant_total_frais_gestion` +
  `montant_total_autres_commissions_1/2/3` (formule déjà correcte dans le
  code, confirmée par l'utilisateur).
- **`NBRE_RESILIATION`** vient de `nombre_resiliations` sur `SRC_TDBPART2`.
- Le filtre **« Fait générateur »**, sans équivalent dans la vraie source, a
  été **remplacé par « Régularisation »** (colonne réelle `regularisation`
  de `SRC_TDBPART1`). **« Pays »** et **« Courtier »** sont devenus deux
  nouveaux filtres globaux à part entière.

### Correction de la source Sinistres (v1.8.0)

Les premiers tests de la v1.7.0 contre l'environnement Recette réel ont de
nouveau révélé une table supposée mais inexistante — erreur SQL
`Invalid object name 'ICI_BI.dbo.TDB_Sinistres_Agrégés'`. Contrairement à
`TDB_Part1`/`TDB_Part2`, cette table n'était pas seulement mal nommée : elle
était aussi supposée **déjà agrégée** (une ligne par contrat/période), alors
que la vraie source est une table **brute, au niveau du sinistre** (une
ligne par sinistre). Les points suivants ont été confirmés avec
l'utilisateur et corrigés :

- Table réelle : **`[TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu]`**,
  une ligne par sinistre (pas de pré-agrégation). L'agrégation par
  contrat/période, auparavant supposée faite en amont en SQL, est désormais
  **entièrement réalisée côté Python** (`app/core/aggregation.py`,
  `_build_sinistres_index`).
- **Rattachement au contrat** : `Numero_Police` (comparé à
  `identifiant_contrat` de `SRC_TDBPART1`) — et non `Numero_Adhesion`.
- **Rattachement à la période** : `Date_Souscription_Adhesion`, comparée à
  **année + mois uniquement** (pas une égalité de date exacte) —
  `date_debut_periode_souscription` (Part1) est toujours le 1er du mois,
  alors que `Date_Souscription_Adhesion` (sinistre) est une date
  d'adhésion réelle, à un jour quelconque du mois. Une comparaison stricte
  aurait manqué quasiment tous les rattachements.
- **Champ statut** : `Statut_Technique_Sinistre` (et non
  `Statut_Sinistre_Niveau_2`).
- **Champ montant** : `Montant_Total_Reglement` (et non
  `Montant_Total_Reglement_FR`).
- **Pas de dédoublonnage nécessaire** : une ligne de la table source =
  un sinistre unique, confirmé par l'utilisateur (`app/core/claims_dedup.py`
  reste disponible mais inutilisé — voir §7 point 6).
- **Mapping des statuts** mis à jour avec les **22 valeurs distinctes
  réelles** observées en base (`app/config/status_mapping.py`), dont deux cas
  ambigus explicitement validés avec l'utilisateur : `"Annulé gestion"` →
  **Refusé**, `"En attente de prescription"` / `"En attente prescription"` →
  **En cours**.
- **Minimisation des données** : la table source contient des données
  personnelles (`Nom_Client`, `Nom_Magasin`, etc.) qui ne sont **ni
  récupérées, ni affichées** nulle part dans l'application — choix
  volontaire de confidentialité par défaut, documenté dans
  `app/data/sqlserver_provider.py`, et non une omission.

### Correctif mémoire sur les sinistres (v1.8.1)

Un test en conditions réelles de la v1.8.0 a révélé un plantage silencieux
de l'application (fermeture instantanée, sans aucun message) juste après
« Appliquer et recharger les données » — comportement caractéristique d'un
manque de mémoire système (le processus est arrêté par le système
d'exploitation, sans exception Python interceptable, donc sans passer par
le filet de sécurité `app/main.py`/`AppState.reload()`). En cause : la vraie
table `SRC_Sinistre_Transformer_Contenu` contient de l'ordre de **1,3
million de lignes de sinistres bruts**, chargées intégralement en mémoire à
chaque rechargement. Deux correctifs, sans aucun changement de règle
métier ni de donnée affichée :

- **`app/data/sqlserver_provider.py`** : la lecture SQL se fait désormais
  par lots (`cursor.fetchmany()`) plutôt qu'avec `cursor.fetchall()` suivi
  d'une reconstruction de liste séparée — cette dernière approche gardait
  temporairement deux copies complètes du résultat en mémoire en même
  temps, doublant inutilement le pic mémoire sur une table de cette taille.
- **`app/ui/pages/data_quality_page.py`** : l'écran **Data Quality** est le
  seul à parcourir la liste brute des sinistres (pour détecter les
  sinistres non rattachables). Comme tous les écrans sont construits
  d'avance et réagissent tous aux mêmes évènements, ce calcul coûteux se
  relançait auparavant à **chaque** rechargement ou changement de filtre,
  même lorsque l'utilisateur regardait un autre écran (Dashboard, Claims,
  ...) — un facteur aggravant au moment précis du plantage. Le recalcul est
  désormais différé : il ne s'exécute que lorsque l'écran Data Quality
  devient réellement visible, ou immédiatement s'il l'est déjà.

### Correctif chargement des données — timeout de requête (v1.10.3)

Remonté par l'utilisateur, avec le message exact affiché par l'application :
`'pyodbc.Cursor' object has no attribute 'timeout' and no __dict__ for
setting new attributes`. Le délai d'exécution de requête ajouté en v1.8.2
(`_QUERY_TIMEOUT_SECONDS`) était affecté par erreur au **curseur**
(`cursor.timeout = ...`) plutôt qu'à la **connexion**
(`conn.timeout = ...`) — `pyodbc.Cursor` est un type C qui n'autorise
aucun attribut arbitraire (contrairement à `pyodbc.Connection`, qui
expose bien `timeout` comme attribut valide). Conséquence : **toute**
requête de données réelles (Part1, Part2, Référentiel, Sinistres — donc
tout rechargement, quel que soit l'environnement Local/Recette/Production)
échouait systématiquement dès qu'une connexion SQL Server aboutissait,
avec le message ci-dessus affiché dans la boîte « Chargement des
données ». Le filet de sécurité existant a bien empêché un plantage de
l'application (voir §10), mais aucune donnée réelle n'a pu être chargée
depuis l'introduction du bug (v1.8.2) jusqu'à ce correctif. Resté invisible
en tests faute d'un faux pyodbc reproduisant fidèlement cette contrainte du
vrai module (voir `tests/test_sqlserver_provider.py`, qui comble cette
lacune avec un faux curseur/connexion à base de `__slots__`, refusant lui
aussi tout attribut imprévu). Corrigé : le délai est désormais affecté à la
connexion, une seule fois, juste après l'établissement de celle-ci. 4
nouveaux tests — 193 au total.

### Retrait du profil d'environnement "Local" (v1.10.4)

Suite au correctif ci-dessus, l'utilisateur a demandé : *« Annule la
connexion à la base LOCAL et que tout se passe directement côté serveur »*.
Après clarification (le profil SQL Server "Local" de l'écran Settings, à
distinguer du système de comptes applicatifs — voir §12 — qui a sa propre
notion indépendante de "Local (fichier, sans OUTILS)"), l'utilisateur a
confirmé vouloir **retirer définitivement "Local" de l'application** plutôt
qu'une simple reconfiguration ponctuelle.

Seuls **Recette** et **Production** restent désormais sélectionnables comme
environnement de connexion (`app/config/settings.py::ENVIRONMENTS`,
`DEFAULT_ENVIRONMENT` passé de `"LOCAL"` à `"RECETTE"`). La migration
automatique d'un `.env` non préfixé (antérieur à la v1.6.0) reste
fonctionnelle, simplement recentrée sur le nouveau profil par défaut
(Recette). Un `.env` existant qui contiendrait encore
`PROFITABILITY_ACTIVE_ENV=LOCAL` et/ou des clés `PROFITABILITY_DB_LOCAL_*`
démarre toujours normalement : l'environnement actif retombe
automatiquement sur Recette, et les clés `LOCAL` orphelines sont ignorées
sans erreur (voir §6 pour le détail). 2 nouveaux tests de non-régression —
195 au total.

## 7. Hypothèses documentées (cahier des charges §24)

Le SQL fourni comme référence fonctionnelle contient des comportements
spécifiques, reproduits **à l'identique** plutôt que "corrigés" silencieusement :

1. **Pas de vraie somme en cas de lignes `SRC_TDBPART1` dupliquées** pour une
   même clé `Key_Contrat_Date` (le `GROUP BY` du SQL de référence liste
   toutes les colonnes sans les envelopper dans `SUM()`). Décision validée
   avec l'utilisateur : reproduire ce comportement et **signaler ces cas
   dans Data Quality** plutôt que sommer automatiquement.
2. **`NBRE_RESILIATION`** vient d'un `SUM` sur `SRC_TDBPART2`
   (`nombre_resiliations`), alors que **`NumberOfSubscription`** vient
   directement du total pré-agrégé de `SRC_TDBPART1`
   (`nombre_total_adhesions`) — deux sources distinctes, volontairement
   conservées telles quelles.
3. **Choix de la tranche tarifaire/référence** en cas de plusieurs lignes
   `SRC_TDBPART2` pour un même contrat+période : celle dont `REFERENCE` est la
   plus petite alphabétiquement (`ROW_NUMBER() ORDER BY REFERENCE`) — un
   choix arbitraire du SQL existant, reproduit tel quel.
4. **`"Moins de X"` → `borne_max = None`** (pas `X`) : le SQL de référence
   ne réutilise jamais X comme borne max dans cette branche. Le cahier des
   charges ne spécifie que `borne_min = 0` pour ce cas ; la valeur n'est donc
   pas inventée.
5. **Limite connue de la normalisation des tranches tarifaires** : une valeur
   unique écrite avec un espace comme séparateur de milliers (ex. `"1 500"`
   pour 1500) peut être interprétée à tort comme un intervalle `"1 - 500"`.
   Comportement du SQL existant, reproduit tel quel (voir
   `app/core/price_range.py` pour le détail).
6. **Dédoublonnage des sinistres non nécessaire** : `SRC_Sinistre_Transformer_Contenu`
   ne contient pas de doublons (une ligne = un sinistre unique, confirmé par
   l'utilisateur, v1.8.0). Le module `app/core/claims_dedup.py` reste fourni
   prêt à l'emploi pour une éventuelle future source qui en contiendrait,
   mais n'est pas utilisé dans le pipeline actuel.

## 8. Réconciliation avec le SQL historique (§23)

L'écran **Data Quality** permet d'importer un export CSV du SQL de référence
(mêmes alias de colonnes que le `SELECT` fourni : `Key_Contrat_Date`,
`Volumes_Primes_TTC`, `Volumes_Primes_HT`, `PartAssureur`, `Total_Com`,
`NumberOfSubscription`, `NBRE_RESILIATION`, `Nombre_Sinistres_Total`,
`Montant_Total_Règlement`) et de comparer automatiquement au dataset
courant, globalement puis par `Key_Contrat_Date`, avec les écarts mis en
évidence (`app/core/reconciliation.py`).

## 9. Sécurité

- Aucun identifiant SQL Server dans le code : tout passe par `.env`
  (`app/config/settings.py`).
- Requêtes paramétrées uniquement (`app/data/sqlserver_provider.py`) —
  aucune concaténation de chaîne avec une entrée utilisateur.
- Les erreurs de connexion/exécution SQL sont journalisées (logs) sans
  jamais exposer les identifiants dans les messages remontés à l'UI.

## 10. Robustesse (audit v1.8.2)

Suite au correctif mémoire de la v1.8.1 (§6), une revue systématique a été
menée sur l'ensemble de l'application pour réduire le risque qu'un cas
limite — une donnée réelle inhabituelle, un volume important, un incident
réseau — n'interrompe l'application ou ne la rende inutilisable :

- **Filet de sécurité global** (`app/main.py`) : toute exception Python non
  interceptée (y compris avant le démarrage de Qt) est journalisée dans
  `profitabilitytools_error.log` et affichée dans une boîte de dialogue —
  l'application reste ouverte au lieu de se fermer silencieusement.
  Vérifié toujours en place et complet lors de cet audit.
- **Filet de sécurité LOCAL par écran** (`app/ui/safety.py`, nouveau) :
  jusqu'ici, une exception de rendu sur un écran (Dashboard, Claims,
  Contracts, Profitability Explorer, Data Quality) remontait jusqu'au filet
  global — ce qui évite bien une fermeture, mais affiche une boîte de
  dialogue **bloquante à répétition** si le problème se reproduit à chaque
  changement de filtre. Chaque écran protège désormais son propre rendu :
  en cas d'erreur, seul cet écran affiche un message discret (non
  bloquant) et reste utilisable — les autres écrans et le reste de
  l'application continuent de fonctionner normalement.
- **Délai d'exécution des requêtes SQL** (`app/data/sqlserver_provider.py`) :
  jusqu'ici, seule la connexion initiale était bornée dans le temps
  (`PROFITABILITY_DB_TIMEOUT`) — l'exécution d'une requête pouvait rester
  bloquée indéfiniment (réseau lent, verrou SQL Server), ce qui se
  manifeste comme une application figée. Un délai distinct, plus généreux
  (5 minutes, pensé pour une table de plus d'un million de lignes comme
  `SRC_Sinistre_Transformer_Contenu`), borne désormais aussi l'exécution.
- **Formatage d'affichage** (`app/ui/formatters.py`) : `format_money` et
  `format_percent` ne lèvent plus d'exception sur une valeur numérique
  malformée (ex. `Decimal("NaN")`) — un filet supplémentaire, le flux
  normal garantissant déjà un montant propre en amont
  (`app/core/money.py`).
- **Audit du cœur métier** (`app/core/aggregation.py`, `kpi.py`, `money.py`,
  `price_range.py`, `keys.py`, `status_mapping.py`) : déjà largement
  défensif (parsing de date/montant qui ne lève jamais, NULL toujours
  traité comme 0 ou catégorie « Inconnu ») — aucune lacune supplémentaire
  identifiée.
- **Chargement en arrière-plan** : évalué mais non retenu pour cette
  version (décision explicite de l'utilisateur) — le chargement des
  données reste sur le thread principal ; l'application peut donc sembler
  « ne répond plus » pendant un chargement long sans pour autant planter,
  grâce aux correctifs ci-dessus.

23 nouveaux tests (`tests/test_formatters.py`, `tests/test_ui_safety.py`),
dont une vérification par écran qu'une exception injectée dans son rendu
ne se propage jamais hors de son point d'entrée.

## 11. Ergonomie et lisibilité des tableaux (v1.9.0)

Suite à un retour direct de l'utilisateur sur Profitability Explorer avec
beaucoup de colonnes affichées (« je ne parviens pas à voir toutes les
colonnes ») :

- **Barre de défilement horizontale visible** (`app/ui/theme.py`) : jusqu'ici
  seule la barre verticale avait son propre style — la barre horizontale,
  pourtant seul moyen d'atteindre les colonnes au-delà de la largeur de
  l'écran, utilisait le rendu natif non thémé, peu visible sur fond clair.
  Elle a désormais son propre style (poignée arrondie, plus épaisse,
  surbrillance au survol), au même titre que la verticale.
- **Colonne « Contrat » figée** (`app/ui/widgets/table_flex.py`, nouveau
  `FrozenColumnTableView`) : sur Profitability Explorer et Claims, la
  première colonne reste désormais visible en permanence pendant qu'on fait
  défiler les colonnes de droite — on ne perd plus le repère (de quel
  contrat il s'agit) une fois les colonnes money/sinistres affichées.
  Reprend le principe de l'exemple officiel Qt « Frozen Column » (une
  seconde vue, superposée, limitée à la colonne 0, synchronisée en
  défilement vertical avec le tableau principal).
- **Colonne Contrat toujours en première position** (`explorer_page.py`) :
  quel que soit l'ordre dans lequel l'utilisateur coche les colonnes dans le
  menu « Colonnes » (qui suit l'ordre du cahier des charges, pas un ordre
  choisi par l'utilisateur), la colonne `identifiant_contrat_tdb` (Contrat)
  est automatiquement replacée en première position — c'est elle qui sert
  de repère figé, elle doit donc toujours être affichée en premier.
- **Défilement au pixel près** (`enable_flexible_header`) : les tableaux
  défilaient jusqu'ici cellule par cellule (verticalement comme
  horizontalement), ce qui donne une impression saccadée — le défilement
  est désormais fluide, au pixel près, sur tous les tableaux de
  l'application.
- **Lignes plus aérées et survol visible** : hauteur de ligne par défaut
  légèrement augmentée (meilleure lisibilité des montants), et la ligne sous
  le pointeur est maintenant mise en surbrillance (`QTableView::item:hover`)
  sur tous les tableaux — purement visuel, aucune donnée ni aucun calcul
  n'est modifié.

Ce correctif porte spécifiquement sur les tableaux de données (le retour
utilisateur portait sur Profitability Explorer) ; un remaniement visuel plus
large des autres écrans n'a pas été demandé pour cette version.

7 nouveaux tests (`tests/test_table_flex.py`, `tests/test_theme.py`) — 173 au
total.

## 12. Authentification et gestion des utilisateurs (v1.10.0)

Suite à une demande explicite de l'utilisateur (« Il faut mettre une
interface de connexion pour l'application et aussi permettre la création
d'utilisateur tel que c'est fait actuellement pour l'application
Orchestrator »), ProfitabilityTools demande désormais de se connecter avec
un compte applicatif, et propose un écran de gestion des comptes.

**Important — totalement indépendant des connexions SQL Server métier**
(décision explicite de l'utilisateur) : ce compte applicatif (login/mot de
passe ProfitabilityTools) n'a **aucun rapport** avec les profils de
connexion Recette/Production (ICI_BI/TECH_BI) configurés sur l'écran
Settings. Se connecter à ProfitabilityTools ne nécessite ni ne fournit
d'identifiants de la base métier, et inversement.

- **Module partagé `auth_partage/`** : repris tel quel (avec un correctif,
  voir plus bas) de l'application Orchestrator, à la demande explicite de
  l'utilisateur. Le même couple login/mot de passe fonctionne, à terme,
  pour tout le parc d'applications Python de l'entreprise, avec un **rôle
  par application** (un agent peut être Administrateur d'une application et
  simple Lecteur d'une autre). Les comptes sont normalement portés par une
  base SQL Server centrale, **OUTILS**, partagée entre applications.
- **Repli local automatique tant qu'OUTILS n'est pas configuré sur ce
  poste** : ProfitabilityTools n'est pas encore raccordé à OUTILS. Plutôt
  que de bloquer l'application dès l'installation, un fichier SQLite local
  (dans le dossier de données de l'application) est créé automatiquement
  au premier lancement, avec un compte administrateur par défaut :
  - **Login : `admin`**
  - **Mot de passe : `ProfitAdmin1`**
  - Le changement de ce mot de passe est **imposé dès la première
    connexion** — il ne peut pas rester valable indéfiniment.
  - Un administrateur peut ensuite migrer vers la base OUTILS centrale à
    tout moment (écran « Connexion OUTILS », accessible une fois connecté).
    À partir de ce moment, les comptes créés en local sur ce poste ne sont
    plus utilisés : l'authentification bascule entièrement sur OUTILS.
- **Deux rôles pour cette version** (`app/auth/setup.py`) :
  « Administrateur » (peut créer/modifier/désactiver des comptes, écran
  « Utilisateurs ») et « Lecteur » (aucune restriction sur les autres
  écrans). **Décision explicite de l'utilisateur : pas de restriction
  d'écran par rôle pour cette version** — Dashboard, Profitability
  Explorer, Contracts, Claims, Data Quality et Settings restent ouverts à
  tout compte connecté, quel que soit son rôle. Seul l'écran
  « Utilisateurs » est réservé au rôle Administrateur (il n'apparaît même
  pas dans le menu pour un compte Lecteur).
- **Écran « Utilisateurs »** (`app/ui/pages/users_page.py`) : liste des
  comptes, création, modification et activation/désactivation — réutilise
  directement la boîte de dialogue fournie par `auth_partage`
  (`UtilisateurDialog`). Garde-fou intégré au module partagé : impossible
  de désactiver le dernier compte Administrateur actif de
  ProfitabilityTools.
- **En-tête** : affiche le compte connecté (nom, rôle), avec les actions
  « Changer mon mot de passe » et « Déconnexion ». Se déconnecter réaffiche
  l'écran de connexion sans redémarrer l'application.
- **Correctif apporté au module partagé** (`auth_partage/ui/connexion.py`) :
  la boîte de changement de mot de passe imposé importait un module
  (`views.password_dialog`) propre à l'application d'origine du module
  (Argos) et absent de toute application actuelle, y compris Orchestrator —
  un bug latent, jamais déclenché à Orchestrator faute d'y avoir testé une
  première connexion ou une réinitialisation de mot de passe. Corrigé pour
  utiliser la boîte réellement fournie par le module
  (`auth_partage.ui.mot_de_passe.ChangementMotDePasseDialog`).

12 nouveaux tests (`tests/test_auth.py`) — 185 au total.

### Correctif v1.10.1 — connexion à OUTILS enfin accessible depuis l'application

La v1.10.0 construisait l'écran « Connexion OUTILS » (`ConnexionOutilsDialog`)
mais ne l'ouvrait **nulle part** dans l'application : un administrateur
n'avait donc aucun moyen, depuis ProfitabilityTools, de configurer la
connexion à la base centrale — seul le repli local SQLite était
accessible. Corrigé en ajoutant une section « Authentification (comptes
ProfitabilityTools) » sur l'écran Settings (réservée au rôle
Administrateur, comme l'écran « Utilisateurs »), avec l'état actuel
(local ou centralisé sur OUTILS) et un bouton « Connexion OUTILS… » qui
ouvre la boîte de dialogue déjà existante. 2 nouveaux tests
(`tests/test_auth.py`) — 187 au total.

### Correctif v1.10.2 — connexion au serveur OUTILS accessible depuis l'écran de connexion lui-même

Remonté par l'utilisateur : un compte qui n'existe **que** dans OUTILS
(créé directement en base, ou habilité via une autre application du parc
comme Orchestrator) ne pouvait pas se connecter tant qu'OUTILS n'était pas
configuré sur le poste — et le configurer exigeait de se connecter
d'abord, avec le compte administrateur amorcé localement (§12), un détour
peu évident si on ne connaît pas ce compte de secours. L'écran de
connexion propose désormais, lui aussi, un bouton **« Connexion au
serveur (OUTILS)… »** — avant toute authentification, symétrique de
l'accès ajouté sur Settings en v1.10.1, qui reste la voie normale une
fois connecté. Implémenté par composition autour de `LoginDialog`
(`app/ui/dialogs/login_screen.py`), sans modifier le module partagé
`auth_partage`, pour que celui-ci reste une copie fidèle réutilisable par
les autres applications du parc. 2 nouveaux tests (`tests/test_auth.py`)
— 189 au total.

### Correctif v1.10.5 — l'exécutable construit (`build_exe.bat`) se fermait instantanément

Remonté par l'utilisateur : l'exécutable produit par `build_exe.bat`
(`dist\ProfitabilityTools\ProfitabilityTools.exe`) ne s'ouvrait pas — « rien
ne se passe, ça se ferme instantanément », sans aucun message visible (le
mode `--windowed` utilisé pour l'exécutable n'a aucune console).

Cause confirmée par relecture du script et des dépendances : la commande
PyInstaller de `build_exe.bat` n'avait jamais été mise à jour depuis
l'ajout de l'authentification en v1.10.0, qui a introduit trois nouvelles
dépendances — **SQLAlchemy**, **bcrypt** et **cryptography**
(`auth_partage/`) — en plus de PySide6. SQLAlchemy choisit son
« dialecte » de base de données (`sqlite`, `mssql+pyodbc`, ...) par un
**import dynamique** basé sur le préfixe de l'URL de connexion
(`create_engine("sqlite:///...")`, utilisé dès le premier lancement pour
créer le repli local d'authentification — voir §12) : ce type d'import est
par nature invisible à l'analyse statique de PyInstaller, qui ne détecte
que les `import` écrits explicitement dans le code. Sans action
particulière, l'exécutable construit ne contenait donc tout simplement pas
`sqlalchemy.dialects.sqlite.pysqlite` (ni `sqlalchemy.dialects.mssql.pyodbc`
pour OUTILS) : la toute première tentative de connexion à la base
d'authentification levait un `ModuleNotFoundError` fatal, et l'application
se refermait sans qu'aucun message ne puisse s'afficher — y compris le
filet de sécurité global de `app/main.py` (§10), qui suppose qu'une
`QApplication` a déjà pu être instanciée, ce qui échoue ici dès
l'exécution de `ensure_auth_backend_ready()`.

Corrigé en ajoutant `--collect-all sqlalchemy`, `--collect-all bcrypt`,
`--collect-all cryptography` et `--collect-all auth_partage` à la commande
PyInstaller de `build_exe.bat`, qui force l'inclusion complète de ces
quatre paquets dans l'exécutable, sans dépendre de la détection
automatique des imports. Le reste du script (installation des dépendances,
icône, données `app/assets`) est inchangé. 5 nouveaux tests
(`tests/test_build_script.py`) — non pas une exécution réelle de
PyInstaller (trop longue pour la suite de tests, et nécessite Windows),
mais une vérification que `build_exe.bat` contient bien ces options, pour
qu'une future modification de ce fichier ne les fasse pas disparaître par
erreur — 200 au total.

### Correctif v1.10.6 — régression introduite par le v1.10.5 lui-même (`build_exe.bat` ne produisait plus d'exécutable du tout)

La v1.10.5 ci-dessus corrigeait un vrai bug, mais son propre commentaire
explicatif dans `build_exe.bat` contenait une erreur de frappe : une ligne
`rem/sqlalchemy/bcrypt/cryptography force PyInstaller...` **sans espace**
après `rem`. Sous Windows `cmd.exe`, `REM` doit impérativement être suivi
d'un espace (ou d'une fin de ligne) pour être reconnu comme un commentaire
— sans cet espace, la ligne entière est interprétée comme le nom d'une
commande à exécuter, inexistante, ce qui provoque une erreur « n'est pas
reconnu en tant que commande interne ou externe ». Remonté par
l'utilisateur : « l'exe ne se crée pas », avec un `build_log.txt` quasiment
vide (une seule ligne blanche), confirmant un arrêt très précoce du script.

Corrigé en réécrivant entièrement ce bloc de commentaires (plus court,
chaque ligne commence bien par `rem ` avec un espace), et en supprimant au
passage les caractères accentués qui s'y étaient glissés — le reste du
fichier les évite volontairement depuis toujours, précisément pour ne
jamais dépendre de la page de code active sur le poste Windows cible.
2 nouveaux tests de non-régression, dont un qui recrée exactement ce bug
(ligne `rem` collée à un caractère) pour prouver qu'il serait désormais
détecté automatiquement avant toute livraison, plutôt que découvert par
l'utilisateur — 202 au total.

### Correctif v1.10.7 — erreur de syntaxe `cmd.exe` (fins de ligne du script)

Après le correctif v1.10.6, `build_exe.bat` ne produisait toujours pas
d'exécutable. En relançant le script depuis une fenêtre `cmd.exe` ouverte
manuellement (pour que la fenêtre reste affichée au lieu de se refermer
seule), l'utilisateur a pu capturer le vrai message : une erreur de syntaxe
`cmd.exe` (« ... était inattendu. ») juste après l'affichage du dossier
courant, avant même la détection de Python — c'est-à-dire tout au début du
bloc `IF`/`ELSE` qui choisit l'interpréteur Python (`py` ou `python`).

Cause identifiée : `build_exe.bat` (et `lancer.bat`) ont toujours été
écrits et modifiés avec des fins de ligne Unix (`LF` seul), puisque les
outils utilisés pour les éditer tournent sous Linux — jamais corrigé
jusqu'ici. Un fichier `.bat` Windows doit en principe utiliser des fins de
ligne `CRLF` ; `cmd.exe` tolère généralement `LF` seul pour de simples
lignes `echo`, mais cette tolérance n'est pas garantie pour l'analyse d'un
bloc `IF (...) ELSE (...)` multi-lignes, qu'il doit lire entièrement avant
de l'exécuter — exactement le type de bloc qui suit immédiatement l'endroit
où l'erreur apparaissait, et qui expliquerait aussi pourquoi les versions
précédentes avaient parfois semblé fonctionner (comportement dépendant de
l'environnement, non garanti).

Corrigé en convertissant `build_exe.bat` et `lancer.bat` en fins de ligne
`CRLF` strictes — le format canonique et sans ambiguïté pour un script
Windows, qui élimine ce risque plutôt que de compter sur une tolérance non
garantie de `cmd.exe`. 1 nouveau test de non-régression (vérifie que les
deux scripts ne contiennent plus aucune fin de ligne `LF` seule) — 203 au
total.

### Correctif v1.10.8 — parenthèses littérales dans un bloc `IF`/`ELSE`

Après le correctif v1.10.7 (fins de ligne `CRLF`), le même symptôme a
persisté : fenêtre qui se ferme aussitôt, `build_log.txt` quasiment vide.
Cause réelle, distincte de la v1.10.7 : le même bloc `IF`/`ELSE` de
détection de Python contenait une ligne `echo ERREUR : aucun interpreteur
Python trouve (ni "py" ni "python").` — avec des **parenthèses
littérales**, à l'intérieur même du bloc. `cmd.exe` repère la fin d'un bloc
`IF`/`ELSE` ou `FOR` en comptant les parenthèses de façon purement
textuelle sur l'ensemble de la ligne, y compris celles qui ne sont que du
texte affiché par un `echo`, sans aucun rapport avec la structure réelle du
bloc — un piège classique et bien documenté de `cmd.exe`, indépendant du
correctif CRLF de la v1.10.7 (les deux problèmes coexistaient dans le même
bloc). Cela peut faire dérailler l'analyse de blocs imbriqués et provoquer
soit une erreur de syntaxe cryptique, soit un arrêt total du script avant
le moindre affichage, y compris avant le `pause` final.

Corrigé en reformulant tous les messages `echo` de `build_exe.bat` et
`lancer.bat` pour qu'ils ne contiennent plus aucune parenthèse littérale
(remplacées par un tiret). 1 nouveau test de non-régression (interdit toute
parenthèse non échappée sur une ligne `echo`, y compris hors d'un bloc par
prudence) — 204 au total.

### Correctif v1.10.9 — passage à un exécutable en un seul fichier (`--onefile`)

Après les correctifs v1.10.7/v1.10.8, l'utilisateur a confirmé que la
construction réussissait enfin (l'exe et le dossier `_internal` étaient bien
créés), mais le lancement de l'exécutable échouait avec un nouveau message,
cette fois émis par le bootloader de PyInstaller lui-même, pas par
l'application : « Failed to start embedded python interpreter: Failed to
import encodings module ». Diagnostic écarté en premier : `PYTHONHOME` et
`PYTHONPATH` ont été vérifiés non définis sur le poste de l'utilisateur
(cause la plus fréquente de ce message), donc le problème venait d'ailleurs.

Le mode de construction par défaut de PyInstaller (`--onedir`, utilisé
jusqu'ici) produit un dossier `dist\ProfitabilityTools\` contenant l'exe ET
un dossier séparé `_internal\` de plusieurs centaines de Mo (confirmé par
l'utilisateur : 530 Mo, avec les dépendances PySide6, SQLAlchemy, bcrypt,
cryptography, lxml, numpy, etc.) — ce dossier doit impérativement rester
intact et à côté de l'exe pour que celui-ci fonctionne, ce qui le rend
sensible à une copie partielle, à un antivirus qui mettrait en quarantaine
un seul fichier interne, ou à une synchronisation OneDrive qui laisserait
certains fichiers à l'état de simples références non réellement
téléchargées sur le disque.

Sur demande explicite de l'utilisateur (« un seul .exe qui est complet »),
corrigé en ajoutant l'option `--onefile` à la commande PyInstaller de
`build_exe.bat` : l'exécutable produit est désormais un unique fichier
autonome (`dist\ProfitabilityTools.exe`, plus de dossier `_internal`
séparé), qui s'auto-extrait dans un dossier temporaire à chaque lancement.
La résolution des ressources embarquées (icône, logo) utilisait déjà
`sys._MEIPASS` (voir `app/ui/icons.py`), le mécanisme standard de
PyInstaller qui fonctionne de façon identique en `--onedir` et en
`--onefile` : aucun changement de code applicatif n'a donc été nécessaire.
1 nouveau test de non-régression (vérifie la présence de `--onefile` dans la
commande PyInstaller) — 205 au total.
