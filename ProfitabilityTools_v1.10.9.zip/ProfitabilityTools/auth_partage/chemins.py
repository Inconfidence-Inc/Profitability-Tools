"""Dossier de données LOCAL du poste, propre à l'application hôte.

Y sont écrits la clé de chiffrement locale et le profil de connexion à la
base OUTILS. Le nom du dossier vient de la configuration : deux
applications installées sur le même poste ne doivent pas se partager ces
fichiers — chacune peut viser une base OUTILS différente, de recette pour
l'une et de production pour l'autre.
"""
from __future__ import annotations

import os
import sys

from auth_partage import config


def get_app_data_dir() -> str:
    """%APPDATA%\\<application> sous Windows, ~/.config/<application> ailleurs."""
    nom = config.nom_dossier_donnees()
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(
            os.path.expanduser("~"), ".config")
    chemin = os.path.join(base, nom)
    os.makedirs(chemin, exist_ok=True)
    return chemin
