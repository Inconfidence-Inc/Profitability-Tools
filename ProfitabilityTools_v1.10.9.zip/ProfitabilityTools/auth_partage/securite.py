"""Hachage et politique de mot de passe.

bcrypt : fonction à sens unique et volontairement lente, conçue pour que
l'empreinte stockée ne permette pas de remonter au mot de passe.
"""
from __future__ import annotations

from auth_partage import config
from auth_partage.vendor_securite import hash_password, verify_password  # noqa: F401


def valider_mot_de_passe(mot_de_passe: str) -> str | None:
    """Message d'erreur si le mot de passe ne convient pas, None sinon.

    Politique volontairement simple et explicable : une longueur minimale
    et un mélange lettres/chiffres. Les règles très contraignantes
    poussent aux mots de passe notés sur un papier, et l'ANSSI comme le
    NIST recommandent de privilégier la longueur.
    """
    minimum = config.longueur_minimale_mot_de_passe()
    if len(mot_de_passe) < minimum:
        return f"Le mot de passe doit comporter au moins {minimum} caractères."
    if not any(c.isalpha() for c in mot_de_passe):
        return "Le mot de passe doit contenir au moins une lettre."
    if not any(c.isdigit() for c in mot_de_passe):
        return "Le mot de passe doit contenir au moins un chiffre."
    return None
