# auth_partage — authentification commune aux applications Python

Un agent est déclaré **une seule fois**, dans la base `OUTILS`, avec un
rôle par application. Chaque application vérifie son mot de passe et ses
habilitations au même endroit, et y écrit ses propres traces.

## Déploiement

Procédure complète — base, application, poste — dans **`DEPLOIEMENT.md`**.

## Installation

Copier le dossier `auth_partage/` à la racine de l'application, ou
l'installer :

```bash
pip install ./auth_partage
```

Dépendances : `SQLAlchemy`, `bcrypt`, `cryptography`, et `PySide6`
uniquement si vous utilisez les boîtes de dialogue fournies.

## Mise en service, une fois pour tout le parc

Exécuter `sql/creation_outils_authentification.sql` sur la base `OUTILS`.

Le module **ne crée pas ce schéma** et ne le migre pas : la base est
partagée, et si chaque application y appliquait ses migrations, elles se
feraient concurrence — deux applications démarrant ensemble sur une base
neuve tenteraient de créer les mêmes tables. Le schéma est posé une fois,
les applications se contentent de le vérifier.

Droits minimaux du compte applicatif :

```sql
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.USERS_PYTHON       TO [compte];
GRANT SELECT, INSERT                 ON dbo.USERS_PYTHON_HISTO TO [compte];
```

L'historique n'est volontairement pas modifiable : une trace de connexion
qu'on peut réécrire ne prouve plus rien.

## Intégration dans une application

```python
import auth_partage

auth_partage.configurer(
    application="PORTAIL",                 # code de CETTE application
    permissions={                          # ce que chaque rôle ouvre ICI
        "Administrateur": {"parametres", "utilisateurs", "consultation"},
        "Lecteur":        {"consultation"},
    },
    nom_dossier_donnees="Portail_Assurance",
)
```

`permissions` appartient à l'application, pas au module : le même code de
rôle n'ouvre pas les mêmes écrans d'une application à l'autre. Le module
dit **quel rôle** l'agent porte ici ; ce que ce rôle autorise ne le
regarde pas.

Connexion :

```python
from auth_partage.ui.connexion import LoginDialog

boite = LoginDialog()
if boite.exec() == boite.Accepted:
    utilisateur = boite.current_user     # .login .role .applications
```

Vérifier un droit :

```python
from auth_partage import AuthService
if AuthService().can(utilisateur.role, "parametres"):
    ...
```

## Ce que le module garantit, identiquement partout

- **un seul couple login / mot de passe** pour tout le parc ;
- **un rôle par application** : administrateur ici, lecteur ailleurs ;
- **des sessions indépendantes** — se déconnecter d'une application
  n'affecte pas les autres ;
- **des traces individuelles** : chaque application écrit dans
  `USERS_PYTHON_HISTO` avec son code, le rôle endossé, le poste et le
  compte Windows ;
- **les mêmes refus, avec les mêmes messages**. En particulier le cas
  « compte valide mais non habilité sur cette application », qui liste les
  applications où le compte l'est — sans quoi l'agent croit à un mot de
  passe erroné et le ressaisit en boucle ;
- **les mêmes garde-fous** : mot de passe provisoire à changer à la
  première connexion, politique de mot de passe, et impossibilité de
  retirer le dernier administrateur actif d'une application.

## Écrans fournis

| Module | Rôle |
|---|---|
| `ui.connexion.LoginDialog` | Connexion, avec changement de mot de passe imposé |
| `ui.mot_de_passe.ChangementMotDePasseDialog` | Changement volontaire ou imposé |
| `ui.utilisateur.UtilisateurDialog` | Création et modification, habilitations en tableau |
| `ui.historique.HistoriqueConnexionsTab` | Historique, filtres, export CSV |

Leur habillage se surcharge via `auth_partage.ui.theme`, pour qu'ils
s'accordent à la charte de l'application hôte.

## Bascule progressive

Tant que la base `OUTILS` n'est pas en place, une application peut
continuer sur sa propre base :

```python
auth_partage.utiliser_session_locale(ma_fabrique_de_session)
```

C'est ce qui permet de basculer **application par application** plutôt que
d'un seul coup, et de revenir en arrière si besoin.
