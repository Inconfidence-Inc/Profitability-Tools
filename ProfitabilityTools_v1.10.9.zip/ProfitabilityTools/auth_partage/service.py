from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field


from auth_partage import config
from auth_partage.database import get_auth_session
from auth_partage.entities import (
    EVT_ACCES_REFUSE, EVT_COMPTE_CREE, EVT_COMPTE_MODIFIE, EVT_COMPTE_SUPPRIME,
    EVT_CONNEXION_ECHEC, EVT_CONNEXION_OK, EVT_DECONNEXION, EVT_MDP_CHANGE,
    EVT_MDP_REINIT, SEPARATEUR_APPLICATIONS, SEPARATEUR_ROLE,
    UserPython, UserPythonHisto)
from auth_partage.securite import (hash_password, valider_mot_de_passe,
                                    verify_password)


# ------------------------------------------- Autorisations par application
def analyser_applications(valeur: str | None) -> dict[str, str]:
    """« ARGOS:Administrateur;PORTAIL:Lecteur » -> {app: rôle}.

    Tolérante : une entrée mal formée est ignorée plutôt que de faire
    échouer la lecture du compte. Cette colonne est destinée à être
    alimentée aussi par d'autres applications, éventuellement à la main :
    elle doit résister à une saisie approximative sans jamais bloquer une
    connexion légitime aux autres applications de la même ligne."""
    autorisations: dict[str, str] = {}
    for morceau in (valeur or "").split(SEPARATEUR_APPLICATIONS):
        morceau = morceau.strip()
        if not morceau:
            continue
        application, _, role = morceau.partition(SEPARATEUR_ROLE)
        application = application.strip().upper()
        if application:
            autorisations[application] = role.strip() or "Lecteur"
    return autorisations


def formater_applications(autorisations: dict[str, str]) -> str:
    return SEPARATEUR_APPLICATIONS.join(
        f"{app}{SEPARATEUR_ROLE}{role}" for app, role in sorted(autorisations.items()))


def _contexte_poste() -> tuple[str, str]:
    """(nom du poste, compte système) — enregistrés dans l'historique.

    « Qui s'est connecté » sans « depuis où » ne répond qu'à moitié à la
    question, surtout sur un outil partagé entre plusieurs agents."""
    import getpass
    import socket
    try:
        poste = socket.gethostname()
    except Exception:  # noqa: BLE001
        poste = ""
    try:
        compte = getpass.getuser()
    except Exception:  # noqa: BLE001
        compte = ""
    return poste[:80], compte[:80]


def tracer_evenement(login: str, evenement: str, detail: str = "",
                      application: str = "", role: str = ""):
    """Écrit une ligne dans USERS_PYTHON_HISTO.

    Ne lève jamais : l'historique ne doit pas empêcher une connexion. Un
    échec d'écriture est pire que silencieux s'il bloque l'utilisateur —
    il est donc absorbé, la trace applicative (app_log) restant par
    ailleurs alimentée."""
    # Résolu À L'APPEL, et non dans la signature : une valeur par défaut
    # est évaluée à l'import du module, avant que l'application ait eu le
    # temps de se déclarer. Le code applicatif partait alors vide dans
    # l'historique — des traces sans application, donc inexploitables.
    application = application or config.application()
    poste, compte_systeme = _contexte_poste()
    session = get_auth_session()
    try:
        session.add(UserPythonHisto(
            login=(login or "?")[:50], application=application[:30],
            evenement=evenement[:30], role=(role or "")[:30], poste=poste,
            utilisateur_systeme=compte_systeme, detail=(detail or "")[:255]))
        session.commit()
    except Exception:  # noqa: BLE001
        try:
            session.rollback()
        except Exception:  # noqa: BLE001
            pass


@dataclass
class CurrentUser:
    id: int
    login: str
    nom_complet: str
    role: str
    # Positionné à la création d'un compte et à toute réinitialisation par
    # un administrateur. Cette information était enregistrée en base depuis
    # l'origine mais n'était JAMAIS lue : un mot de passe provisoire, connu
    # de l'administrateur qui l'a saisi, restait donc valable indéfiniment.
    # C'est la fenêtre de connexion qui impose désormais le changement.
    doit_changer_mdp: bool = False
    # Horodatage de l'ouverture de CETTE session, distinct de
    # User.derniere_connexion enregistré en base : sur un poste partagé, la
    # question « depuis quand suis-je connecté ? » se pose pour la session
    # en cours, pas pour la dernière connexion historisée.
    connecte_depuis: dt.datetime | None = None
    # Rôle de l'agent dans CHAQUE application partageant USERS_PYTHON.
    # Argos n'utilise que le sien, mais l'exposer évite qu'une autre
    # application ait à relire la base pour le connaître.
    applications: dict = field(default_factory=dict)


# Motifs de refus, exposés par AuthService.dernier_motif_refus.
REFUS_IDENTIFIANTS = "identifiants"
REFUS_DESACTIVE = "desactive"
REFUS_NON_HABILITE = "non_habilite"


class AuthService:
    def authenticate(self, login: str, mot_de_passe: str) -> CurrentUser | None:
        """Authentifie un agent POUR CETTE APPLICATION.

        Trois refus distincts, tous tracés dans USERS_PYTHON_HISTO :
        identifiants faux, compte désactivé, et compte valide mais **non
        autorisé sur Argos**. Ce dernier cas est nouveau : la table étant
        partagée, un agent peut exister pour une autre application sans
        avoir accès à celle-ci. Le distinguer d'un mot de passe erroné est
        indispensable, sinon l'administrateur cherche un problème de mot de
        passe là où il manque une autorisation.

        Le message rendu à l'écran reste générique pour les deux premiers
        cas : préciser « ce login existe mais le mot de passe est faux »
        renseignerait un tiers sur l'existence du compte.
        """
        # Toute panne d'accès à la base centrale est traduite ici en
        # exception dédiée. Sans cela, l'erreur brute du pilote remontait
        # jusqu'à l'écran de connexion, où elle se présentait comme un
        # plantage — alors que le diagnostic « base injoignable » était
        # parfaitement identifiable.
        try:
            session = get_auth_session()
            utilisateur = session.query(UserPython).filter_by(login=login).first()
        except Exception as exception:  # noqa: BLE001
            # CORRECTIF (à remonter au paquet) : importait depuis
            # `models.auth_database`, module d'Argos, alors que
            # `auth_partage.database` expose EXACTEMENT ces deux noms.
            # Ce chemin ne s'exécute que lorsque la base est injoignable :
            # dans toute autre application, « base injoignable » devenait
            # un ModuleNotFoundError, masquant le diagnostic que le
            # commentaire ci-dessus dit pourtant identifiable.
            from auth_partage.database import (AuthentificationIndisponible,
                                                centralisee)
            if not centralisee():
                raise
            raise AuthentificationIndisponible(str(exception)) from exception

        if utilisateur is None or not verify_password(mot_de_passe,
                                                       utilisateur.mot_de_passe_hash):
            self.dernier_motif_refus = REFUS_IDENTIFIANTS
            tracer_evenement(login, EVT_CONNEXION_ECHEC,
                              "identifiant ou mot de passe incorrect")
            return None
        if not utilisateur.actif:
            self.dernier_motif_refus = REFUS_DESACTIVE
            tracer_evenement(login, EVT_CONNEXION_ECHEC, "compte désactivé")
            return None

        autorisations = analyser_applications(utilisateur.applications)
        role = autorisations.get(config.application())
        if role is None:
            # Motif exposé DIRECTEMENT plutôt que déduit en relisant
            # l'historique : cette relecture échouait dès que l'écriture de
            # la trace avait échoué, et l'utilisateur recevait alors un
            # « mot de passe incorrect » trompeur.
            self.dernier_motif_refus = REFUS_NON_HABILITE
            self.applications_du_compte = autorisations
            tracer_evenement(
                login, EVT_ACCES_REFUSE,
                f"compte valide mais non autorisé sur {config.application()} "
                f"(applications : {', '.join(sorted(autorisations)) or 'aucune'})")
            return None

        utilisateur.derniere_connexion = dt.datetime.now()
        session.commit()
        tracer_evenement(login, EVT_CONNEXION_OK,
                          f"connexion à {config.application()}", role=role)

        return CurrentUser(
            id=utilisateur.id, login=utilisateur.login,
            nom_complet=f"{utilisateur.prenom or ''} {utilisateur.nom or ''}".strip(),
            role=role,
            doit_changer_mdp=bool(utilisateur.doit_changer_mdp),
            connecte_depuis=dt.datetime.now(),
            applications=autorisations,
        )

    @staticmethod
    def role_dans_application(utilisateur, application: str = ""):
        return analyser_applications(utilisateur.applications).get(
            application or config.application())

    @staticmethod
    def applications_declarees() -> list[str]:
        """Codes d'application rencontrés dans la table partagée, plus celui
        d'Argos. Les autres applications déclarant leurs comptes ici, leurs
        codes apparaissent d'eux-mêmes : aucune liste à tenir à jour."""
        session = get_auth_session()
        codes = {config.application()}
        for (valeur,) in session.query(UserPython.applications).all():
            codes |= set(analyser_applications(valeur))
        return sorted(codes)

    def historique(self, login: str = "", application: str = "",
                    evenement: str = "", limite: int = 500) -> list:
        """Lignes de USERS_PYTHON_HISTO, les plus récentes d'abord."""
        session = get_auth_session()
        q = session.query(UserPythonHisto)
        if login:
            q = q.filter(UserPythonHisto.login == login)
        if application:
            q = q.filter(UserPythonHisto.application == application)
        if evenement:
            q = q.filter(UserPythonHisto.evenement == evenement)
        return q.order_by(UserPythonHisto.horodatage.desc()).limit(limite).all()

    def tracer_deconnexion(self, login: str, detail: str = ""):
        tracer_evenement(login, EVT_DECONNEXION, detail)

    def list_users(self, application: str = "") -> list:
        """Comptes de la table partagée.

        `application` filtre sur ceux autorisés sur une application donnée ;
        chaîne vide = TOUS les comptes, y compris ceux qui ne relèvent pas
        d'Argos. Les administrateurs d'Argos gèrent en effet une table
        commune : leur cacher l'existence des autres comptes les ferait
        recréer des logins déjà pris, et l'unicité les rejetterait sans
        qu'ils comprennent pourquoi."""
        application = config.application() if application is None else application
        session = get_auth_session()
        comptes = session.query(UserPython).order_by(UserPython.login).all()
        if not application:
            return comptes
        return [c for c in comptes
                if application in analyser_applications(c.applications)]

    def list_roles(self) -> list[str]:
        """Rôles connus de cette application, dans l'ordre déclaré."""
        return list(config.permissions())

    @property
    def ROLE_ADMINISTRATEUR(self) -> str:
        """Rôle habilité à administrer les comptes DE CETTE application."""
        return config.role_administrateur()

    def _nb_administrateurs_actifs(self, sauf_id: int | None = None) -> int:
        """Administrateurs ACTIFS **d'Argos**, en excluant éventuellement le
        compte qu'on s'apprête à modifier.

        Le décompte porte sur cette application seule : un administrateur
        d'une autre application ne pourrait pas administrer Argos, et le
        compter ici laisserait croire à tort qu'il reste quelqu'un aux
        commandes."""
        total = 0
        for compte in self.list_users(config.application()):
            if sauf_id is not None and compte.id == sauf_id:
                continue
            if compte.actif and analyser_applications(
                    compte.applications).get(config.application()) == self.ROLE_ADMINISTRATEUR:
                total += 1
        return total

    def create_user(self, login, nom, prenom, email, role_code, mot_de_passe,
                     applications: dict | None = None,
                     cree_par: str = "", commentaire: str = "") -> tuple[bool, str]:
        """Crée un compte dans la table partagée.

        `applications` permet d'ouvrir d'emblée plusieurs applications ;
        par défaut, seul Argos avec le rôle demandé — un compte créé
        depuis Argos n'ouvre aucun droit ailleurs sans geste explicite."""
        session = get_auth_session()
        login = (login or "").strip()
        if not login:
            return False, "Le login est obligatoire."
        if session.query(UserPython).filter_by(login=login).first():
            return False, (f"Le login « {login} » existe déjà dans USERS_PYTHON "
                            f"(table partagée entre applications).")
        probleme = valider_mot_de_passe(mot_de_passe or "")
        if probleme:
            return False, probleme

        # Si l'appelant fournit explicitement des autorisations, elles font
        # FOI : ajouter Argos d'office donnerait un accès que personne n'a
        # demandé. Ce n'est qu'en l'absence d'indication que le compte est
        # créé pour l'application courante, avec le rôle choisi.
        autorisations = dict(applications) if applications else {
            config.application(): role_code}
        if not analyser_applications(formater_applications(autorisations)):
            return False, "Aucune application autorisée : le compte serait inutilisable."

        session.add(UserPython(
            login=login, mot_de_passe_hash=hash_password(mot_de_passe),
            nom=nom, prenom=prenom, email=email,
            applications=formater_applications(autorisations),
            actif=True, doit_changer_mdp=True, cree_par=cree_par or "",
            commentaire=commentaire or ""))
        session.commit()
        tracer_evenement(login, EVT_COMPTE_CREE,
                          f"créé par {cree_par or '?'} — "
                          f"{formater_applications(autorisations)}")
        return True, (f"Utilisateur « {login} » créé "
                       f"({formater_applications(autorisations)}).")

    def set_active(self, user_id: int, actif: bool) -> tuple[bool, str]:
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."
        role = self.role_dans_application(compte)
        if (not actif and role == self.ROLE_ADMINISTRATEUR
                and self._nb_administrateurs_actifs(sauf_id=user_id) == 0):
            return False, ("Impossible de désactiver le dernier administrateur actif "
                            "d'Argos : plus personne ne pourrait administrer "
                            "l'application.")
        compte.actif = actif
        session.commit()
        tracer_evenement(compte.login, EVT_COMPTE_MODIFIE,
                          "activé" if actif else "désactivé")
        return True, f"Utilisateur « {compte.login} » {'activé' if actif else 'désactivé'}."

    def changer_role(self, user_id: int, role_code: str,
                      application: str = "") -> tuple[bool, str]:
        """Change le rôle d'un compte SUR UNE APPLICATION, sans toucher à
        ses droits sur les autres."""
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."
        autorisations = analyser_applications(compte.applications)
        ancien = autorisations.get(application)
        if (application == config.application() and ancien == self.ROLE_ADMINISTRATEUR
                and role_code != self.ROLE_ADMINISTRATEUR
                and self._nb_administrateurs_actifs(sauf_id=user_id) == 0):
            return False, ("Impossible de retirer le rôle Administrateur au dernier "
                            "administrateur actif d'Argos.")
        autorisations[application] = role_code
        compte.applications = formater_applications(autorisations)
        session.commit()
        tracer_evenement(compte.login, EVT_COMPTE_MODIFIE,
                          f"{application} : {ancien or 'aucun'} -> {role_code}")
        return True, (f"« {compte.login} » : sur {application}, "
                       f"{ancien or 'aucun accès'} -> {role_code}.")

    def definir_applications(self, user_id: int,
                              autorisations: dict) -> tuple[bool, str]:
        """Remplace l'ensemble des autorisations d'un compte."""
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."
        if (analyser_applications(compte.applications).get(config.application())
                == self.ROLE_ADMINISTRATEUR
                and autorisations.get(config.application()) != self.ROLE_ADMINISTRATEUR
                and self._nb_administrateurs_actifs(sauf_id=user_id) == 0):
            return False, ("Impossible : ce compte est le dernier administrateur "
                            "actif d'Argos.")
        if not autorisations:
            return False, "Aucune application autorisée : le compte serait inutilisable."
        compte.applications = formater_applications(autorisations)
        session.commit()
        tracer_evenement(compte.login, EVT_COMPTE_MODIFIE,
                          f"applications -> {compte.applications}")
        return True, f"Applications de « {compte.login} » : {compte.applications}"

    def modifier_utilisateur(self, user_id: int, nom: str = None, prenom: str = None,
                              email: str = None, commentaire: str = None,
                              actif: bool = None,
                              applications: dict = None) -> tuple[bool, str]:
        """Met à jour un compte. Seuls les champs fournis sont touchés.

        Le login n'est volontairement PAS modifiable : l'historique des
        connexions le référence — dans toutes les applications — et non
        l'identifiant technique. Le changer romprait le lien avec les
        traces déjà écrites, sans moyen de le rétablir.

        Les mêmes garde-fous que partout ailleurs s'appliquent : on ne peut
        pas désactiver ni déshabiliter le dernier administrateur actif
        d'Argos, fût-ce en passant par cette boîte plutôt que par les
        boutons dédiés."""
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."

        etait_admin = (analyser_applications(compte.applications).get(config.application())
                       == self.ROLE_ADMINISTRATEUR) and compte.actif
        restera_admin = True
        if applications is not None:
            restera_admin = (applications.get(config.application())
                             == self.ROLE_ADMINISTRATEUR)
        if actif is not None:
            restera_admin = restera_admin and actif
        if (etait_admin and not restera_admin
                and self._nb_administrateurs_actifs(sauf_id=user_id) == 0):
            return False, ("Impossible : ce compte est le dernier administrateur "
                            "actif d'Argos. Nommez d'abord un autre administrateur.")

        changements = []
        for champ, valeur in (("nom", nom), ("prenom", prenom), ("email", email),
                               ("commentaire", commentaire)):
            if valeur is not None and getattr(compte, champ) != valeur:
                setattr(compte, champ, valeur)
                changements.append(champ)
        if actif is not None and bool(compte.actif) != bool(actif):
            compte.actif = bool(actif)
            changements.append("actif" if actif else "désactivé")
        if applications is not None:
            nouvelles = formater_applications(applications)
            if nouvelles != (compte.applications or ""):
                compte.applications = nouvelles
                changements.append(f"habilitations -> {nouvelles}")
        if not changements:
            return True, "Aucune modification."
        session.commit()
        tracer_evenement(compte.login, EVT_COMPTE_MODIFIE, ", ".join(changements))
        return True, (f"« {compte.login} » mis à jour : "
                       + ", ".join(changements) + ".")

    def supprimer_utilisateur(self, user_id: int, demandeur_id: int) -> tuple[bool, str]:
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."
        if compte.id == demandeur_id:
            return False, ("Vous ne pouvez pas supprimer votre propre compte. "
                            "Demandez à un autre administrateur de le faire.")
        if (self.role_dans_application(compte) == self.ROLE_ADMINISTRATEUR
                and self._nb_administrateurs_actifs(sauf_id=user_id) == 0):
            return False, "Impossible de supprimer le dernier administrateur actif."
        autres = {a: r for a, r in analyser_applications(compte.applications).items()
                  if a != config.application()}
        login = compte.login
        if autres:
            # La table est partagée : supprimer la ligne priverait l'agent
            # de ses accès aux AUTRES applications, dont Argos n'a pas à
            # décider. On ne retire donc que l'autorisation Argos.
            compte.applications = formater_applications(autres)
            session.commit()
            tracer_evenement(login, EVT_COMPTE_MODIFIE,
                              f"accès {config.application()} retiré ; conserve {compte.applications}")
            return True, (f"Accès Argos retiré à « {login} ». Le compte est CONSERVÉ : "
                           f"il reste autorisé sur {', '.join(sorted(autres))}.")
        session.delete(compte)
        session.commit()
        tracer_evenement(login, EVT_COMPTE_SUPPRIME, "compte supprimé de USERS_PYTHON")
        return True, f"Utilisateur « {login} » supprimé."

    def reset_password(self, user_id: int, nouveau_mdp: str) -> tuple[bool, str]:
        """Réinitialisation par un administrateur : le mot de passe est
        PROVISOIRE, l'utilisateur devra le changer à sa prochaine
        connexion."""
        probleme = valider_mot_de_passe(nouveau_mdp or "")
        if probleme:
            return False, probleme
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."
        compte.mot_de_passe_hash = hash_password(nouveau_mdp)
        compte.doit_changer_mdp = True
        session.commit()
        tracer_evenement(compte.login, EVT_MDP_REINIT, "réinitialisé par un administrateur")
        return True, (f"Mot de passe de « {compte.login} » réinitialisé. "
                       "Il devra le changer à sa prochaine connexion.")

    def changer_mon_mot_de_passe(self, user_id: int, ancien: str,
                                  nouveau: str) -> tuple[bool, str]:
        session = get_auth_session()
        compte = session.get(UserPython, user_id)
        if compte is None:
            return False, "Utilisateur introuvable."
        if not verify_password(ancien, compte.mot_de_passe_hash):
            return False, "Le mot de passe actuel est incorrect."
        if ancien == nouveau:
            return False, "Le nouveau mot de passe doit être différent de l'ancien."
        probleme = valider_mot_de_passe(nouveau or "")
        if probleme:
            return False, probleme
        compte.mot_de_passe_hash = hash_password(nouveau)
        compte.doit_changer_mdp = False
        session.commit()
        tracer_evenement(compte.login, EVT_MDP_CHANGE, "changé par l'utilisateur")
        return True, "Mot de passe modifié."

    # Droits attachés à chaque rôle, POUR CETTE APPLICATION. La table
    # USERS_PYTHON étant partagée, le même code de rôle peut recouvrir des
    # droits différents ailleurs : chaque application définit les siens.
    @property
    def PERMISSIONS(self) -> dict:
        """Droits ouverts par chaque rôle DANS CETTE application.

        Déclarés par l'application hôte : le même code de rôle n'ouvre pas
        les mêmes écrans d'une application à l'autre. Le module dit quel
        rôle l'agent porte ; ce que ce rôle autorise ne le regarde pas."""
        return config.permissions()

    # Libellé lisible de chaque droit, pour que l'administrateur qui
    # attribue un rôle voie ce qu'il accorde au lieu de deviner.
    # Libellés lisibles des droits, renseignés par l'application hôte via
    # auth_partage.configurer(libelles_permissions=...). Sans eux, le code
    # technique du droit est affiché tel quel.
    LIBELLES_PERMISSIONS: dict = {}

    def can(self, role: str, permission: str) -> bool:
        return permission in self.PERMISSIONS.get(role, set())

    def description_role(self, role: str) -> str:
        """Description en clair des droits d'un rôle, affichée dans l'IHM."""
        droits = self.PERMISSIONS.get(role)
        if not droits:
            return "Rôle inconnu — aucun droit."
        ordonnes = [self.LIBELLES_PERMISSIONS.get(d, d)
                     for d in self.LIBELLES_PERMISSIONS if d in droits]
        return " · ".join(ordonnes)
