"""Création et modification d'un compte, habilitations comprises.

Remplace deux saisies libres qui demandaient à l'administrateur de
connaître une syntaxe : un champ texte « ARGOS:Administrateur;PORTAIL:
Lecteur » à la création, et une boîte de dialogue à une ligne pour la
modification. Une virgule à la place d'un point-virgule, un rôle mal
orthographié, et l'habilitation partait en silence — la chaîne étant
analysée avec tolérance, une entrée fautive était simplement ignorée.

Le tableau ci-dessous rend la même information saisissable sans syntaxe :
une ligne par application, le rôle choisi dans une liste. Le format
texte reste ce qui est stocké en base, mais plus personne n'a à le taper.

La même boîte sert à la création et à la modification. C'est délibéré :
deux écrans séparés divergent toujours, et l'un finit par offrir un champ
que l'autre ignore — exactement ce qui s'était produit entre le formulaire
de connexion métier et celui de la base OUTILS.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLineEdit, QLabel,
    QPushButton, QTableWidget, QTableWidgetItem, QComboBox, QCheckBox,
    QMessageBox, QHeaderView, QAbstractItemView, QGroupBox,
)

from auth_partage.config import longueur_minimale_mot_de_passe
from auth_partage.service import AuthService, analyser_applications
from auth_partage.config import application as _application
from auth_partage.ui.theme import TEXTE_SECONDAIRE, marquer_action_principale


class UtilisateurDialog(QDialog):
    """Boîte de création (compte=None) ou de modification d'un compte."""

    def __init__(self, compte=None, parent=None):
        super().__init__(parent)
        self.auth = AuthService()
        self.compte = compte
        self.creation = compte is None
        self.setWindowTitle("Créer un utilisateur" if self.creation
                             else f"Modifier « {compte.login} »")
        self.setModal(True)
        self.resize(640, 560)

        layout = QVBoxLayout(self)

        # ---------------------------------------------------- Identité
        identite = QGroupBox("Identité")
        form = QFormLayout(identite)
        self.edit_login = QLineEdit()
        self.edit_nom = QLineEdit()
        self.edit_prenom = QLineEdit()
        self.edit_email = QLineEdit()
        self.edit_commentaire = QLineEdit()
        self.edit_commentaire.setPlaceholderText("service, fonction, motif du compte…")
        form.addRow("Login", self.edit_login)
        form.addRow("Nom", self.edit_nom)
        form.addRow("Prénom", self.edit_prenom)
        form.addRow("E-mail", self.edit_email)
        form.addRow("Commentaire", self.edit_commentaire)

        self.case_actif = QCheckBox("Compte actif")
        self.case_actif.setChecked(True)
        if not self.creation:
            form.addRow("", self.case_actif)
        layout.addWidget(identite)

        # ----------------------------------------------- Habilitations
        habilitations = QGroupBox("Applications autorisées et rôle dans chacune")
        bloc = QVBoxLayout(habilitations)
        explication = QLabel(
            "Un agent peut avoir un rôle <b>différent selon l'application</b> : "
            "administrateur ici, simple lecteur ailleurs. Il ne pourra se "
            "connecter qu'aux applications listées ci-dessous.")
        explication.setWordWrap(True)
        explication.setStyleSheet(f"color: {TEXTE_SECONDAIRE};")
        bloc.addWidget(explication)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Application", "Rôle"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumHeight(150)
        bloc.addWidget(self.table)

        boutons_table = QHBoxLayout()
        btn_ajouter = QPushButton("Ajouter une application")
        btn_ajouter.clicked.connect(lambda: self._ajouter_ligne())
        btn_retirer = QPushButton("Retirer la ligne sélectionnée")
        btn_retirer.clicked.connect(self._retirer_ligne)
        boutons_table.addWidget(btn_ajouter)
        boutons_table.addWidget(btn_retirer)
        boutons_table.addStretch()
        bloc.addLayout(boutons_table)
        layout.addWidget(habilitations)

        # ------------------------------------------------ Mot de passe
        if self.creation:
            mdp_bloc = QGroupBox("Mot de passe provisoire")
            form_mdp = QFormLayout(mdp_bloc)
            self.edit_mdp = QLineEdit()
            self.edit_mdp.setEchoMode(QLineEdit.Password)
            self.edit_mdp.setPlaceholderText(
                f"au moins {longueur_minimale_mot_de_passe()} caractères, "
                "une lettre et un chiffre")
            form_mdp.addRow("Mot de passe", self.edit_mdp)
            note = QLabel("L'utilisateur devra le remplacer dès sa première "
                           "connexion, sur chaque application.")
            note.setWordWrap(True)
            note.setStyleSheet(f"color: {TEXTE_SECONDAIRE};")
            form_mdp.addRow("", note)
            layout.addWidget(mdp_bloc)

        # ----------------------------------------------------- Boutons
        pied = QHBoxLayout()
        pied.addStretch()
        annuler = QPushButton("Annuler")
        annuler.clicked.connect(self.reject)
        pied.addWidget(annuler)
        self.btn_valider = QPushButton("Créer" if self.creation else "Enregistrer")
        marquer_action_principale(self.btn_valider)
        self.btn_valider.clicked.connect(self._valider)
        pied.addWidget(self.btn_valider)
        layout.addLayout(pied)

        self._precharger()

    # ------------------------------------------------------------ Contenu
    def _codes_applications(self) -> list[str]:
        try:
            return self.auth.applications_declarees()
        except Exception:  # noqa: BLE001
            return [_application()]

    def _codes_roles(self) -> list[str]:
        try:
            codes = [r.code for r in self.auth.list_roles()]
        except Exception:  # noqa: BLE001
            codes = []
        return codes or sorted(self.auth.PERMISSIONS)

    def _ajouter_ligne(self, application: str = "", role: str = ""):
        rang = self.table.rowCount()
        self.table.insertRow(rang)

        combo_app = QComboBox()
        combo_app.setEditable(True)   # un code d'application nouveau reste saisissable
        combo_app.addItems(self._codes_applications())
        combo_app.setCurrentText(application or _application())
        combo_app.setToolTip(
            "Code de l'application. Les codes déjà rencontrés sont proposés ; "
            "un nouveau peut être saisi directement — les autres applications "
            "se déclarent elles-mêmes dans la table partagée.")
        self.table.setCellWidget(rang, 0, combo_app)

        combo_role = QComboBox()
        roles = self._codes_roles()
        combo_role.addItems(roles)
        combo_role.setCurrentText(role or roles[0])
        combo_role.setToolTip(
            "Rôle de l'agent DANS CETTE APPLICATION. Chaque application "
            "définit ce que ses rôles autorisent.")
        self.table.setCellWidget(rang, 1, combo_role)

    def _retirer_ligne(self):
        rang = self.table.currentRow()
        if rang >= 0:
            self.table.removeRow(rang)

    def _precharger(self):
        if self.creation:
            self._ajouter_ligne(_application(), "Lecteur")
            return
        self.edit_login.setText(self.compte.login)
        # Le login identifie le compte dans toutes les applications et dans
        # tout l'historique : le modifier romprait le lien avec les traces
        # déjà écrites, qui référencent le login et non l'identifiant
        # technique.
        self.edit_login.setReadOnly(True)
        self.edit_login.setToolTip(
            "Le login ne peut pas être modifié : l'historique des connexions "
            "y fait référence, dans toutes les applications.")
        self.edit_nom.setText(self.compte.nom or "")
        self.edit_prenom.setText(self.compte.prenom or "")
        self.edit_email.setText(self.compte.email or "")
        self.edit_commentaire.setText(self.compte.commentaire or "")
        self.case_actif.setChecked(bool(self.compte.actif))
        for application, role in sorted(
                analyser_applications(self.compte.applications).items()):
            self._ajouter_ligne(application, role)

    def habilitations(self) -> dict:
        resultat = {}
        for rang in range(self.table.rowCount()):
            application = self.table.cellWidget(rang, 0).currentText().strip().upper()
            role = self.table.cellWidget(rang, 1).currentText().strip()
            if application:
                resultat[application] = role or "Lecteur"
        return resultat

    # ----------------------------------------------------------- Validation
    def _valider(self):
        habilitations = self.habilitations()
        if not habilitations:
            QMessageBox.warning(
                self, "Aucune habilitation",
                "Ajoutez au moins une application : sans habilitation, ce compte "
                "ne pourrait se connecter nulle part.")
            return

        if self.creation:
            ok, message = self.auth.create_user(
                self.edit_login.text().strip(), self.edit_nom.text().strip(),
                self.edit_prenom.text().strip(), self.edit_email.text().strip(),
                "", self.edit_mdp.text(), applications=habilitations,
                cree_par=getattr(self.parent(), "current_user", None)
                and self.parent().current_user.login or "",
                commentaire=self.edit_commentaire.text().strip())
        else:
            ok, message = self.auth.modifier_utilisateur(
                self.compte.id, nom=self.edit_nom.text().strip(),
                prenom=self.edit_prenom.text().strip(),
                email=self.edit_email.text().strip(),
                commentaire=self.edit_commentaire.text().strip(),
                actif=self.case_actif.isChecked(),
                applications=habilitations)

        self.message = message
        if not ok:
            QMessageBox.warning(self, "Opération refusée", message)
            return
        self.accept()
