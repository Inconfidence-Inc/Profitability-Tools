"""Habillage minimal des boîtes du module.

L'application hôte peut remplacer ces valeurs pour que les écrans
d'authentification s'accordent à sa propre charte — sans quoi trois boîtes
au style étranger apparaîtraient au milieu de son interface.

    from auth_partage.ui import theme
    theme.TEXTE_SECONDAIRE = "#61708A"
    theme.marquer_action_principale = ma_fonction
"""
from __future__ import annotations

TEXTE_SECONDAIRE = "#61708A"


def marquer_action_principale(bouton):
    """Met en valeur le bouton d'action principale d'une boîte.

    Implémentation neutre par défaut : le module ne présume pas de la
    feuille de style de l'application hôte."""
    bouton.setDefault(True)
