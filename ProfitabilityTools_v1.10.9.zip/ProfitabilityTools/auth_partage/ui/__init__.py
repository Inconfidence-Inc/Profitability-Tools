"""Boîtes de dialogue PySide6 du module d'authentification."""
