"""Boîte de changement de mot de passe, utilisée dans deux situations :

- **imposée** à la connexion, quand le compte porte l'indicateur
  « doit changer son mot de passe » (compte créé par un administrateur, ou
  mot de passe réinitialisé). Cet indicateur était enregistré en base
  depuis l'origine mais n'était jamais lu : un mot de passe provisoire,
  connu de l'administrateur qui l'a saisi, restait valable indéfiniment ;
- **volontaire**, depuis le bouton « Mon compte » de la fenêtre
  principale. Ce bouton est accessible à TOUS les rôles : la gestion des
  utilisateurs vit dans l'onglet Administration, réservé aux
  administrateurs, si bien qu'un Lecteur n'avait aucun moyen de changer
  son propre mot de passe.

Dans le cas imposé, la boîte ne peut pas être annulée : la refuser revient
à ne pas se connecter.
"""
from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QLabel,
    QHBoxLayout, QMessageBox,
)

from auth_partage.config import longueur_minimale_mot_de_passe
from auth_partage.service import AuthService
from auth_partage.ui.theme import TEXTE_SECONDAIRE, marquer_action_principale


class ChangementMotDePasseDialog(QDialog):
    def __init__(self, utilisateur, impose: bool = False, parent=None):
        super().__init__(parent)
        self.utilisateur = utilisateur
        self.impose = impose
        self.auth = AuthService()
        self.setWindowTitle("Changer mon mot de passe")
        self.setModal(True)
        self.resize(430, 240)

        layout = QVBoxLayout(self)
        if impose:
            entete = QLabel(
                "<b>Vous devez choisir un nouveau mot de passe</b><br>"
                "Ce compte utilise un mot de passe provisoire, défini par un "
                "administrateur. Il doit être remplacé avant d'accéder à l'application.")
        else:
            entete = QLabel(f"<b>Compte {utilisateur.login}</b>")
        entete.setWordWrap(True)
        layout.addWidget(entete)

        form = QFormLayout()
        self.edit_actuel = QLineEdit()
        self.edit_actuel.setEchoMode(QLineEdit.Password)
        self.edit_nouveau = QLineEdit()
        self.edit_nouveau.setEchoMode(QLineEdit.Password)
        self.edit_confirmation = QLineEdit()
        self.edit_confirmation.setEchoMode(QLineEdit.Password)
        self.edit_confirmation.returnPressed.connect(self._valider)
        form.addRow("Mot de passe actuel", self.edit_actuel)
        form.addRow("Nouveau mot de passe", self.edit_nouveau)
        form.addRow("Confirmation", self.edit_confirmation)
        layout.addLayout(form)

        regle = QLabel(f"Au moins {longueur_minimale_mot_de_passe()} caractères, "
                        "dont une lettre et un chiffre.")
        regle.setStyleSheet(f"color: {TEXTE_SECONDAIRE}; font-style: italic;")
        layout.addWidget(regle)

        boutons = QHBoxLayout()
        boutons.addStretch()
        if not impose:
            annuler = QPushButton("Annuler")
            annuler.clicked.connect(self.reject)
            boutons.addWidget(annuler)
        self.btn_valider = QPushButton("Valider")
        marquer_action_principale(self.btn_valider)
        self.btn_valider.clicked.connect(self._valider)
        boutons.addWidget(self.btn_valider)
        layout.addLayout(boutons)

    def _valider(self):
        if self.edit_nouveau.text() != self.edit_confirmation.text():
            QMessageBox.warning(self, "Confirmation", "Les deux saisies diffèrent.")
            return
        ok, message = self.auth.changer_mon_mot_de_passe(
            self.utilisateur.id, self.edit_actuel.text(), self.edit_nouveau.text())
        if not ok:
            QMessageBox.warning(self, "Mot de passe refusé", message)
            return

        self.utilisateur.doit_changer_mdp = False
        QMessageBox.information(self, "Mot de passe modifié", message)
        self.accept()

    def reject(self):
        """Un changement imposé ne peut pas être contourné en fermant la
        fenêtre : la refuser équivaut à renoncer à se connecter."""
        if self.impose:
            return
        super().reject()
