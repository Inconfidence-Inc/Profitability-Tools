"""Vue « Historique des connexions » — lecture de USERS_PYTHON_HISTO.

Distincte du journal des actions (`app_log`, onglet Logs), et pour une
raison de fond : `app_log` trace ce que fait l'application ; cette table-ci
trace **qui accède aux applications**, et elle est PARTAGÉE entre elles.
Un administrateur d'Argos y voit aussi les connexions aux autres
applications déclarées dans USERS_PYTHON, ce qui est le but : savoir
quel agent se connecte à quoi, et quand.

Les échecs y figurent au même titre que les succès. C'est même leur
principal intérêt : une série de « CONNEXION_ECHEC » sur un même login, ou
un « ACCES_REFUSE » répété, est exactement ce qu'on cherche à repérer. Ils
sont donc mis en évidence par la couleur plutôt que noyés dans la liste.
"""
from __future__ import annotations

import datetime as dt

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QComboBox, QPushButton, QHeaderView, QAbstractItemView, QLineEdit,
    QSpinBox, QMessageBox,
)

from auth_partage.service import AuthService
from auth_partage.entities import (
    EVT_ACCES_REFUSE, EVT_CONNEXION_ECHEC, EVT_CONNEXION_OK, EVT_DECONNEXION,
    EVT_MDP_CHANGE, EVT_MDP_REINIT, EVT_COMPTE_CREE, EVT_COMPTE_MODIFIE,
    EVT_COMPTE_SUPPRIME,
)

# Événements signalant un problème d'accès : mis en évidence.
EVENEMENTS_ALERTE = {EVT_CONNEXION_ECHEC, EVT_ACCES_REFUSE}
COULEUR_ALERTE = "#FBE3E3"
COULEUR_CONNEXION = "#E8F4EA"


class HistoriqueConnexionsTab(QWidget):
    # Fonction d'export propre à l'application hôte, si elle en a une :
    # reçoit la liste des lignes et retourne le chemin produit.
    exporter = None

    def __init__(self, current_user, parent=None):
        super().__init__(parent)
        self.current_user = current_user
        self.auth = AuthService()

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>Historique des connexions</h2>"))
        explication = QLabel(
            "Table <b>USERS_PYTHON_HISTO</b>, partagée entre toutes les applications "
            "qui utilisent les comptes communs. Les tentatives <b>échouées</b> et les "
            "<b>accès refusés</b> y figurent au même titre que les connexions "
            "réussies — c'est ce qui permet de repérer un compte sous pression ou une "
            "autorisation manquante.")
        explication.setWordWrap(True)
        layout.addWidget(explication)

        filtres = QHBoxLayout()
        filtres.addWidget(QLabel("Login"))
        self.edit_login = QLineEdit()
        self.edit_login.setPlaceholderText("tous")
        self.edit_login.returnPressed.connect(self._refresh)
        filtres.addWidget(self.edit_login)

        filtres.addWidget(QLabel("Application"))
        self.combo_application = QComboBox()
        filtres.addWidget(self.combo_application)

        filtres.addWidget(QLabel("Événement"))
        self.combo_evenement = QComboBox()
        self.combo_evenement.addItem("Tous", "")
        for evenement in (EVT_CONNEXION_OK, EVT_CONNEXION_ECHEC, EVT_ACCES_REFUSE,
                           EVT_DECONNEXION, EVT_MDP_CHANGE, EVT_MDP_REINIT,
                           EVT_COMPTE_CREE, EVT_COMPTE_MODIFIE, EVT_COMPTE_SUPPRIME):
            self.combo_evenement.addItem(evenement, evenement)
        filtres.addWidget(self.combo_evenement)

        filtres.addWidget(QLabel("Lignes"))
        self.spin_limite = QSpinBox()
        self.spin_limite.setRange(50, 10000)
        self.spin_limite.setSingleStep(50)
        self.spin_limite.setValue(500)
        self.spin_limite.setToolTip(
            "Nombre maximal de lignes rapatriées. Cette table grossit à chaque "
            "connexion de chaque agent : on ne la charge jamais entièrement.")
        filtres.addWidget(self.spin_limite)

        self.btn_refresh = QPushButton("Rafraîchir")
        self.btn_refresh.clicked.connect(self._refresh)
        filtres.addWidget(self.btn_refresh)
        self.btn_export = QPushButton("Exporter Excel")
        self.btn_export.clicked.connect(self._export)
        filtres.addWidget(self.btn_export)
        filtres.addStretch()
        layout.addLayout(filtres)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["Horodatage", "Login", "Application", "Rôle endossé", "Événement",
             "Poste", "Compte Windows", "Détail"])
        for colonne in range(7):
            self.table.horizontalHeader().setSectionResizeMode(
                colonne, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        layout.addWidget(self.table)

        self.label_resume = QLabel()
        self.label_resume.setStyleSheet("color: #61708A;")
        layout.addWidget(self.label_resume)

        self._lignes: list[dict] = []
        self._remplir_applications()
        self._refresh()

    def _remplir_applications(self):
        """Liste des applications déclarées dans la table partagée.

        Tolérante à l'échec : cet onglet ne doit jamais empêcher la fenêtre
        principale de s'ouvrir. Une table absente — base pas encore migrée,
        base d'authentification centrale injoignable — faisait tomber la
        construction entière, donc l'application, pour un simple
        remplissage de liste déroulante."""
        courant = self.combo_application.currentData()
        self.combo_application.clear()
        self.combo_application.addItem("Toutes", "")
        try:
            codes = self.auth.applications_declarees()
        except Exception:  # noqa: BLE001
            codes = []
        for code in codes:
            self.combo_application.addItem(code, code)
        if courant:
            index = self.combo_application.findData(courant)
            if index >= 0:
                self.combo_application.setCurrentIndex(index)

    def _refresh(self):
        try:
            lignes = self._lire_historique()
        except Exception as exception:  # noqa: BLE001
            self.table.setRowCount(0)
            self._lignes = []
            self.label_resume.setText(
                f"Historique indisponible : {exception}"[:300])
            return
        self._afficher(lignes)

    def _lire_historique(self):
        return self.auth.historique(
            login=self.edit_login.text().strip(),
            application=self.combo_application.currentData() or "",
            evenement=self.combo_evenement.currentData() or "",
            limite=self.spin_limite.value())

    def _afficher(self, lignes):
        self._lignes = [{
            "Horodatage": h.horodatage.strftime("%d/%m/%Y %H:%M:%S") if h.horodatage else "",
            "Login": h.login, "Application": h.application,
            # Le rôle endossé POUR CETTE connexion : un même agent peut être
            # administrateur ici et lecteur ailleurs, et c'est ce que le
            # contrôle cherche à retrouver.
            "Rôle endossé": h.role or "",
            "Événement": h.evenement,
            "Poste": h.poste or "", "Compte Windows": h.utilisateur_systeme or "",
            "Détail": h.detail or "",
        } for h in lignes]

        self.table.setRowCount(len(lignes))
        for rang, h in enumerate(lignes):
            valeurs = list(self._lignes[rang].values())
            for colonne, valeur in enumerate(valeurs):
                item = QTableWidgetItem(valeur)
                if h.evenement in EVENEMENTS_ALERTE:
                    item.setBackground(QColor(COULEUR_ALERTE))
                elif h.evenement == EVT_CONNEXION_OK:
                    item.setBackground(QColor(COULEUR_CONNEXION))
                self.table.setItem(rang, colonne, item)

        echecs = sum(1 for h in lignes if h.evenement in EVENEMENTS_ALERTE)
        self.label_resume.setText(
            f"{len(lignes)} ligne(s) affichée(s), dont {echecs} tentative(s) "
            f"en échec ou accès refusé."
            + ("  Limite atteinte : affinez les filtres pour voir plus ancien."
               if len(lignes) >= self.spin_limite.value() else ""))

    def _export(self):
        """Export CSV, volontairement sans dépendance à l'application hôte.

        La version d'Argos passait par son service d'export Excel. Le module
        doit rester utilisable par une application qui n'en possède pas :
        un CSV en UTF-8 avec BOM s'ouvre directement dans Excel, et
        n'ajoute aucune dépendance.

        Une application disposant de son propre export peut remplacer
        `exporter` (voir l'attribut de classe) pour produire son format
        habituel.
        """
        import csv
        import datetime as dt
        import os
        from PySide6.QtWidgets import QFileDialog

        if not self._lignes:
            QMessageBox.information(self, "Export", "Aucune ligne à exporter.")
            return
        if self.exporter is not None:
            chemin = self.exporter(self._lignes)
        else:
            defaut = os.path.join(
                os.path.expanduser("~"),
                f"historique_connexions_{dt.datetime.now():%Y%m%d_%H%M%S}.csv")
            chemin, _ = QFileDialog.getSaveFileName(
                self, "Exporter l'historique", defaut, "CSV (*.csv)")
            if not chemin:
                return
            # utf-8-sig : le BOM fait reconnaître l'encodage par Excel, qui
            # sinon affiche les accents en caractères parasites.
            with open(chemin, "w", encoding="utf-8-sig", newline="") as fichier:
                redacteur = csv.DictWriter(fichier, fieldnames=list(self._lignes[0]),
                                            delimiter=";")
                redacteur.writeheader()
                redacteur.writerows(self._lignes)
        QMessageBox.information(self, "Export réussi", f"Fichier généré :\n{chemin}")

    # Interface commune aux onglets rafraîchis par le panneau de filtres :
    # l'historique ne dépend pas des filtres métier, il les ignore.
    def refresh(self, ctx=None):
        self._refresh()
