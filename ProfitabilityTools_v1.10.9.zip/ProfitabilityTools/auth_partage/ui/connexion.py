from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QLabel, QMessageBox,
)

from auth_partage import config as _config
from auth_partage.database import AuthentificationIndisponible, MESSAGE_INJOIGNABLE
from auth_partage.service import AuthService, CurrentUser


class LoginDialog(QDialog):
    """Boîte de connexion générique (auth_partage) — titre/sous-titre tirés
    de la configuration de l'application hôte (auth_partage.configurer(...))
    plutôt que codés en dur, pour rester réutilisable d'une application à
    l'autre sans adaptation (correctif ProfitabilityTools v1.10.0 : la
    version d'origine, écrite pour Argos, affichait « Connexion — Argos » /
    « IN CONFIDENCE INSURANCE » quelle que soit l'application hôte, et
    pré-remplissait le login avec « admin »)."""

    def __init__(self, sous_titre: str = "", parent=None):
        super().__init__(parent)
        try:
            app_label = _config.application()
        except Exception:  # noqa: BLE001 - configurer() pas encore appelé
            app_label = "Application"
        self.setWindowTitle(f"Connexion — {app_label.title()}")
        self.setModal(True)
        self.resize(360, 180)
        self.auth = AuthService()
        self.current_user: CurrentUser | None = None

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"<h3>{app_label.title()}</h3>"))
        if sous_titre:
            layout.addWidget(QLabel(sous_titre))

        form = QFormLayout()
        self.edit_login = QLineEdit()
        self.edit_mdp = QLineEdit()
        self.edit_mdp.setEchoMode(QLineEdit.Password)
        self.edit_mdp.returnPressed.connect(self._on_login)
        form.addRow("Login", self.edit_login)
        form.addRow("Mot de passe", self.edit_mdp)
        layout.addLayout(form)

        self.btn_login = QPushButton("Se connecter")
        self.btn_login.clicked.connect(self._on_login)
        layout.addWidget(self.btn_login)

    def _on_login(self):
        login = self.edit_login.text().strip()
        mdp = self.edit_mdp.text()
        try:
            user = self.auth.authenticate(login, mdp)
        except AuthentificationIndisponible as indisponible:
            # Ce n'est PAS un problème de mot de passe : le dire évite que
            # l'utilisateur ressaisisse ses identifiants en boucle pendant
            # qu'un VPN est coupé ou que la base centrale est arrêtée.
            QMessageBox.critical(
                self, "Base d'authentification injoignable",
                MESSAGE_INJOIGNABLE + f"\n\nDétail : {indisponible}")
            self.edit_mdp.clear()
            return
        if user is None:
            # Le motif vient du service, qui le connaît, plutôt que d'une
            # relecture de l'historique : celle-ci échouait dès que
            # l'écriture de la trace avait échoué, et l'utilisateur recevait
            # alors un « mot de passe incorrect » trompeur.
            from auth_partage.service import REFUS_NON_HABILITE
            from auth_partage.config import application as _application
            if getattr(self.auth, "dernier_motif_refus", "") == REFUS_NON_HABILITE:
                autres = self.auth.applications_du_compte or {}
                if autres:
                    detail = ("Ce compte est habilité sur : "
                              + ", ".join(f"{app} ({role})"
                                           for app, role in sorted(autres.items()))
                              + ".")
                else:
                    detail = "Ce compte n'est habilité sur aucune application."
                QMessageBox.warning(
                    self, "Habilitation manquante",
                    f"<b>Votre identifiant et votre mot de passe sont corrects.</b>"
                    f"<br><br>Mais ce compte n'est pas habilité sur "
                    f"<b>{_application()}</b>.<br><br>{detail}<br><br>"
                    f"Demandez à un administrateur d'ajouter l'application "
                    f"{_application()} à vos habilitations, avec le rôle "
                    f"correspondant à votre fonction.")
            else:
                QMessageBox.warning(
                    self, "Connexion refusée",
                    "Identifiant ou mot de passe incorrect, ou compte désactivé.")
            self.edit_mdp.clear()
            return

        # Mot de passe provisoire (compte créé ou réinitialisé par un
        # administrateur) : le changement est imposé AVANT d'ouvrir
        # l'application. L'indicateur existait en base depuis l'origine
        # mais n'était jamais lu — un mot de passe connu d'un tiers
        # restait donc valable indéfiniment.
        if user.doit_changer_mdp:
            # Correctif ProfitabilityTools v1.10.0 : la version d'origine
            # importait `views.password_dialog`, un module propre à Argos
            # qui n'existe dans aucune application du parc (bug latent dans
            # auth_partage lui-même, jamais déclenché à Orchestrator faute
            # d'y avoir testé une première connexion ou une réinitialisation
            # de mot de passe) — la boîte de dialogue réellement fournie par
            # le module partagé est auth_partage.ui.mot_de_passe.
            from auth_partage.ui.mot_de_passe import ChangementMotDePasseDialog
            boite = ChangementMotDePasseDialog(user, impose=True, parent=self)
            if boite.exec() != QDialog.Accepted:
                self.edit_mdp.clear()
                return

        self.current_user = user
        self.accept()
