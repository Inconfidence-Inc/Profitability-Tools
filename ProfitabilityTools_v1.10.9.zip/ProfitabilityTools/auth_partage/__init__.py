"""Module d'authentification PARTAGÉ entre les applications Python.

Un agent est déclaré une seule fois, dans la base OUTILS, avec un rôle par
application. Chaque application vérifie son mot de passe et ses
habilitations au même endroit, et y écrit ses propres traces.

Intégration en quatre lignes, au démarrage de l'application :

    import auth_partage

    auth_partage.configurer(
        application="PORTAIL",
        permissions={
            "Administrateur": {"parametres", "utilisateurs", "consultation"},
            "Lecteur": {"consultation"},
        },
        nom_dossier_donnees="Portail_Assurance",
    )

Puis, pour authentifier :

    from auth_partage.ui.connexion import LoginDialog

    boite = LoginDialog()
    if boite.exec() == boite.Accepted:
        utilisateur = boite.current_user      # login, role, applications…

Ce que le module garantit, identiquement dans toutes les applications :

- **un seul couple login / mot de passe** pour tout le parc ;
- **un rôle par application** : administrateur ici, lecteur ailleurs ;
- **des sessions indépendantes** : se déconnecter d'une application
  n'affecte pas les autres ;
- **des traces individuelles** : chaque application écrit dans
  USERS_PYTHON_HISTO avec son propre code, le rôle endossé, le poste et le
  compte Windows ;
- **les mêmes refus, avec les mêmes messages** : identifiants incorrects,
  compte désactivé, et surtout *compte valide mais non habilité sur cette
  application* — ce dernier cas listant les applications où le compte
  l'est, pour que l'agent comprenne immédiatement ;
- **les mêmes garde-fous** : mot de passe provisoire à changer à la
  première connexion, politique de mot de passe, impossibilité de retirer
  le dernier administrateur actif d'une application.

Ce que le module NE fait PAS, délibérément :

- il ne crée pas le schéma de la base OUTILS. Cette base est partagée ;
  si chaque application y appliquait ses migrations, elles se feraient
  concurrence. Le schéma est posé une fois avec
  `sql/creation_outils_authentification.sql`, et les applications se
  contentent de le vérifier ;
- il ne décide pas de ce qu'un rôle autorise : chaque application déclare
  ses propres permissions.
"""
from auth_partage.config import (ConfigurationManquante, application,  # noqa: F401
                                  configurer, permissions, role_administrateur)
from auth_partage.database import (AuthentificationIndisponible,  # noqa: F401
                                    MESSAGE_INJOIGNABLE, ProfilIllisible, centralisee, creer_tables,
                                    description, enregistrer_profil, lire_profil,
                                    oublier_profil, tester, utiliser_session_locale)
from auth_partage.entities import (Base, UserPython, UserPythonHisto)  # noqa: F401
from auth_partage.service import (AuthService, CurrentUser,  # noqa: F401
                                   REFUS_DESACTIVE, REFUS_IDENTIFIANTS,
                                   REFUS_NON_HABILITE, analyser_applications,
                                   formater_applications, tracer_evenement)
from auth_partage.connexion_mssql import (  # noqa: F401
    DRIVER_ODBC_PAR_DEFAUT, MODES_AUTH, construire_url_mssql)
from auth_partage.database import chemin_profil  # noqa: F401
from auth_partage.securite import valider_mot_de_passe  # noqa: F401

# RÈGLE D'IMPLÉMENTATION DU PAQUET, née de trois incidents successifs :
# aucun chemin, aucune valeur de configuration n'est résolu AU MOMENT DE
# L'IMPORT. Le code d'application, le chemin du profil et celui de la clé
# de chiffrement l'étaient ; chacun a produit une panne différente et
# aucune ne désignait sa cause — traces sans application, connexion à la
# mauvaise base, « InvalidToken » à la lecture du profil. Tout se résout
# désormais à l'appel, et `nom_dossier_donnees()` refuse plutôt que de
# retourner un défaut. Un outil de contrôle vérifie cette règle :
# `tools/verifier_auth_partage.py`.
__version__ = "1.1.0"
