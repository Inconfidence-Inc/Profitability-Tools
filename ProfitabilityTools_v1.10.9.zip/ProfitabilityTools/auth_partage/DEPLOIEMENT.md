# Déployer `auth_partage`

Trois niveaux, à faire dans cet ordre : la base une fois pour toutes, puis
chaque application, puis chaque poste.

---

## 1. La base OUTILS — une seule fois pour tout le parc

Exécuter `sql/creation_outils_authentification.sql` sur la base `OUTILS`.

Le module **ne crée pas ce schéma et ne le migre pas** : la base est
partagée entre plusieurs applications. Si chacune y appliquait ses
migrations, elles se feraient concurrence — deux applications démarrant
ensemble sur une base neuve tenteraient de créer les mêmes tables. Le
schéma est posé une fois ; les applications se contentent de le vérifier.

Droits minimaux du compte applicatif :

```sql
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.USERS_PYTHON       TO [compte];
GRANT SELECT, INSERT                 ON dbo.USERS_PYTHON_HISTO TO [compte];
```

L'historique n'est volontairement pas modifiable : une trace de connexion
qu'on peut réécrire ne prouve plus rien.

---

## 2. Chaque application — une fois, dans son code

### Installer le paquet

```bash
pip install ./auth_partage
```

ou, si vous préférez ne rien installer, copier le dossier `auth_partage/`
à la racine de l'application. Les deux fonctionnent.

Dépendances : `SQLAlchemy`, `bcrypt`, `cryptography`. `PySide6` uniquement
si vous utilisez les écrans fournis — une application en ligne de commande
s'en passe.

### Déclarer l'application au démarrage

**Avant tout autre usage du module**, et avant toute connexion :

```python
import auth_partage

auth_partage.configurer(
    application="PORTAIL",                  # code de CETTE application
    permissions={                           # ce que chaque rôle ouvre ICI
        "Administrateur": {"parametres", "utilisateurs", "consultation"},
        "Lecteur":        {"consultation"},
    },
    nom_dossier_donnees="Portail_Assurance",
)
```

Le module **refuse de travailler** tant que cet appel n'a pas eu lieu, et
c'est délibéré : un module non configuré irait chercher sa clé de
chiffrement dans un dossier par défaut, rendant indéchiffrable le profil
déjà enregistré. Cette panne-là ne désigne jamais sa cause.

`permissions` appartient à l'application : le même code de rôle n'ouvre
pas les mêmes écrans d'un outil à l'autre.

### Connecter

```python
from auth_partage.ui.connexion import LoginDialog

boite = LoginDialog()
if boite.exec() == boite.Accepted:
    utilisateur = boite.current_user      # .login .role .applications
```

### Vérifier un droit

```python
from auth_partage import AuthService
if AuthService().can(utilisateur.role, "parametres"):
    ...
```

---

## 3. Chaque poste — une commande

La connexion à OUTILS est propre au poste : elle est chiffrée avec une clé
locale, et ne se copie donc pas d'une machine à l'autre.

```bash
python -m auth_partage.installer ^
    --application PORTAIL --dossier-donnees Portail_Assurance ^
    --serveur monserveur.database.windows.net --base OUTILS ^
    --auth windows --trust-server-certificate
```

Sans argument, les questions sont posées. `--tester-seulement` vérifie une
connexion sans rien enregistrer. Le code de retour est exploitable par un
script de déploiement : `0` en cas de succès.

> **`--trust-server-certificate`** est nécessaire dès que le serveur
> présente un certificat que le poste ne reconnaît pas — cas courant en
> interne ou derrière un proxy. La connexion reste chiffrée : seule la
> vérification de l'autorité émettrice est levée. Sans cette option, le
> pilote ODBC 18 refuse la connexion avec l'erreur `08001`.

Sur la **première** machine seulement, ajouter `--creer-tables` si la base
OUTILS est vide et que vous n'avez pas exécuté le script SQL.

---

## 4. Bascule progressive

Tant qu'OUTILS n'est pas en place, une application peut continuer sur sa
propre base :

```python
auth_partage.utiliser_session_locale(ma_fabrique_de_session)
```

C'est ce qui permet de basculer **application par application** au lieu
d'un basculement général, et de revenir en arrière sans redéployer. Argos
procède ainsi : sans profil OUTILS enregistré, il lit ses comptes dans sa
propre base.

---

## Vérifier une installation

```bash
python -m auth_partage.installer --application PORTAIL \
       --dossier-donnees Portail_Assurance --url "<url>" --tester-seulement
python auth_partage/exemple_integration.py       # démonstration complète
python tools/verifier_auth_partage.py            # contrôle du paquet lui-même
```

---

## Panne courante : « InvalidToken » à la connexion

Le profil enregistré ne peut pas être déchiffré avec la clé locale. Deux
causes :

- le dossier de données a été **copié depuis un autre poste** — la clé y
  est propre à la machine d'origine ;
- la clé a été régénérée, ou l'application a démarré une fois sans être
  configurée, dans un autre dossier.

Supprimer `auth_profile.json` du dossier de données, puis relancer
l'installateur. Le message affiché par le module donne le chemin exact.
