"""Tables PARTAGÉES entre applications : USERS_PYTHON et USERS_PYTHON_HISTO.

Base déclarative DÉDIÉE, distincte de celle de l'application hôte. C'est
volontaire : le module doit pouvoir créer ou vérifier ses deux tables sans
emporter le schéma métier de l'application, et sans que celui-ci le
suive. Une application qui appellerait `Base.metadata.create_all()` sur sa
propre base ne créerait donc pas par accident les tables de comptes.

Les noms sont en majuscules, comme les tables métier des bases SQL Server
de la direction : ces tables ne sont la propriété d'aucune application.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Unicode
from sqlalchemy.orm import declarative_base

Base = declarative_base()

SEPARATEUR_APPLICATIONS = ";"
SEPARATEUR_ROLE = ":"


class UserPython(Base):
    """Compte utilisateur commun à toutes les applications Python.

    Les droits sont portés par la colonne `applications`, sous la forme
    « ARGOS:Administrateur;PORTAIL:Lecteur ».

    Pourquoi une colonne délimitée plutôt qu'une table de liaison : cette
    table a vocation à être lue par des applications tierces, écrites dans
    d'autres langages et avec d'autres ORM. Une ligne unique et
    auto-portante leur évite une jointure et un schéma à connaître — un
    simple SELECT sur le login suffit à savoir qui est l'agent et ce à
    quoi il a droit. Le prix à payer est qu'aucune contrainte d'intégrité
    ne garantit la validité des codes applicatifs : c'est le code qui les
    valide (voir models/auth_service.py:analyser_applications).
    """
    __tablename__ = "USERS_PYTHON"
    id = Column(Integer, primary_key=True)
    # Unicode (NVARCHAR côté SQL Server) sur tout ce qui peut contenir un
    # nom propre. En VARCHAR, la conversion vers la page de codes de la
    # base MUTILE silencieusement les caractères qu'elle ne connaît pas :
    # « Łukasz » devient « ?ukasz ». Le groupe opérant en Pologne, le cas
    # est concret et non théorique — et un nom corrompu en base ne se
    # répare pas après coup.
    login = Column(Unicode(50), unique=True, nullable=False)
    # L'empreinte bcrypt est de l'ASCII pur : String suffit et évite de
    # doubler l'espace occupé par la colonne la plus large de la table.
    mot_de_passe_hash = Column(String(128), nullable=False)
    nom = Column(Unicode(50))
    prenom = Column(Unicode(50))
    email = Column(Unicode(120))
    # « ARGOS:Administrateur;AUTRE_APP:Lecteur » — codes applicatifs, ASCII
    applications = Column(String(500), default="")
    actif = Column(Boolean, default=True)
    doit_changer_mdp = Column(Boolean, default=True)
    date_creation = Column(DateTime, default=dt.datetime.now)
    date_modification = Column(DateTime, default=dt.datetime.now,
                                onupdate=dt.datetime.now)
    cree_par = Column(Unicode(50))
    derniere_connexion = Column(DateTime, nullable=True)
    commentaire = Column(Unicode(255))


class UserPythonHisto(Base):
    """Historique des connexions, commun à toutes les applications.

    Trace les ÉCHECS autant que les succès : c'est ce qui donne sa valeur
    à un historique de connexion. Une série de « CONNEXION_ECHEC » sur un
    même login, depuis un poste inhabituel, est précisément ce qu'on
    cherche à voir.

    Le poste et le compte Windows sont enregistrés : sur un outil partagé,
    « qui s'est connecté » sans « depuis où » laisse la question à moitié
    répondue.
    """
    __tablename__ = "USERS_PYTHON_HISTO"
    id = Column(Integer, primary_key=True)
    login = Column(Unicode(50), nullable=False, index=True)
    # Codes techniques, ASCII par convention.
    application = Column(String(30), nullable=False, index=True)
    evenement = Column(String(30), nullable=False)
    # Rôle EFFECTIVEMENT endossé pour cette connexion-là. Un même agent
    # peut être Administrateur sur une application et simple Lecteur sur
    # une autre : sans cette colonne, l'historique dit qui s'est connecté
    # où, mais pas avec quels droits — or c'est précisément ce qu'on
    # cherche à retrouver lors d'un contrôle.
    role = Column(Unicode(30))
    horodatage = Column(DateTime, default=dt.datetime.now, index=True)
    # Nom de poste et compte Windows : un poste nommé « BUREAU-JÉRÔME » est
    # banal, et le détail contient des messages en français accentués.
    poste = Column(Unicode(80))
    utilisateur_systeme = Column(Unicode(80))
    detail = Column(Unicode(255))


# Événements tracés dans USERS_PYTHON_HISTO.
EVT_CONNEXION_OK = "CONNEXION_OK"
EVT_CONNEXION_ECHEC = "CONNEXION_ECHEC"
EVT_DECONNEXION = "DECONNEXION"
EVT_MDP_CHANGE = "MOT_DE_PASSE_CHANGE"
EVT_MDP_REINIT = "MOT_DE_PASSE_REINITIALISE"
EVT_COMPTE_CREE = "COMPTE_CREE"
EVT_COMPTE_MODIFIE = "COMPTE_MODIFIE"
EVT_COMPTE_SUPPRIME = "COMPTE_SUPPRIME"
EVT_ACCES_REFUSE = "ACCES_REFUSE"
