"""Connexion à la base d'authentification CENTRALE (OUTILS).

Le principe
-----------
Les comptes et l'historique des connexions ne vivent plus dans la base de
chaque application, mais dans une base unique — `OUTILS` — que toutes les
applications Python interrogent. Un agent y est déclaré une fois ; son mot
de passe et ses accréditations sont vérifiés au même endroit, quelle que
soit l'application par laquelle il arrive.

Pourquoi une CONNEXION séparée, et non une requête inter-bases
--------------------------------------------------------------
Le code sait déjà interroger une autre base par nommage en trois parties
(`[TECH_BI].[dbo].[SRC_Sinistre_Transformer_Contenu]`). La même approche
aurait pu servir ici — mais elle lie l'authentification au serveur des
données métier, et **Azure SQL Database (base isolée) ne permet pas les
requêtes inter-bases** sans Elastic Query. Une connexion distincte
fonctionne partout : base isolée, Managed Instance, serveur classique.

Elle apporte un second bénéfice : OUTILS et les données métier peuvent
vivre sur des serveurs différents, avec des droits différents. Le compte
applicatif n'a besoin que de lecture/écriture sur deux tables d'OUTILS, et
rien de plus.

Le prix à payer, à connaître
----------------------------
**Si OUTILS est injoignable, personne ne peut se connecter — nulle part.**
C'est la contrepartie inhérente à toute centralisation d'authentification,
et elle doit être assumée en connaissance de cause : la base OUTILS devient
un composant critique, au même titre que l'annuaire. Le message d'erreur le
dit explicitement plutôt que de laisser croire à un mot de passe erroné.

En l'absence de configuration, l'application retombe sur sa propre base :
c'est ce qui permet de fonctionner en démonstration, et de migrer
progressivement application par application.
"""
from __future__ import annotations

import json
import os

from sqlalchemy import create_engine, text
from sqlalchemy.orm import scoped_session, sessionmaker

from auth_partage.chemins import get_app_data_dir
from auth_partage.chiffrement import decrypt, encrypt

NOM_FICHIER_PROFIL = "auth_profile.json"


def chemin_profil() -> str:
    """Chemin du profil de connexion, résolu À L'APPEL.

    Une constante calculée à l'import serait évaluée AVANT que
    l'application ait déclaré son dossier de données : le module lirait
    alors le profil d'une autre application, ou échouerait. Défaut
    constaté — Argos se retrouvait connecté à la base d'authentification
    d'un exemple de test."""
    return os.path.join(get_app_data_dir(), NOM_FICHIER_PROFIL)

_moteur = None
_session = None
_url_active: str | None = None

# Session de repli, fournie par l'application hôte. Permet de fonctionner
# sur la base de l'application tant que la base OUTILS n'est pas en place —
# c'est ce qui rend la bascule progressive possible, application par
# application, au lieu d'un basculement général.
_session_locale = None


def utiliser_session_locale(fabrique):
    """Déclare une fabrique de session de repli (callable sans argument)."""
    global _session_locale
    _session_locale = fabrique


# ----------------------------------------------------- Profil enregistré
def enregistrer_profil(nom: str, moteur: str, url: str):
    """Enregistre la connexion OUTILS, URL chiffrée avec la clé locale —
    même protection que le profil de connexion métier."""
    os.makedirs(os.path.dirname(chemin_profil()), exist_ok=True)
    with open(chemin_profil(), "w", encoding="utf-8") as fichier:
        json.dump({"nom": nom, "moteur": moteur, "url_chiffree": encrypt(url)}, fichier)


def lire_profil() -> dict | None:
    if not os.path.exists(chemin_profil()):
        return None
    try:
        with open(chemin_profil(), encoding="utf-8") as fichier:
            donnees = json.load(fichier)
        return {"nom": donnees["nom"], "moteur": donnees["moteur"],
                "url": decrypt(donnees["url_chiffree"])}
    except Exception as erreur:  # noqa: BLE001
        # InvalidToken notamment : le profil a été chiffré avec une autre
        # clé que celle lue ici. Retourner None ferait croire à une absence
        # de configuration ; l'utilisateur doit savoir que le profil existe
        # mais n'est plus déchiffrable, et comment repartir.
        from auth_partage import config
        raise ProfilIllisible(
            f"Le profil de connexion enregistré sur ce poste n'a pas pu être "
            f"déchiffré ({type(erreur).__name__}).\n\nLa clé locale de "
            f"« {config.nom_dossier_donnees()} » ne correspond pas au profil. "
            f"Cela arrive si le dossier de données a été copié d'un autre "
            f"poste, ou si la clé a été régénérée.\n\nSupprimez le fichier "
            f"puis ressaisissez la connexion :\n{chemin_profil()}") from erreur


def oublier_profil():
    global _moteur, _session, _url_active
    if os.path.exists(chemin_profil()):
        os.remove(chemin_profil())
    _fermer()
    _moteur = _session = _url_active = None


def _fermer():
    global _session, _moteur
    if _session is not None:
        try:
            _session.remove()
        except Exception:  # noqa: BLE001
            pass
    if _moteur is not None:
        try:
            _moteur.dispose()
        except Exception:  # noqa: BLE001
            pass


# ------------------------------------------------------------- Connexion
def centralisee() -> bool:
    """Vrai si une base d'authentification centrale est configurée.

    Un profil présent mais illisible compte comme configuré : le dire
    absent enverrait l'application démarrer en mode local sans expliquer
    pourquoi la centralisation a disparu."""
    try:
        return lire_profil() is not None
    except ProfilIllisible:
        return True


def description() -> str:
    try:
        profil = lire_profil()
    except ProfilIllisible as erreur:
        return f"Profil d'authentification ILLISIBLE — {erreur}"
    if profil is None:
        return ("Authentification LOCALE — les comptes sont dans la base de "
                "l'application.")
    return f"Authentification CENTRALISÉE sur « {profil['nom']} »."


def get_auth_session():
    """Session à utiliser pour tout ce qui touche aux comptes.

    Retourne la session de la base OUTILS si elle est configurée, celle de
    l'application sinon. Ce point de bascule unique évite d'avoir à choisir
    la bonne base à chaque appel : le service d'authentification ignore
    lequel des deux modes est actif."""
    global _moteur, _session, _url_active
    try:
        profil = lire_profil()
    except ProfilIllisible as erreur:
        raise AuthentificationIndisponible(str(erreur)) from erreur
    if profil is None:
        # Pas de base centrale configurée : le module ne sait pas où écrire.
        # Une application autonome DOIT en désigner une ; Argos peut aussi
        # lui passer la session de sa propre base (voir session_locale).
        if _session_locale is not None:
            return _session_locale()
        raise AuthentificationIndisponible(
            "Aucune base d'authentification n'est configurée. Renseignez la "
            "connexion à la base OUTILS, ou fournissez une session locale "
            "via auth_partage.database.utiliser_session_locale().")

    if _session is None or _url_active != profil["url"]:
        _fermer()
        connect_args = {"timeout": 15} if profil["url"].startswith("mssql") else {}
        _moteur = create_engine(profil["url"], future=True, pool_pre_ping=True,
                                 pool_recycle=1800, connect_args=connect_args)
        _session = scoped_session(sessionmaker(bind=_moteur, autoflush=False,
                                                expire_on_commit=False))
        _url_active = profil["url"]
    return _session()


def tester(url: str) -> tuple[bool, str]:
    """Teste la connexion ET la présence des deux tables attendues.

    Tester la seule connexion ne suffirait pas : une base joignable mais
    dépourvue de `USERS_PYTHON` produirait un échec bien plus tard, à la
    première tentative de connexion d'un utilisateur."""
    from auth_partage.entities import UserPython, UserPythonHisto
    moteur = None
    try:
        moteur = create_engine(url, future=True)
        from sqlalchemy import inspect
        with moteur.connect() as connexion:
            connexion.execute(text("SELECT 1"))
            tables = set(inspect(connexion).get_table_names())
        manquantes = [t.__tablename__ for t in (UserPython, UserPythonHisto)
                      if t.__tablename__ not in tables]
        if manquantes:
            return False, ("Connexion établie, mais table(s) manquante(s) : "
                            + ", ".join(manquantes)
                            + ". Exécutez sql/creation_outils_authentification.sql "
                              "sur cette base, ou utilisez « Créer les tables ».")
        return True, "Connexion réussie, les deux tables sont présentes."
    except Exception as exception:  # noqa: BLE001
        return False, _message_avec_piste(str(exception))
    finally:
        if moteur is not None:
            moteur.dispose()


def _message_avec_piste(message: str) -> str:
    """Ajoute la marche à suivre aux erreurs dont le remède est connu.

    Le message brut du pilote ODBC décrit le problème sans jamais dire quoi
    faire — « la chaîne de certificats a été fournie par une autorité qui
    n'est pas approuvée » laisse l'administrateur sans issue alors qu'une
    case à cocher suffit."""
    bas = message.lower()
    if "certificat" in bas or "certificate" in bas or "08001" in bas:
        return (message + "\n\n→ Le serveur présente un certificat que ce poste "
                "ne reconnaît pas. Cochez « TrustServerCertificate » ci-dessus, "
                "puis retestez. La connexion reste chiffrée : seule la "
                "vérification de l'autorité émettrice est levée.")
    if "login failed" in bas or "échec de la connexion" in bas or "18456" in bas:
        return (message + "\n\n→ Identifiants refusés par le serveur. Vérifiez le "
                "compte et le mot de passe, et que ce compte a bien accès à la "
                "base indiquée.")
    if "cannot open database" in bas or "4060" in bas:
        return (message + "\n\n→ La base n'existe pas sur ce serveur, ou le compte "
                "n'y a pas accès. Vérifiez le nom saisi dans « Base ».")
    if "timeout" in bas or "délai" in bas:
        return (message + "\n\n→ Aucune réponse du serveur : vérifiez le réseau, le "
                "VPN, et que le port est bien ouvert depuis ce poste.")
    return message


def creer_tables(url: str) -> tuple[bool, str]:
    """Crée les deux tables si elles manquent.

    Volontairement PAS géré par Alembic : la base OUTILS est partagée entre
    plusieurs applications, et les laisser toutes migrer le même schéma
    reviendrait à les faire courir l'une contre l'autre. Ici, une création
    idempotente, qui ne touche à rien si les tables existent déjà."""
    from auth_partage.entities import UserPython, UserPythonHisto
    moteur = None
    try:
        moteur = create_engine(url, future=True)
        for modele in (UserPython, UserPythonHisto):
            modele.__table__.create(bind=moteur, checkfirst=True)
        return True, "Tables USERS_PYTHON et USERS_PYTHON_HISTO en place."
    except Exception as exception:  # noqa: BLE001
        return False, _message_avec_piste(str(exception))
    finally:
        if moteur is not None:
            moteur.dispose()


class ProfilIllisible(RuntimeError):
    """Le profil enregistré existe mais ne peut pas être déchiffré."""


class AuthentificationIndisponible(RuntimeError):
    """La base d'authentification centrale n'a pas pu être jointe.

    Distincte d'un refus d'identifiants : l'appelant doit dire à
    l'utilisateur que le problème n'est pas son mot de passe, faute de quoi
    il le ressaisira en boucle pendant qu'un VPN est coupé."""


MESSAGE_INJOIGNABLE = (
    "La base d'authentification centrale est injoignable : aucune connexion "
    "n'est possible pour le moment.\n\nCe n'est pas un problème de mot de "
    "passe. Vérifiez le réseau et le VPN, puis réessayez. Si le problème "
    "persiste, un administrateur peut repasser en authentification locale "
    "depuis l'onglet Administration d'un poste déjà connecté."
)
