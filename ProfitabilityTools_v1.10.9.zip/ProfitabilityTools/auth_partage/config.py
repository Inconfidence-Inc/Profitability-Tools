"""Configuration du module d'authentification partagé.

Le module ne connaît RIEN de l'application qui l'utilise tant qu'elle ne
s'est pas déclarée. C'est la condition pour qu'il serve Argos, un portail
et un outil de facturation sans contenir une ligne spécifique à l'un
d'eux.

Chaque application appelle `configurer()` une fois, au démarrage, avant
toute authentification :

    from auth_partage import configurer

    configurer(
        application="PORTAIL",
        permissions={
            "Administrateur": {"parametres", "utilisateurs", "consultation"},
            "Lecteur": {"consultation"},
        },
        role_administrateur="Administrateur",
        nom_dossier_donnees="Portail_Assurance",
    )

Deux points méritent d'être compris plutôt que copiés :

- **`permissions` appartient à l'application, pas au module.** Le même code
  de rôle « Administrateur » n'ouvre pas les mêmes écrans d'une application
  à l'autre. Le module se contente de dire QUEL rôle l'agent porte ici ;
  ce que ce rôle autorise ne regarde que l'application.

- **`role_administrateur`** désigne le rôle qui peut administrer les
  comptes. Il sert aux garde-fous : le module refuse de désactiver,
  déshabiliter ou supprimer le dernier compte portant ce rôle sur cette
  application — faute de quoi plus personne ne pourrait administrer, et il
  faudrait intervenir en base pour reprendre la main.
"""
from __future__ import annotations

# Valeurs par défaut, volontairement inutilisables en production : une
# application qui oublie d'appeler configurer() doit s'en apercevoir
# immédiatement, pas se retrouver silencieusement rattachée à « ARGOS ».
_config: dict = {
    "application": "",
    "permissions": {},
    "role_administrateur": "Administrateur",
    "nom_dossier_donnees": "Auth_Partage",
    "longueur_minimale_mot_de_passe": 8,
}


class ConfigurationManquante(RuntimeError):
    """configurer() n'a pas été appelé avant la première authentification."""


def configurer(application: str, permissions: dict | None = None,
                role_administrateur: str = "Administrateur",
                nom_dossier_donnees: str = "",
                longueur_minimale_mot_de_passe: int = 8):
    if not (application or "").strip():
        raise ValueError("Le code d'application est obligatoire.")
    _config["application"] = application.strip().upper()
    _config["permissions"] = dict(permissions or {})
    _config["role_administrateur"] = role_administrateur
    _config["nom_dossier_donnees"] = (nom_dossier_donnees
                                       or _config["application"])
    _config["longueur_minimale_mot_de_passe"] = int(longueur_minimale_mot_de_passe)


def application() -> str:
    code = _config["application"]
    if not code:
        raise ConfigurationManquante(
            "Le module d'authentification n'est pas configuré. Appelez "
            "auth_partage.configurer(application=\"...\") au démarrage, avant "
            "toute connexion.")
    return code


def permissions() -> dict:
    return _config["permissions"]


def role_administrateur() -> str:
    return _config["role_administrateur"]


def nom_dossier_donnees() -> str:
    """Dossier de données local, OBLIGATOIREMENT configuré.

    Cette fonction retournait auparavant un défaut, « Auth_Partage ». Une
    application qui importait le module avant de se configurer allait donc
    chercher sa clé de chiffrement et son profil de connexion dans un
    dossier qui n'était pas le sien — et le profil déjà chiffré devenait
    indéchiffrable, avec pour seul message « InvalidToken ».

    Un défaut silencieux transforme un oubli de configuration en panne
    incompréhensible. Mieux vaut refuser tout de suite, en disant quoi
    faire."""
    if not _config["application"]:
        raise ConfigurationManquante(
            "Le module d'authentification n'est pas configuré : impossible de "
            "savoir où lire la clé de chiffrement et le profil de connexion. "
            "Appelez auth_partage.configurer(application=..., "
            "nom_dossier_donnees=...) au démarrage, AVANT tout autre import "
            "du module.")
    return _config["nom_dossier_donnees"]


def longueur_minimale_mot_de_passe() -> int:
    return _config["longueur_minimale_mot_de_passe"]
