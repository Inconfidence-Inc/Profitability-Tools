"""Construction de l'URL de connexion SQL Server / Azure SQL.

Repris à l'identique de l'application d'origine, pour que toutes les
applications se connectent à OUTILS exactement de la même façon — mêmes
paramètres ODBC, mêmes options de chiffrement. Une divergence ici
produirait des symptômes difficiles à rapprocher : une application qui se
connecte, une autre qui échoue sur le même serveur.
"""
from __future__ import annotations

from urllib.parse import quote_plus

DRIVER_ODBC_PAR_DEFAUT = "ODBC Driver 18 for SQL Server"

MODES_AUTH = {
    "sql": "Connexion SQL Server (utilisateur / mot de passe)",
    "windows": "Authentification Windows intégrée",
    "azure_ad_password": "Azure AD (utilisateur / mot de passe)",
    "azure_ad_interactive": "Azure AD interactif (fenêtre Microsoft)",
}


def construire_url_mssql(serveur: str, port: str = "1433", base: str = "OUTILS",
                          mode: str = "windows", utilisateur: str = "",
                          mot_de_passe: str = "", driver: str = "",
                          chiffrer: bool = True,
                          accepter_certificat: bool = False) -> str:
    """URL SQLAlchemy pour SQL Server.

    `accepter_certificat` (TrustServerCertificate) est nécessaire dès que le
    serveur présente un certificat que le poste ne reconnaît pas — cas
    courant sur un serveur interne ou derrière un proxy d'entreprise. La
    connexion reste chiffrée : seule la vérification de l'autorité
    émettrice est levée.
    """
    commun = (f"driver={quote_plus(driver or DRIVER_ODBC_PAR_DEFAUT)}"
              f"&Encrypt={'yes' if chiffrer else 'no'}"
              f"&TrustServerCertificate={'yes' if accepter_certificat else 'no'}")
    if mode == "azure_ad_interactive":
        return (f"mssql+pyodbc://@{serveur}:{port}/{base}"
                f"?{commun}&Authentication=ActiveDirectoryInteractive")
    if mode == "azure_ad_password":
        return (f"mssql+pyodbc://{quote_plus(utilisateur)}:{quote_plus(mot_de_passe)}"
                f"@{serveur}:{port}/{base}"
                f"?{commun}&Authentication=ActiveDirectoryPassword")
    if mode == "windows":
        return (f"mssql+pyodbc://@{serveur}:{port}/{base}"
                f"?{commun}&trusted_connection=yes")
    return (f"mssql+pyodbc://{quote_plus(utilisateur)}:{quote_plus(mot_de_passe)}"
            f"@{serveur}:{port}/{base}?{commun}")
