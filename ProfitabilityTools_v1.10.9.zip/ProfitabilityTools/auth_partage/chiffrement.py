"""Chiffrement local du profil de connexion enregistré.

La clé est générée une seule fois sur la machine, dans le dossier de
données applicatives du système (hors du répertoire du projet — voir
models/app_paths.py — pour survivre au remplacement du dossier projet
lors d'une mise à jour de l'application), et n'est JAMAIS transmise ni
affichée. Elle protège uniquement le fichier de profil enregistré sur
CE poste ; ce n'est pas un coffre-fort partagé entre utilisateurs/postes.
"""
from __future__ import annotations

import os
import stat

from cryptography.fernet import Fernet

# CORRECTIF (à remonter au paquet) : `from models.database import APP_DIR`
# importait un module d'Argos, et APP_DIR n'était utilisé NULLE PART dans
# ce fichier. Cet import mort faisait échouer l'import de tout le paquet
# dans n'importe quelle application autre qu'Argos — le module se déclare
# pourtant partagé.
from auth_partage.chemins import get_app_data_dir

NOM_FICHIER_CLE = "secret.key"


def chemin_cle() -> str:
    """Chemin de la clé locale, résolu À L'APPEL.

    Une constante calculée à l'import serait évaluée AVANT que
    l'application ait déclaré son dossier de données. Le module irait alors
    chercher — ou pire, CRÉER — une clé dans un dossier par défaut, et le
    profil de connexion déjà chiffré deviendrait indéchiffrable :
    « InvalidToken », sans rien qui désigne la cause.

    Défaut constaté en production après l'extraction du module. C'est la
    troisième valeur de ce paquet figée trop tôt, après le code
    d'application et le chemin du profil : d'où la règle désormais
    appliquée ici — aucun chemin ni aucune valeur de configuration n'est
    résolu au moment de l'import.
    """
    return os.path.join(get_app_data_dir(), NOM_FICHIER_CLE)



def _get_or_create_key() -> bytes:
    os.makedirs(os.path.dirname(chemin_cle()), exist_ok=True)
    if os.path.exists(chemin_cle()):
        with open(chemin_cle(), "rb") as f:
            return f.read()
    key = Fernet.generate_key()
    with open(chemin_cle(), "wb") as f:
        f.write(key)
    try:
        os.chmod(chemin_cle(), stat.S_IRUSR | stat.S_IWUSR)  # lecture/écriture propriétaire seul (best-effort sous Windows)
    except OSError:
        pass
    return key


def encrypt(plaintext: str) -> str:
    f = Fernet(_get_or_create_key())
    return f.encrypt(plaintext.encode("utf-8")).decode("utf-8")


def decrypt(ciphertext: str) -> str:
    f = Fernet(_get_or_create_key())
    return f.decrypt(ciphertext.encode("utf-8")).decode("utf-8")
