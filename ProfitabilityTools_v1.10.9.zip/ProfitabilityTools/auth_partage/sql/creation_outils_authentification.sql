/* ============================================================================
   BASE OUTILS - authentification CENTRALISEE des applications Python
   ----------------------------------------------------------------------------
   A executer UNE SEULE FOIS, sur la base OUTILS.

   Principe : les comptes et l'historique des connexions ne vivent plus dans
   la base de chaque application, mais ici. Un agent est declare une fois ;
   son mot de passe et ses accreditations sont verifies au meme endroit,
   quelle que soit l'application par laquelle il arrive.

   La colonne APPLICATIONS porte les accreditations, au format
       ARGOS:Administrateur;PORTAIL:Lecteur
   Chaque application n'ouvre l'acces qu'aux agents portant son code.

   ----------------------------------------------------------------------------
   POURQUOI CE SCRIPT ET PAS UNE MIGRATION ALEMBIC

   La base OUTILS est partagee entre plusieurs applications. Si chacune
   appliquait ses propres migrations sur ce schema, elles se feraient
   concurrence : deux applications demarrant en meme temps sur une base neuve
   tenteraient de creer les memes tables. Le schema d'OUTILS est donc pose
   une fois, ici, et les applications se contentent de le VERIFIER.

   ----------------------------------------------------------------------------
   DROITS A ACCORDER au compte applicatif - le strict necessaire :

       GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.USERS_PYTHON       TO [compte];
       GRANT SELECT, INSERT                 ON dbo.USERS_PYTHON_HISTO TO [compte];

   L'historique n'a pas a etre modifiable : une trace de connexion qu'on peut
   reecrire ne prouve plus rien.

   ----------------------------------------------------------------------------
   NVARCHAR et non VARCHAR sur les colonnes pouvant contenir un nom propre :
   en VARCHAR, la conversion vers la page de codes de la base mutile
   silencieusement les caracteres qu'elle ne connait pas. Le groupe operant en
   Pologne, un nom polonais y perdrait ses caracteres accentues - et un nom
   corrompu en base ne se repare pas apres coup.

   Le DDL ci-dessous est GENERE depuis le schema reel de l'application : il ne
   peut pas diverger de ce que le code attend.
   ========================================================================= */


IF OBJECT_ID('dbo.USERS_PYTHON', 'U') IS NULL
BEGIN
    CREATE TABLE [USERS_PYTHON] (
    	id INTEGER NOT NULL IDENTITY, 
    	login NVARCHAR(50) NOT NULL, 
    	mot_de_passe_hash VARCHAR(128) NOT NULL, 
    	nom NVARCHAR(50) NULL, 
    	prenom NVARCHAR(50) NULL, 
    	email NVARCHAR(120) NULL, 
    	applications VARCHAR(500) NULL, 
    	actif BIT NULL, 
    	doit_changer_mdp BIT NULL, 
    	date_creation DATETIME NULL, 
    	date_modification DATETIME NULL, 
    	cree_par NVARCHAR(50) NULL, 
    	derniere_connexion DATETIME NULL, 
    	commentaire NVARCHAR(255) NULL, 
    	PRIMARY KEY (id), 
    	UNIQUE (login)
    );
END
GO

IF OBJECT_ID('dbo.USERS_PYTHON_HISTO', 'U') IS NULL
BEGIN
    CREATE TABLE [USERS_PYTHON_HISTO] (
    	id INTEGER NOT NULL IDENTITY, 
    	login NVARCHAR(50) NOT NULL, 
    	application VARCHAR(30) NOT NULL, 
    	evenement VARCHAR(30) NOT NULL, 
    	role NVARCHAR(30) NULL, 
    	horodatage DATETIME NULL, 
    	poste NVARCHAR(80) NULL, 
    	utilisateur_systeme NVARCHAR(80) NULL, 
    	detail NVARCHAR(255) NULL, 
    	PRIMARY KEY (id)
    );
    CREATE INDEX [ix_USERS_PYTHON_HISTO_application] ON [USERS_PYTHON_HISTO] (application);
    CREATE INDEX [ix_USERS_PYTHON_HISTO_horodatage] ON [USERS_PYTHON_HISTO] (horodatage);
    CREATE INDEX [ix_USERS_PYTHON_HISTO_login] ON [USERS_PYTHON_HISTO] (login);
END
GO

/* ---------------------------------------------------------------------------
   Compte administrateur initial, si la table est vide.
   Mot de passe : 'admin' - A CHANGER DES LA PREMIERE CONNEXION. L'application
   l'impose : le compte est cree avec doit_changer_mdp a 1.
   L'empreinte ci-dessous est un hachage bcrypt ; le mot de passe en clair
   n'apparait nulle part.
   --------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM dbo.USERS_PYTHON)
BEGIN
    INSERT INTO dbo.USERS_PYTHON
        (login, mot_de_passe_hash, nom, prenom, email, applications,
         actif, doit_changer_mdp, date_creation, date_modification, cree_par,
         commentaire)
    VALUES
        (N'admin', '$2b$12$REMPLACER_PAR_UNE_EMPREINTE_BCRYPT',
         N'Administrateur', N'ICI', N'admin@in-confidence.example',
         'ARGOS:Administrateur', 1, 1, GETDATE(), GETDATE(), 'script SQL',
         N'Compte initial - mot de passe a changer a la premiere connexion');
END
GO

/* Verification */
SELECT login, applications, actif, derniere_connexion
FROM   dbo.USERS_PYTHON ORDER BY login;
SELECT COUNT(*) AS lignes_historique FROM dbo.USERS_PYTHON_HISTO;
