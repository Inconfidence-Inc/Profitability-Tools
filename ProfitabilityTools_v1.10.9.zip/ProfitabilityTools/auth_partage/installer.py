"""Installation de la connexion à la base OUTILS sur un poste.

    python -m auth_partage.installer --application PORTAIL \\
        --dossier-donnees Portail_Assurance \\
        --serveur monserveur.database.windows.net --base OUTILS \\
        --auth windows --trust-server-certificate

Pourquoi cet outil existe : l'API du module sait enregistrer un profil,
mais une application neuve n'avait aucun moyen de le faire sans écrire
d'abord son propre écran d'administration. Or il faut bien que la
connexion soit configurée AVANT la première authentification — sans quoi
personne ne peut se connecter, y compris l'administrateur qui viendrait
la paramétrer. Le problème de l'œuf et de la poule se règle ici, en ligne
de commande.

Trois usages :

- **déploiement de masse** : tous les paramètres en arguments, aucune
  interaction, code de retour exploitable par un script ;
- **installation manuelle** : sans argument, les questions sont posées ;
- **vérification** : `--tester-seulement` contrôle une connexion sans rien
  enregistrer.

L'URL est chiffrée avec la clé locale du poste, comme si elle avait été
saisie dans l'application.
"""
from __future__ import annotations

import argparse
import getpass
import sys

import auth_partage
from auth_partage.connexion_mssql import MODES_AUTH, construire_url_mssql


def _demander(question: str, defaut: str = "") -> str:
    suffixe = f" [{defaut}]" if defaut else ""
    reponse = input(f"{question}{suffixe} : ").strip()
    return reponse or defaut


def main(argv: list[str] | None = None) -> int:
    analyseur = argparse.ArgumentParser(
        description="Configure la connexion à la base OUTILS sur ce poste.")
    analyseur.add_argument("--application", default="",
                            help="code de l'application, ex. PORTAIL")
    analyseur.add_argument("--dossier-donnees", default="",
                            help="dossier de données local (défaut : le code "
                                  "d'application)")
    analyseur.add_argument("--serveur", default="")
    analyseur.add_argument("--port", default="1433")
    analyseur.add_argument("--base", default="OUTILS")
    analyseur.add_argument("--auth", default="windows", choices=sorted(MODES_AUTH),
                            help="mode d'authentification SQL Server")
    analyseur.add_argument("--utilisateur", default="")
    analyseur.add_argument("--mot-de-passe", default="",
                            help="omis, il est demandé sans être affiché")
    analyseur.add_argument("--driver", default="")
    analyseur.add_argument("--sans-chiffrement", action="store_true",
                            help="désactive Encrypt (déconseillé)")
    analyseur.add_argument("--trust-server-certificate", action="store_true",
                            help="accepte un certificat serveur non reconnu par "
                                  "ce poste ; la connexion reste chiffrée")
    analyseur.add_argument("--url", default="",
                            help="URL SQLAlchemy complète, au lieu des champs "
                                  "ci-dessus (tests, autres moteurs)")
    analyseur.add_argument("--creer-tables", action="store_true",
                            help="crée USERS_PYTHON et USERS_PYTHON_HISTO si "
                                  "elles manquent")
    analyseur.add_argument("--tester-seulement", action="store_true",
                            help="teste sans rien enregistrer")
    arguments = analyseur.parse_args(argv)

    application = arguments.application or _demander("Code de l'application")
    if not application:
        print("ÉCHEC : le code de l'application est obligatoire.", file=sys.stderr)
        return 2
    # Les permissions ne servent pas à l'installation : seules comptent
    # l'identité de l'application et son dossier de données.
    auth_partage.configurer(
        application=application,
        permissions={},
        nom_dossier_donnees=arguments.dossier_donnees or application)

    if arguments.url:
        url = arguments.url
        libelle = f"{arguments.base or 'OUTILS'} (URL fournie)"
    else:
        serveur = arguments.serveur or _demander("Serveur")
        if not serveur:
            print("ÉCHEC : le serveur est obligatoire.", file=sys.stderr)
            return 2
        base = arguments.base or _demander("Base", "OUTILS")
        mot_de_passe = arguments.mot_de_passe
        if arguments.auth in ("sql", "azure_ad_password") and not mot_de_passe:
            mot_de_passe = getpass.getpass("Mot de passe : ")
        url = construire_url_mssql(
            serveur=serveur, port=arguments.port, base=base, mode=arguments.auth,
            utilisateur=arguments.utilisateur, mot_de_passe=mot_de_passe,
            driver=arguments.driver, chiffrer=not arguments.sans_chiffrement,
            accepter_certificat=arguments.trust_server_certificate)
        libelle = f"{base} sur {serveur}"

    if arguments.creer_tables:
        ok, message = auth_partage.creer_tables(url)
        print(f"Tables : {message}")
        if not ok:
            return 1

    ok, message = auth_partage.tester(url)
    print(f"Test   : {message}")
    if not ok:
        return 1
    if arguments.tester_seulement:
        print("Test seul : rien n'a été enregistré.")
        return 0

    auth_partage.enregistrer_profil(libelle, "mssql", url)
    print(f"Enregistré : « {libelle} ».")
    print(f"  Profil chiffré dans : {auth_partage.chemin_profil()}")
    print(f"  Les connexions de {application} passeront désormais par cette base.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
