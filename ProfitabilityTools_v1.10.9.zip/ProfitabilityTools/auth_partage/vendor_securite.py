"""Hachage de mot de passe via la librairie bcrypt directement.
(passlib.hash.bcrypt est incompatible avec les versions récentes de la
librairie bcrypt — cf. https://github.com/pyca/bcrypt/issues/684 —
d'où ce petit wrapper local plutôt qu'une dépendance supplémentaire.)
"""
from __future__ import annotations

import bcrypt


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False
