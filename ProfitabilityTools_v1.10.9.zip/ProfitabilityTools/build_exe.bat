@echo off
setlocal
cd /d "%~dp0"
set LOGFILE=%~dp0build_log.txt
echo. > "%LOGFILE%"

echo ============================================
echo ProfitabilityTools - Construction de l'exe
echo ============================================
echo Dossier courant : %cd%
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=py
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set PYCMD=python
    ) else (
        echo ERREUR : aucun interpreteur Python trouve - ni "py" ni "python" installes avec PATH. >> "%LOGFILE%"
        echo ERREUR : aucun interpreteur Python trouve - ni "py" ni "python" installes avec PATH.
        echo Installez Python depuis https://www.python.org/downloads/ en cochant "Add python.exe to PATH".
        pause
        exit /b 1
    )
)

echo Interpreteur utilise : %PYCMD%
%PYCMD% --version 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOGFILE%' -Append"

echo.
echo Installation des dependances + PyInstaller - peut prendre plusieurs minutes...
echo --- pip install --- >> "%LOGFILE%"
%PYCMD% -m pip install -r requirements.txt pyinstaller 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOGFILE%' -Append"
if errorlevel 1 (
    echo.
    echo ERREUR pendant l'installation. Voir le message ci-dessus et build_log.txt.
    pause
    exit /b 1
)

echo.
echo Construction de l'executable autonome - peut prendre plusieurs minutes...
echo --- pyinstaller --- >> "%LOGFILE%"
rem Correctif v1.10.5 : depuis la v1.10.0, l'application depend aussi de
rem SQLAlchemy, bcrypt et cryptography (module auth_partage). SQLAlchemy
rem choisit son dialecte (sqlite, mssql+pyodbc) par un import DYNAMIQUE
rem que PyInstaller ne detecte jamais par analyse statique, donc sans les
rem options --collect-all ci-dessous l'executable construit plantait des
rem la premiere connexion a la base d'authentification, sans aucun message
rem visible (mode --windowed = aucune console). Voir le README pour le
rem detail complet de ce correctif.
rem Correctif v1.10.9 : demande explicite de l'utilisateur apres un echec
rem au lancement de l'exe - "Failed to start embedded python interpreter:
rem Failed to import encodings module" - avec le mode par defaut --onedir,
rem qui cree un dossier _internal de plusieurs centaines de Mo a cote de
rem l'exe, sensible a une copie partielle, un antivirus, ou une
rem synchronisation OneDrive qui laisse des fichiers en l'etat de simples
rem references non telechargees. --onefile regroupe tout dans un seul
rem fichier .exe autonome, qui s'auto-extrait dans un dossier temporaire a
rem chaque lancement. Voir le README pour le detail complet de ce correctif.
%PYCMD% -m PyInstaller --noconfirm --clean --name ProfitabilityTools --onefile --windowed --paths . --collect-all PySide6 --collect-all auth_partage --collect-all sqlalchemy --collect-all bcrypt --collect-all cryptography --icon app\assets\logo.ico --add-data "app\assets;app\assets" run.py 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOGFILE%' -Append"
if errorlevel 1 (
    echo.
    echo ERREUR pendant la construction. Voir le message ci-dessus et build_log.txt.
    pause
    exit /b 1
)

echo.
echo ============================================
echo TERMINE
echo ============================================
echo Le fichier executable se trouve dans :
echo   %cd%\dist\ProfitabilityTools.exe
echo.
echo C'est un fichier unique et autonome - double-clic pour lancer. Il peut
echo etre copie/deplace/partage tel quel, sans avoir besoin de Python
echo installe sur le poste cible, ni d'aucun autre fichier ou dossier a cote.
echo.
pause
